TRUNCATE TABLE `product_center`.`module_auth_quota`;
-- Kong