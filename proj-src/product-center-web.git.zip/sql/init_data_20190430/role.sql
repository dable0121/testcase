TRUNCATE TABLE `product_center`.`role`;
INSERT INTO `role` VALUES ('ROLE_ADMIN', '管理员');
