TRUNCATE TABLE `product_center`.`user_role`;
INSERT INTO `user_role` VALUES ('daib', 'ROLE_ADMIN');
INSERT INTO `user_role` VALUES ('lvxg', 'ROLE_ADMIN');
INSERT INTO `user_role` VALUES ('manjh', 'ROLE_ADMIN');
INSERT INTO `user_role` VALUES ('xial-a', 'ROLE_ADMIN');
INSERT INTO `user_role` VALUES ('yexy-a', 'ROLE_ADMIN');
INSERT INTO `user_role` VALUES ('chenlp', 'ROLE_ADMIN');
