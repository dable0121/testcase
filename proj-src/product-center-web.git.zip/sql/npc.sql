-- 创建数据库
-- CREATE DATABASE IF NOT EXISTS product_center default charset utf8 COLLATE utf8_general_ci;

USE product_center;
-- 创建表
CREATE TABLE `product_line` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `product_line_name` varchar(255) NOT NULL COMMENT '产品线',
  `is_stop` tinyint(1) DEFAULT '0' COMMENT '是否停用：0否1是',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_product_line_name` (`product_line_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品线表';

CREATE TABLE IF NOT EXISTS `budget_product` (
  `id` INTEGER unsigned NOT NULL  AUTO_INCREMENT COMMENT 'id',
  `product_line_id` SMALLINT unsigned NOT NULL  COMMENT '产品线id',
  `budget_product_name` varchar(255) NOT NULL COMMENT '预算产品',
  `is_stop`  TINYINT(1) DEFAULT '0' COMMENT '是否停用：0否1是',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `k_product_line_id` (`product_line_id`),
  UNIQUE KEY  `uk_budget_product_name` (`budget_product_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='预算产品表';

CREATE TABLE IF NOT EXISTS `copyright` (
  `id` INTEGER unsigned NOT NULL  AUTO_INCREMENT COMMENT 'id',
  `copyright_code` varchar(255) NOT NULL  COMMENT '著作权编号',
  `copyright_name` varchar(255) NOT NULL COMMENT '著作权名称',
  `is_stop`  TINYINT(1) DEFAULT '0' COMMENT '是否停用：0否1是',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY  `uk_copyright_code` (`copyright_code`) USING BTREE,
  UNIQUE KEY  `uk_copyright_name` (`copyright_name`) USING BTREE

) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='著作权表';


CREATE TABLE IF NOT EXISTS `gmspid_rule` (
  `id` INTEGER unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `type_name` varchar(255) NOT NULL COMMENT '类型名称',
  `parent_id` INTEGER unsigned DEFAULT '0' COMMENT '父id',
  `description` varchar(1000) NOT NULL DEFAULT '' COMMENT '描述',
  `type` char(1) NOT NULL COMMENT '类型标识',
  `gmspid_start` char(4) DEFAULT NULL COMMENT 'gmspid起始数',
  `gmspid_end` char(4) DEFAULT NULL COMMENT 'gmspid结束数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='助记符规则表';
-- init gmspid_rule
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (1, '程序', 0, '程序类', '1', '3000', '9999', '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (2, '定额', 0, '定额', '2', '3000', '8999', '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (3, '规则', 0, '规则', '3', '3000', '9999', '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (4, '互联网', 0, '互联网云续费类', '4', '3000', '9999', '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (5, '国际化', 1, '国际化产品', '1', '1520', '2000', '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (6, '广梦', 1, '广梦产品', '1', NULL, NULL, '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (7, '擎洲', 1, '擎洲软件', '1', NULL, NULL, '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (8, '兴安得力', 1, '兴安得力软件', '1', NULL, NULL, '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (9, '其他', 1, '其他', '1', NULL, NULL, '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (10, '华润', 2, '华润', '2', '9010', '9999', '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (11, '其他', 2, '其他', '2', NULL, NULL, '2018-12-18 10:00:00', '2018-12-18 10:00:00');
INSERT INTO `product_center`.`gmspid_rule`(`id`, `type_name`, `parent_id`, `description`, `type`, `gmspid_start`, `gmspid_end`, `create_time`, `update_time`) VALUES (12, '施工', 1, '施工', '1', NULL, NULL, '2018-12-18 10:00:00', '2018-12-18 10:00:00');



CREATE TABLE IF NOT EXISTS `type_gmspid` (
  `id` INTEGER unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `gmspid_rule_id` INTEGER unsigned NOT NULL COMMENT 'gmspid_rule_id',
  `type` char(1) NOT NULL COMMENT '类型标识',
  `gmspid` char(4) NOT NULL COMMENT 'gmspid',
    `out_pid` varchar(255) DEFAULT NULL COMMENT '外部产品id',
    `out_mid` varchar(255) DEFAULT NULL COMMENT '外部模块id',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY  `uk_type_gmspid` (`type`,`gmspid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='助记符表';

-- ----------------------------
-- Table structure for module_auth_template
-- ----------------------------
DROP TABLE IF EXISTS `module_auth_template`;
CREATE TABLE `module_auth_template` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `mid` varchar(32) NOT NULL COMMENT '模块ID',
  `auth_name` varchar(255) NOT NULL COMMENT '名称',
  `auth_type` tinyint(3) unsigned NOT NULL COMMENT '1. 整型 2. 字符型 3. 布尔型 4.枚举',
  `auth_code` varchar(180) NOT NULL COMMENT '授权编码',
  `auth_category` tinyint(3) unsigned NOT NULL COMMENT '授权类别 0: 无类别 1:空间大小 2:空间成员数',
  `auth_read_only` tinyint(4) NOT NULL COMMENT '0:可编辑，1:不可编辑',
  `auth_default_value` varchar(255) DEFAULT NULL COMMENT '属性默认值',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mid_and_code` (`mid`,`auth_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` varchar(32) NOT NULL COMMENT '产品ID',
  `product_line_id` smallint(5) unsigned NOT NULL COMMENT '产品线ID',
  `budget_product_id` int(10) unsigned NOT NULL COMMENT '预算产品ID',
  `name` varchar(255) NOT NULL COMMENT '产品名称',
  `product_status` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '产品状态 1.新建 2.已发布',
  `domain_creator` varchar(255) NOT NULL COMMENT '归属域账号',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品表';

-- ----------------------------
-- Table structure for product_module
-- ----------------------------
CREATE TABLE `product_module` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '模块名称',
  `auth_type` varchar(255) NOT NULL COMMENT '授权分类 0.无 1.加密锁 2.账号 3.激活码 4.证书',
  `pid` varchar(32) NOT NULL COMMENT '产品ID',
  `product_name` varchar(255) NOT NULL COMMENT '产品名称',
  `copyright_name` varchar(255) DEFAULT NULL COMMENT '著作权名称',
  `copyright_code` varchar(255) DEFAULT NULL COMMENT '著作权编号',
  `app_name` varchar(255) DEFAULT NULL COMMENT '驱动标识',
  `lock_auth_pid` varchar(255) DEFAULT NULL COMMENT '锁授权产品标识(助记符)',
  `new_lock_auth_rule_id` int(10) unsigned DEFAULT NULL COMMENT '助记符生成规则ID',
  `out_product_id` varchar(255) DEFAULT NULL COMMENT '外部产品id',
  `out_module_id` varchar(255) DEFAULT NULL COMMENT '外部模块id',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_name` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `role` (
  `role_name` varchar(255) NOT NULL COMMENT '角色名',
  `comment` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色表';
-- 插入管理员角色
INSERT INTO `product_center`.`role`(`role_name`, `comment`) VALUES ('ROLE_ADMIN', '管理员');

CREATE TABLE `user_role` (
  `user_name` varchar(128) NOT NULL COMMENT '用户名',
  `role_name` varchar(64) NOT NULL COMMENT '角色名',
  PRIMARY KEY (`user_name`,`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户角色关系表';

INSERT INTO `product_center`.`user_role`(`user_name`, `role_name`) VALUES ('xial-a', 'ROLE_ADMIN');
INSERT INTO `product_center`.`user_role`(`user_name`, `role_name`) VALUES ('yexy-a', 'ROLE_ADMIN');
INSERT INTO `product_center`.`user_role`(`user_name`, `role_name`) VALUES ('daib', 'ROLE_ADMIN');
INSERT INTO `product_center`.`user_role`(`user_name`, `role_name`) VALUES ('manjh', 'ROLE_ADMIN');
INSERT INTO `product_center`.`user_role`(`user_name`, `role_name`) VALUES ('lvxg', 'ROLE_ADMIN');