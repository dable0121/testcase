-- 改名去除不用字段
ALTER  TABLE product_module RENAME TO product_auth_module;
ALTER  TABLE module_auth_template RENAME TO module_auth_quota;

alter table product_auth_module drop index uk_name;

alter  table product_auth_module change `name` `auth_name` varchar(255) NOT NULL default '' COMMENT
'授权模块名称';
alter table product_auth_module add  UNIQUE KEY `uk_auth_name` (`auth_name`) USING BTREE;


alter  table module_auth_quota change `auth_name` `quota_name` varchar(255) NOT NULL default '' COMMENT '配额名称';
alter  table module_auth_quota change `auth_type` `quota_type` tinyint(3) unsigned NOT NULL
default 1 COMMENT '1. 整型 2. 字符型';
alter  table module_auth_quota change  `auth_default_value` `quota_default_value` varchar(255) DEFAULT NULL COMMENT '属性默认值';
alter table product_auth_module DROP COLUMN auth_type;
alter table product_auth_module DROP COLUMN app_name;
alter table module_auth_quota DROP COLUMN `auth_code`;
alter table module_auth_quota DROP COLUMN `auth_category`;
alter table module_auth_quota DROP COLUMN `auth_read_only`;
alter table module_auth_quota DROP index uk_mid_and_code;


-- 多对多关系配置
alter table product_auth_module DROP COLUMN pid;
alter table product_auth_module DROP COLUMN product_name;
CREATE TABLE `product_and_module` (
  `pid` varchar(32) NOT NULL COMMENT '产品id',
  `mid` varchar(32) NOT NULL COMMENT '模块id',
   PRIMARY KEY (`pid`,`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品模块关系';




