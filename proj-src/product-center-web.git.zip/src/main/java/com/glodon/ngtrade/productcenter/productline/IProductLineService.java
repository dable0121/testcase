package com.glodon.ngtrade.productcenter.productline;

import com.glodon.ngtrade.productcenter.productline.ProductLine;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 产品线表 服务类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
public interface IProductLineService extends IService<ProductLine> {

  ProductLine getByIDWithException(Integer productLineId);
}
