package com.glodon.ngtrade.productcenter.moduleauthquota;

import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dable
 * @since 2018-12-12
 */
public interface IModuleAuthQuotaService extends IService<ModuleAuthQuota> {

  void createByDTO(List<ModuleAuthQuotaDTO> authTemplates);

  String generateId();
}
