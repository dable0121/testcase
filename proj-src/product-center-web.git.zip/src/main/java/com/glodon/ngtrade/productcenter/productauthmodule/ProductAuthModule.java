package com.glodon.ngtrade.productcenter.productauthmodule;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 *
 * </p>
 *
 * @author dable
 * @since 2019-01-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ProductAuthModule implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * 主键
   */
  private String id;

  /**
   * 授权模块名称
   */
  private String authName;



  /**
   * 著作权名称
   */
  private String copyrightName;

  /**
   * 著作权编号
   */
  private String copyrightCode;


  /**
   * 锁授权产品标识(助记符)
   */
  private String lockAuthPid;

  /**
   * 助记符生成规则ID
   */
  private Integer newLockAuthRuleId;

  /**
   * 外部产品标识
   */
  private String outProductId;

  /**
   * 外部模块标识
   */
  private String outModuleId;

  /**
   * 创建时间
   */
  private LocalDateTime createTime;

  /**
   * 更新时间
   */
  private LocalDateTime updateTime;

}
