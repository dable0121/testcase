package com.glodon.ngtrade.productcenter.product;

import lombok.Data;

@Data
public class PageDTO {
    private String searchValue;
    private Integer size;
    private Integer current;
}
