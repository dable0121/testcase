package com.glodon.ngtrade.productcenter.gmspidrule.dto;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Data;

/**
 * @author dable
 */
@Data
public class GmspidRuleDTO implements Serializable{
  private Integer id;

  /**
   * 类型名称
   */
  private String typeName;

  /**
   * 父id
   */
  private Integer parentId;

  /**
   * 描述
   */
  private String description;

  /**
   * 类型标识
   */
  private String type;

  /**
   * gmspid起始数
   */
  private String gmspidStart;

  /**
   * gmspid结束数
   */
  private String gmspidEnd;

  private LocalDateTime createTime;

  private LocalDateTime updateTime;

  private List<GmspidRuleDTO> childs;
}
