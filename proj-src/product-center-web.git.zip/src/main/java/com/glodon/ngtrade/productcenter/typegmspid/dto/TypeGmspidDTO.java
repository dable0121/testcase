package com.glodon.ngtrade.productcenter.typegmspid.dto;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Data;

@Data
public class TypeGmspidDTO implements Serializable {

  private String typeGmspid;
  private String gmspid;
  private List<PMDTO> moduleDtos;
  private Integer gmspRuleId;
  private LocalDateTime createTime;
  private String typeName;

}
