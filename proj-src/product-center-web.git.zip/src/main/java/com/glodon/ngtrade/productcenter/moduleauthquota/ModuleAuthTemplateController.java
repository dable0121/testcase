package com.glodon.ngtrade.productcenter.moduleauthquota;


import com.glodon.ngtrade.productcenter.common.UpdatePublish;
import com.glodon.ngtrade.productcenter.productauthmodule.IProductAuthModuleService;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author dable
 * @since 2019-01-02
 */
@RestController
@RequestMapping("/api/module-auth-template")
public class ModuleAuthTemplateController {

    private final static Logger logger = LoggerFactory.getLogger(ModuleAuthTemplateController.class);

    @Autowired
    private IModuleAuthQuotaService moduleAuthTemplateService;
    @Autowired
    private IProductAuthModuleService productModuleService;

    @PostMapping
    public Response create(@RequestBody List<ModuleAuthQuotaDTO> authTemplates) {
        logger.info("create[{}]", authTemplates);

        moduleAuthTemplateService.createByDTO(authTemplates);
        return Response.SUCCESS;
    }

    @Autowired
    UpdatePublish updatePublish;

    @PutMapping
    @Transactional
    public Response update(@RequestBody ModuleAuthQuotaDTO dto) {
        productModuleService.getAuthModuleByIDWithException(dto.getMid());
        if (dto.getId() == null ||
                moduleAuthTemplateService.getById(dto.getId()) == null) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.ERROR, "授权配额更新，配额id" +
                    "不能为空，必须存在");
        }
        dto.setUpdateTime(LocalDateTime.now());
        ModuleAuthQuota moduleAuthQuota = new ModuleAuthQuota();
        BeanUtils.copyProperties(dto, moduleAuthQuota);
        boolean b = moduleAuthTemplateService.updateById(moduleAuthQuota);
        updatePublish.updateModuleTime(dto.getMid());
        return b ?
                Response.SUCCESS : Response.getErrorResponseWithNoArgs(MessageCode.MessageCodeEnum.DB_INSERT_UPDATE_ERROR);

    }
}

