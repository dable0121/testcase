package com.glodon.ngtrade.productcenter.moduleauthquota;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author dable
 * @since 2018-12-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ModuleAuthQuota implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;

    /**
     * 模块ID
     */
    private String mid;

    /**
     * 配额名称
     */
    private String quotaName;

    /**
     * 1. 整型 2. 字符型
     */
    private Integer quotaType;


    /**
     * 属性默认值
     */
    private String quotaDefaultValue;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

}
