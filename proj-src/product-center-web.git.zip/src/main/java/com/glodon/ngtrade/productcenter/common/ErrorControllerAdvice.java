package com.glodon.ngtrade.productcenter.common;

import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Dable on 2017/5/9 16:17.
 */
@ControllerAdvice(basePackages = "com.glodon.ngtrade.productcenter")
public class ErrorControllerAdvice extends ResponseEntityExceptionHandler {
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public Response<?> handleControllerException(Throwable ex) {
        logger.error("product-center-[统一异常捕获]", ex);
        String errorCode;
        String errorMsg;
        // 在这里判断异常，根据不同的异常返回错误。
        if (ex instanceof NgtradeException) {
            errorCode = ((NgtradeException) ex).getErrorCode();
            errorMsg = ((NgtradeException) ex).getErrorMsg();
            return Response.errorWithOtherMsg(errorCode, errorMsg);
        } else if (ex instanceof MethodArgumentNotValidException) {
            logger.error("请求参数不合法-------------", ex);
            BindingResult bindingResult = ((MethodArgumentNotValidException) ex).getBindingResult();
            return Response.errorWithOtherMsg(MessageCode.MessageCodeEnum.ERROR.getCode(), String.valueOf(getErrors(bindingResult)));
        } else {
            // 根据异常类型判断错误码
            errorCode = MessageCode.getErrorCodeByException((Exception) ex);
            errorMsg = MessageCode.getMsg(errorCode, ex.getClass().getName());
            return Response.errorWithOtherMsg(errorCode, errorMsg);
        }
    }

    private Map<String, String> getErrors(BindingResult result) {
        Map<String, String> map = new HashMap<>();
        List<FieldError> list = result.getFieldErrors();
        for (FieldError error : list) {
            map.put(error.getField(), error.getDefaultMessage());
        }
        return map;
    }
}
