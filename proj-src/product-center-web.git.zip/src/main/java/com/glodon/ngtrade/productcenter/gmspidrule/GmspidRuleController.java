package com.glodon.ngtrade.productcenter.gmspidrule;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.glodon.ngtrade.productcenter.gmspidrule.impl.GmspidRuleServiceImpl;
import com.glodon.ngtrade.util.common.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 助记符规则表 前端控制器
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@RestController
@RequestMapping("/api/gmspid-rule")
public class GmspidRuleController {
  @Autowired
  GmspidRuleServiceImpl gmspidRuleService;

  @GetMapping("listall")
  public Response getChildren() {
    return Response.successWithData(gmspidRuleService.getChildren());
  }

  @GetMapping("typelist")
  public Response getTypeList() {
    QueryWrapper<GmspidRule> queryWrapper = new QueryWrapper<>();
    queryWrapper.lambda().eq(GmspidRule::getParentId,Integer.valueOf(0));
    return Response.successWithData(gmspidRuleService.list(queryWrapper));
  }
}

