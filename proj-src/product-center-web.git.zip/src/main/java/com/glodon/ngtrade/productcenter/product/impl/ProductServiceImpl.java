package com.glodon.ngtrade.productcenter.product.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.glodon.ngtrade.productcenter.budgetproduct.BudgetProduct;
import com.glodon.ngtrade.productcenter.budgetproduct.impl.BudgetProductServiceImpl;
import com.glodon.ngtrade.productcenter.common.UpdatePublish;
import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuota;
import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuotaDTO;
import com.glodon.ngtrade.productcenter.moduleauthquota.impl.ModuleAuthQuotaServiceImpl;
import com.glodon.ngtrade.productcenter.product.*;
import com.glodon.ngtrade.productcenter.productandmodule.ProductAndModule;
import com.glodon.ngtrade.productcenter.productandmodule.impl.ProductAndModuleServiceImpl;
import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModule;
import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModuleDTO;
import com.glodon.ngtrade.productcenter.productauthmodule.impl.ProductAuthModuleServiceImpl;
import com.glodon.ngtrade.productcenter.productline.ProductLine;
import com.glodon.ngtrade.productcenter.productline.impl.ProductLineServiceImpl;
import com.glodon.ngtrade.productcenter.typegmspid.TypeGmspid;
import com.glodon.ngtrade.productcenter.typegmspid.impl.TypeGmspidServiceImpl;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * 产品表 服务实现类
 * </p>
 *
 * @author dable
 * @since 2018-12-11
 */
@Service("productService")
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements IProductService {

    private final static Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);

    @Autowired
    private ProductAuthModuleServiceImpl productAuthModuleService;

    @Autowired
    private ModuleAuthQuotaServiceImpl moduleAuthQuotaService;

    @Autowired
    private ProductLineServiceImpl productLineService;

    @Autowired
    private BudgetProductServiceImpl budgetProductService;

    @Autowired
    private ProductAndModuleServiceImpl productAndModuleService;

    @Autowired
    private TypeGmspidServiceImpl typeGmspidService;

    @Autowired
    private RedissonClient redissonClient;

    public static final String PRODUCT_CREATE_DLOCK_PREFIX = "PRODUCT_CREATE_DLOCK";

    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    public String createByDTO(ProductDTO productDTO) throws InterruptedException {


        RLock lock = redissonClient.getLock(PRODUCT_CREATE_DLOCK_PREFIX);

        // 尝试加锁，最多等待5秒，上锁以后300秒自动解锁
        try {
            boolean lockAcquired = lock.tryLock(5, 60 * 5, TimeUnit.SECONDS);
            if (lockAcquired) {
                String productId = generateId();
                fillLockAuthPid(productDTO);
                Product product = new Product();
                BeanUtils.copyProperties(productDTO, product);

                product.setId(productId);
                product.setProductStatus(ProductEnum.ProductStatusEnum.NEW.getStatus());

                save(product);

                @Valid List<ProductAuthModuleDTO> productAuthModuleDTOS =
                        productDTO.getProductAuthModuleDTOS();
                if (!CollectionUtils.isEmpty(productAuthModuleDTOS)) {

                    for (ProductAuthModuleDTO moduleDTO : productAuthModuleDTOS) {
                        String moduleId =
                                productAuthModuleService.generateId();
                        Collection<ProductAuthModule> productAuthModules = productAuthModuleService.listByIds(Arrays.asList(moduleId));
                        if (!productAuthModules.isEmpty()) {
                            logger.info("当前模块id{}已经存在不需要新增模块信息", moduleId);
                        } else {
                            ProductAuthModule newpam = new ProductAuthModule();
                            moduleDTO.setId(moduleId);
                            BeanUtils.copyProperties(moduleDTO, newpam);
                            productAuthModuleService.save(newpam);
                        }
                        ProductAndModule pm = new ProductAndModule();

                        pm.setPid(product.getId());
                        pm.setMid(moduleId);
                        if (productAndModuleService.selectOne(pm) == null) {
                            productAndModuleService.insert(pm);
                        }
                        List<ModuleAuthQuotaDTO> moduleAuthQuotaDTOS =
                                moduleDTO.getModuleAuthQuotaDTOS();
                        if (!CollectionUtils.isEmpty(moduleAuthQuotaDTOS)) {

                            for (ModuleAuthQuotaDTO moduleAuthTemplateDTO : moduleAuthQuotaDTOS) {
                                moduleAuthTemplateDTO.setMid(moduleId);
                            }
                            for (ModuleAuthQuotaDTO moduleAuthQuotaDTO : moduleAuthQuotaDTOS) {

                                String templateId = moduleAuthQuotaService.generateId();

                                ModuleAuthQuota moduleAuthQuota = new ModuleAuthQuota();

                                BeanUtils.copyProperties(moduleAuthQuotaDTO, moduleAuthQuota);
                                moduleAuthQuota.setId(templateId);
                                moduleAuthQuotaService.save(moduleAuthQuota);
                            }
                        }
                    }
                }
                return productId;
            } else {
                throw NgtradeException.exception(MessageCode.MessageCodeEnum.PRODUCT_CREATE_ERROR.getCode(), "createByDTO acquire lock failed");
            }
        } catch (Exception e) {
            throw e;
        } finally {
            lock.unlock();
        }
    }

    /**
     * P打头+5位数字
     */
    public String generateId() {
        final String FORMAT = "P%05d";
        List<Product> productList =
                list(new LambdaQueryWrapper<Product>().orderByDesc(Product::getId).last("limit 1"));
        if (productList.isEmpty()) {
            return String.format(FORMAT, 1);
        }
        String id = productList.get(0).getId();
        return String.format(FORMAT, Long.parseLong(id.substring(1)) + 1);
    }

    @Autowired
    UpdatePublish updatePublish;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateByDTO(ProductDTO productDTO) {

        Product product = getProductByDTOWithException(productDTO);

        BeanUtils.copyProperties(productDTO, product);

        product.setUpdateTime(LocalDateTime.now());

        updateById(product);
    }

    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.SERIALIZABLE)
    public void saveUpdateQuota(ProductAuthModuleDTO moduleDTO) {
        List<ModuleAuthQuotaDTO> quotaDTOS =
                moduleDTO.getModuleAuthQuotaDTOS();
        if (!CollectionUtils.isEmpty(quotaDTOS)) {
            for (ModuleAuthQuotaDTO quotaDTO : quotaDTOS) {
                if (StringUtils.isBlank(quotaDTO.getId())) {
                    String qid = moduleAuthQuotaService.generateId();
                    quotaDTO.setId(qid);
                }
                ModuleAuthQuota quota = new ModuleAuthQuota();
                BeanUtils.copyProperties(quotaDTO, quota);
                quota.setMid(moduleDTO.getId());
                moduleAuthQuotaService.saveOrUpdate(quota);
            }
        }
    }

    @Override
    public Product getProductByDTOWithException(ProductDTO productDTO) {
        if (StringUtils.isBlank(productDTO.getId())) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND.getCode());
        }
        Product product = getById(productDTO.getId());
        if (null == product) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND.getCode());
        }
        return product;
    }

    @Override
    public Product getProductByIDWithException(String id) {
        if (StringUtils.isBlank(id)) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND);
        }
        Product product = getById(id);
        if (null == product) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND.getCode(),
                    "产品不存在" + id);
        }
        return product;
    }


    @Override
    public void checkProductLineExistenceWithException(ProductDTO productDTO) {
        ProductLine productLine = productLineService.getById(productDTO.getProductLineId());
        if (null == productLine) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND);
        }
    }

    @Override
    public void checkBudgetProductExistenceWithException(ProductDTO productDTO) {
        BudgetProduct budgetProduct = budgetProductService.getById(productDTO.getBudgetProductId());
        if (null == budgetProduct) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void fillLockAuthPid(ProductDTO productDTO) {
        @Valid List<ProductAuthModuleDTO> authModules = productDTO.getProductAuthModuleDTOS();
        if (!CollectionUtils.isEmpty(authModules)) {
            for (ProductAuthModuleDTO moduleDTO : authModules) {
                if (moduleDTO.getNewLockAuthPid()) {
                    TypeGmspid typeGmspid =
                            typeGmspidService.genTypeGmspid(moduleDTO.getNewLockAuthRuleId(),
                                    moduleDTO.getOutProductId(), moduleDTO.getOutModuleId());
                    moduleDTO.setLockAuthPid(typeGmspid.getType() + typeGmspid.getGmspid());
                } else {
                    if (StringUtils.isNotBlank(moduleDTO.getLockAuthPid())) {
                        TypeGmspid typeGmspid =
                                typeGmspidService.getOne(new LambdaQueryWrapper<TypeGmspid>().eq(TypeGmspid::getType, moduleDTO.getLockAuthPid().substring(0, 1)).eq(TypeGmspid::getGmspid, moduleDTO.getLockAuthPid().substring(1)));
                        if (null == typeGmspid) {
                            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND.getCode(), "助记符未找到:" + moduleDTO.getLockAuthPid());
                        }
                    } else {
                        throw NgtradeException.exception(MessageCode.MessageCodeEnum.COMMODITY_CHANGE_GT_TIMES);
                    }
                }
            }
        }
    }

    @Override
    public void checkProductNameUniqueWithException(ProductDTO productDTO) {
        List<Product> product;
        if (StringUtils.isBlank(productDTO.getId())) {
            product =
                    list(new LambdaQueryWrapper<Product>().eq(Product::getName
                            , productDTO.getName()));

        } else {
            product =
                    list(new LambdaQueryWrapper<Product>().eq(Product::getName
                            , productDTO.getName()).ne(Product::getId, productDTO.getId()));
        }
        if (!product.isEmpty()) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_UNIQUE.getCode(),
                    productDTO.getName() + "已存在，请重新填写");
        }
    }

    @Override
    public void checkModuleNameUniqueWithException(ProductDTO productDTO) {
        @Valid List<ProductAuthModuleDTO> authModules = productDTO.getProductAuthModuleDTOS();
        if (!CollectionUtils.isEmpty(authModules)) {
            for (ProductAuthModuleDTO productAuthModuleDTO : authModules) {
                List<ProductAuthModule> duplicateNameModule = null;
                if (StringUtils.isBlank(productAuthModuleDTO.getId())) {
                    duplicateNameModule =
                            productAuthModuleService.list(new LambdaQueryWrapper<ProductAuthModule>().eq(ProductAuthModule::getAuthName, productAuthModuleDTO.getAuthName()));
                } else {
                    duplicateNameModule =
                            productAuthModuleService.list(new LambdaQueryWrapper<ProductAuthModule>()
                                    .eq(ProductAuthModule::getAuthName, productAuthModuleDTO.getAuthName())
                                    .ne(ProductAuthModule::getId, productAuthModuleDTO.getId()));
                }
                if (!duplicateNameModule.isEmpty()) {
                    throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_UNIQUE.getCode(), "模块名称不可以重复");
                }
                if (!productAuthModuleDTO.getNewLockAuthPid()) {
                    // 添加已有助记符
                    if (StringUtils.isBlank(productAuthModuleDTO.getLockAuthPid())) {
                        throw NgtradeException.exception(MessageCode.MessageCodeEnum.PARAMETER_NOT_FOUND, "添加已有助记符，助记符不能为空！");
                    }

                }
            }
        }
    }


}
