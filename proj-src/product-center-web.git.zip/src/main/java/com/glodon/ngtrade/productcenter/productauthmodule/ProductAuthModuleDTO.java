package com.glodon.ngtrade.productcenter.productauthmodule;

import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuotaDTO;
import com.glodon.ngtrade.productcenter.product.ProductDTO;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author dable
 * @since 2019-01-02
 */
@Data
public class ProductAuthModuleDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;

    /**
     * 授权模块名称
     */
    @NotBlank
    private String authName;


    /**
     * 著作权名称
     */
    private String copyrightName;

    /**
     * 产品ID
     */
    private String pid;

    /**
     * 著作权编号
     */
    private String copyrightCode;


    /**
     * 锁授权产品标识(助记符)
     */
    private String lockAuthPid;

    /**
     * 选择已有锁授权产品ID
     */
    private Boolean newLockAuthPid;

    /**
     * 助记符生成规则ID
     */
    private Integer newLockAuthRuleId;

    /**
     * 助记符类别名称
     */
    private String ruleTypeName;

    /**
     * 外部产品标识
     */
    private String outProductId;

    /**
     * 外部模块标识
     */
    private String outModuleId;

    /**
     * 模块功能点
     */
    private List<ModuleAuthQuotaDTO> moduleAuthQuotaDTOS;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 产品列表
     */
    private List<ProductDTO> productDTOS;

    /**
     * 创建时间
     */
    private long createTimeLong;

    /**
     * 更新时间
     */
    private long updateTimeLong;

    public long getCreateTimeLong() {
        return this.createTime.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public void setCreateTimeLong(long createTimeLong) {
        this.createTimeLong = createTimeLong;
    }

    public long getUpdateTimeLong() {
        return this.updateTime.toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

    public void setUpdateTimeLong(long updateTimeLong) {
        this.updateTimeLong = updateTimeLong;
    }
}