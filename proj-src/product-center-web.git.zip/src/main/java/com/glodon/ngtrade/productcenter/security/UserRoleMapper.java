package com.glodon.ngtrade.productcenter.security;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author dable
 * @since 2018-12-11
 */
public interface UserRoleMapper extends BaseMapper<UserRole> {
// select * from user_role where user_name = "xxx";
}
