package com.glodon.ngtrade.productcenter.product;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.glodon.ngtrade.productcenter.budgetproduct.BudgetProduct;
import com.glodon.ngtrade.productcenter.budgetproduct.impl.BudgetProductServiceImpl;
import com.glodon.ngtrade.productcenter.copyright.impl.CopyrightServiceImpl;
import com.glodon.ngtrade.productcenter.moduleauthquota.IModuleAuthQuotaService;
import com.glodon.ngtrade.productcenter.productandmodule.impl.ProductAndModuleServiceImpl;
import com.glodon.ngtrade.productcenter.productauthmodule.IProductAuthModuleService;
import com.glodon.ngtrade.productcenter.productline.ProductLine;
import com.glodon.ngtrade.productcenter.productline.impl.ProductLineServiceImpl;
import com.glodon.ngtrade.productcenter.typegmspid.impl.TypeGmspidServiceImpl;
import com.glodon.ngtrade.util.common.response.Response;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * <p>
 * 产品表 前端控制器
 * </p>
 *
 * @author dable
 * @since 2018-12-11
 */
@RestController
@RequestMapping("/api/product")
public class ProductController {

    public static final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private IProductService productService;

    @Autowired
    private IProductAuthModuleService productModuleService;

    @Autowired
    private ProductAndModuleServiceImpl productAndModuleService;

    @Autowired
    private BudgetProductServiceImpl budgetProductService;

    @Autowired
    private ProductLineServiceImpl productLineService;

    @Autowired
    private TypeGmspidServiceImpl typeGmspidService;

    @Autowired
    private CopyrightServiceImpl copyrightService;

    @Autowired
    private IModuleAuthQuotaService moduleAuthTemplateService;


    /**
     * 创建产品.
     */
    @PostMapping
    @SneakyThrows
    @Transactional(rollbackFor = Exception.class,propagation = Propagation.REQUIRED)
    public Response create(@RequestBody @Valid ProductDTO productDTO) {

        logger.info("product post,request:{}", productDTO);

        productService.checkProductNameUniqueWithException(productDTO);

        productService.checkModuleNameUniqueWithException(productDTO);

        productService.checkProductLineExistenceWithException(productDTO);

        productService.checkBudgetProductExistenceWithException(productDTO);

        String pid = productService.createByDTO(productDTO);

        return Response.successWithData(pid);
    }

    /**
     * 修改产品.
     */
    @PutMapping
    @Transactional(rollbackFor = Exception.class)
    public Response update(@RequestBody @Valid ProductDTO productDTO) {

        logger.info("product put,request: {}", productDTO);

        productService.checkProductNameUniqueWithException(productDTO);

        productService.checkModuleNameUniqueWithException(productDTO);

        productService.checkProductLineExistenceWithException(productDTO);

        productService.checkBudgetProductExistenceWithException(productDTO);

        productService.getProductByDTOWithException(productDTO);

        productService.updateByDTO(productDTO);

        return Response.SUCCESS;
    }

    @GetMapping("{id}")
    public Response get(@PathVariable String id) {
        logger.info("get: [{}]", id);
        Product product = productService.getProductByIDWithException(id);
        ProductDTO productDTO = new ProductDTO();
        BeanUtils.copyProperties(product, productDTO);

        BudgetProduct budgetProduct =
                budgetProductService.getByIDWithException(product.getBudgetProductId());

        ProductLine productLine =
                productLineService.getByIDWithException(product.getProductLineId());
        if (productLine != null) {
            productDTO.setProductLineName(productLine.getProductLineName());
        }
        if (budgetProduct != null) {
            productDTO.setBudgetProductName(budgetProduct.getBudgetProductName());
        }
        return Response.successWithData(productDTO);
    }

    @PostMapping("{id}/updateStatus")
    public Response updateStatus(@PathVariable String id, @RequestParam Integer status) {

        logger.info("updateStatus: [id: {}, status: {}]", id, status);

        Product product = productService.getProductByIDWithException(id);
        product.setProductStatus(status);
        productService.saveOrUpdate(product);
        return Response.SUCCESS;
    }

    @PostMapping("page")
    public Response page(@RequestBody PageDTO pageDTO) {

        logger.info("page: [dto: {}]", pageDTO);

        IPage<Product> productIPage = productService.page(new Page<>(pageDTO.getCurrent(),
                        pageDTO.getSize()),
                new LambdaQueryWrapper<Product>().like(Product::getName,
                        pageDTO.getSearchValue()).or().eq(Product::getId,
                        pageDTO.getSearchValue()).orderByDesc(Product::getUpdateTime));

        IPage<ProductDTO> productDTOIPage = productIPage.convert(product -> {
            ProductDTO productDTO = new ProductDTO();

            BeanUtils.copyProperties(product, productDTO);

            BudgetProduct budgetProduct =
                    budgetProductService.getByIDWithException(product.getBudgetProductId());

            ProductLine productLine =
                    productLineService.getByIDWithException(product.getProductLineId());

            productDTO.setProductLineName(productLine.getProductLineName());

            productDTO.setBudgetProductName(budgetProduct.getBudgetProductName());

            return productDTO;
        });

        return Response.successWithData(productDTOIPage);
    }
}
