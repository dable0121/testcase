package com.glodon.ngtrade.productcenter.tool;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Dable on 2017/4/14 19:13.
 */
public class CrmUtil {

    public static String getDigitFromString(String str) {
        String regEx="[^0-9]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        String digit = m.replaceAll("").trim();
        return digit;
    }
    //CRM不仅仅要求取数字，还要求换成整数，比如G0000185，不能0000185查询，必须185查询，同理V0000000按0查询
    public static String getDigitAndRemoveLeftZeroFromString(String str) {
        String regEx="^[0|a-z|A-Z]+";
        String digit = str.replaceAll( regEx,"").trim();
        return digit;

    }
}
