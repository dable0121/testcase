package com.glodon.ngtrade.productcenter.common;

import lombok.Getter;
import lombok.Setter;
import org.springframework.context.ApplicationEvent;

public class UpdateTimeEvent extends ApplicationEvent {

    @Getter
    @Setter
    private String moduleId;

    public UpdateTimeEvent(Object source, String moduleId) {
        super(source);
        this.moduleId = moduleId;
    }


}
