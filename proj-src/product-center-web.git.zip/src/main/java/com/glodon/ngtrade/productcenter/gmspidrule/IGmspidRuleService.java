package com.glodon.ngtrade.productcenter.gmspidrule;

import com.baomidou.mybatisplus.extension.service.IService;
import com.glodon.ngtrade.productcenter.gmspidrule.dto.GmspidRuleDTO;
import java.util.List;

/**
 * <p>
 * 助记符规则表 服务类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
public interface IGmspidRuleService extends IService<GmspidRule> {

  List<GmspidRuleDTO> getChildren();
}
