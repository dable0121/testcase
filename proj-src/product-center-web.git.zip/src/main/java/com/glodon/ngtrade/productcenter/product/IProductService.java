package com.glodon.ngtrade.productcenter.product;

import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 产品表 服务类
 * </p>
 *
 * @author dable
 * @since 2018-12-11
 */
public interface IProductService extends IService<Product> {

  String createByDTO(ProductDTO productDTO) throws InterruptedException;

  void updateByDTO(ProductDTO productDTO);

  Product getProductByDTOWithException(ProductDTO productDTO);

  Product getProductByIDWithException(String id);

  void checkProductLineExistenceWithException(ProductDTO productDTO);

  void checkBudgetProductExistenceWithException(ProductDTO productDTO);

  void fillLockAuthPid(ProductDTO productDTO);

  void checkProductNameUniqueWithException(ProductDTO productDTO);

  void checkModuleNameUniqueWithException(ProductDTO productDTO);

  String generateId();

}
