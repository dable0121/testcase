package com.glodon.ngtrade.productcenter.productauthmodule;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

@Data
public class ProductAuthModuleListDTO implements Serializable {

    @Valid
    @NotEmpty
    private List<ProductAuthModuleDTO> modules;

}
