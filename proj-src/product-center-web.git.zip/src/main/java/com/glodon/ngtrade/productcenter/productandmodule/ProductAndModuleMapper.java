package com.glodon.ngtrade.productcenter.productandmodule;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 产品模块关系 Mapper 接口
 * </p>
 *
 * @author dable
 * @since 2019-04-23
 */
public interface ProductAndModuleMapper extends BaseMapper<ProductAndModule> {

    int insert(ProductAndModule productAndModule);
    ProductAndModule selectOne(ProductAndModule productAndModule);
    List<ProductAndModule> selectByPid(String pid);
    List<ProductAndModule> selectByMid(String mid);
    List<ProductAndModule> selectByMids(List<String> mids);
}
