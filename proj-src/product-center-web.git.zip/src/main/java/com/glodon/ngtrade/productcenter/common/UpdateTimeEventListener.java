package com.glodon.ngtrade.productcenter.common;

import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModule;
import com.glodon.ngtrade.productcenter.productauthmodule.impl.ProductAuthModuleServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Component
public class UpdateTimeEventListener implements ApplicationListener<UpdateTimeEvent> {

    @Autowired
    ProductAuthModuleServiceImpl productAuthModuleService;

    @Override
    @Transactional
    public void onApplicationEvent(UpdateTimeEvent event) {
        ProductAuthModule update = new ProductAuthModule();
        update.setId(event.getModuleId());
        update.setUpdateTime(LocalDateTime.now());
        productAuthModuleService.updateById(update);
    }
}
