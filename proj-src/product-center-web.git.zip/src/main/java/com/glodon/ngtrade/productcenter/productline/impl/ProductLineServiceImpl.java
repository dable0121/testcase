package com.glodon.ngtrade.productcenter.productline.impl;

import com.glodon.ngtrade.productcenter.productline.ProductLine;
import com.glodon.ngtrade.productcenter.productline.ProductLineMapper;
import com.glodon.ngtrade.productcenter.productline.IProductLineService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 产品线表 服务实现类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@Service
public class ProductLineServiceImpl extends ServiceImpl<ProductLineMapper, ProductLine> implements IProductLineService {

  @Override
  public ProductLine getByIDWithException(Integer productLineId) {
    ProductLine productLine = getById(productLineId);
    if (null == productLine) {
      throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND);
    }

    return productLine;
  }
}
