package com.glodon.ngtrade.productcenter.budgetproduct.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.glodon.ngtrade.productcenter.budgetproduct.BudgetProduct;
import com.glodon.ngtrade.productcenter.budgetproduct.BudgetProductMapper;
import com.glodon.ngtrade.productcenter.budgetproduct.IBudgetProductService;
import com.glodon.ngtrade.productcenter.budgetproduct.dto.BudgetProductDTO;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 预算产品表 服务实现类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@Service
public class BudgetProductServiceImpl extends
    ServiceImpl<BudgetProductMapper, BudgetProduct> implements IBudgetProductService {

  @Override
  public IPage<BudgetProductDTO> selectPage(Page page) {
    PageHelper.startPage((int) page.getCurrent(), (int) page.getSize());
    List<BudgetProductDTO> budgetProductDTOS = baseMapper.selectDtoPage();
    PageInfo<BudgetProductDTO> pageInfo = new PageInfo<>(budgetProductDTOS);
    page.setRecords(pageInfo.getList());
    page.setTotal(pageInfo.getTotal());
    page.setPages(pageInfo.getPages());
    return page;
  }

  @Override
  public BudgetProduct getByIDWithException(Integer budgetProductId) {
    BudgetProduct budgetProduct = getById(budgetProductId);

    if (null == budgetProduct) {
      throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND);
    }

    return budgetProduct;
  }
}
