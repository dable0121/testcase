package com.glodon.ngtrade.productcenter.gmspidrule;

import com.glodon.ngtrade.productcenter.gmspidrule.GmspidRule;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 助记符规则表 Mapper 接口
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
public interface GmspidRuleMapper extends BaseMapper<GmspidRule> {

}
