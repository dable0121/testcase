package com.glodon.ngtrade.productcenter.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserService {
    @Autowired
    private UserRoleMapper mapper;
    private final static Logger logger = LoggerFactory.getLogger(UserService.class);
    /**
     * authentication from user center
     *
     * @return authenticate result.
     * Y: yes
     * N: no
     * L: lock
     */
    public String verify(String username, String password) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://home.glodon.com:7783/Utilities/Account/ProxyService/SsoAuthUserProcess?wsdl";
        String requestBody = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sso=\"http://www.glodon.com/xsd/SsoAuthUser\">\n" +
                "    <soapenv:Header/>\n" +
                "    <soapenv:Body>\n" +
                "        <sso:SsoAuthUserRequest>\n" +
                "            <sso:userCode>{0}</sso:userCode>\n" +
                "            <sso:password><![CDATA[{1}]]></sso:password>\n" +
                "        </sso:SsoAuthUserRequest>\n" +
                "    </soapenv:Body>\n" +
                "</soapenv:Envelope>";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        HttpEntity<String> entity = new HttpEntity<>(MessageFormat.format(requestBody, username, password), headers);

        String result = restTemplate.postForObject(url, entity, String.class);
        logger.info("the authentication result from user is "+ result);
        if(result !=null && result.length()>0){
            String substring = result.substring(result.indexOf("<result>")+"<result>".length(), result.indexOf("</result>"));
            return substring.trim();
        }
        return null;
    }
    /**
     * 获取当前用户信息
     *
     * @return
     */
    public User currentUser() {
        // 1. get the current login user
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String userName = principal.toString(); // 获取当前登录用户
        if (principal == null) {
            return null;
        } else {
            // 2. get the roles
            List<String> roles = findRolesByUserName(principal.toString());
            return new User(userName, roles);
        }
    }

    /**
     * 根据用户名查询角色
     *
     * @param userName
     * @return
     */
    List<String> findRolesByUserName(String userName) {
        List<String> result = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("user_name", userName);
        List<UserRole> userRoles = mapper.selectByMap(map);
        if (userRoles != null && userRoles.size() > 0) {
            userRoles.forEach(userRole -> result.add(userRole.getRoleName()));
        }
        return result;
    }

}
