package com.glodon.ngtrade.productcenter.security;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    private UserService service;

    /**
     * 登录
     */
    @PostMapping("login")
    public Response login(HttpServletRequest request, @RequestBody String json) throws IOException {
        JsonNode jsonNode = new ObjectMapper().readTree(json);
        String username = jsonNode.get("username").asText();
        String password = jsonNode.get("password").asText();
        String authenticationResult = service.verify(username, password);
        if ("Y".equalsIgnoreCase(authenticationResult)) {
            List<String> rolesByUserName = service.findRolesByUserName(username);
            List<GrantedAuthority> authorities = new ArrayList<>();
            rolesByUserName.forEach(role -> authorities.add(new SimpleGrantedAuthority(role)));
            SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(username, password, authorities));
            request.getSession().setAttribute("SPRING_SECURITY_CONTEXT", SecurityContextHolder.getContext());
            return Response.SUCCESS;
        } else if ("N".equalsIgnoreCase(authenticationResult)) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.LOGIN_FAIL);
        } else if ("L".equalsIgnoreCase(authenticationResult)) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.USER_LOCKED);
        } else {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.NET_CALL_ERROR);
        }
    }

    /**
     * 登出
     */
    @GetMapping("logout")
    public Response logout(HttpServletRequest request) {
        // clear security context
        SecurityContextHolder.clearContext();
        // clear session
        HttpSession session = request.getSession();
        if (session != null) {
            session.invalidate();
        }
        // clear cookie
        for (Cookie cookie : request.getCookies()) {
            cookie.setMaxAge(0);
        }
        return Response.SUCCESS;
    }

    /**
     * 获取用户信息
     */
    @GetMapping("account")
    public Response account() {
        return Response.successWithData(service.currentUser());
    }
}
