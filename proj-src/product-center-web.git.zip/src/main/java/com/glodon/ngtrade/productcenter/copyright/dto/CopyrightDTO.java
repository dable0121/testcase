package com.glodon.ngtrade.productcenter.copyright.dto;

import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModule;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class CopyrightDTO implements Serializable {

  private Integer id;

  /**
   * 著作权编号
   */
  private String copyrightCode;

  /**
   * 著作权名称
   */
  private String copyrightName;

  /**
   * 是否停用：0否1是
   */
  private Boolean isStop;

  private LocalDateTime createTime;

  private LocalDateTime updateTime;

  private List<ProductAuthModule> productAuthModuleDTOS;
}
