package com.glodon.ngtrade.productcenter.copyright;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.glodon.ngtrade.productcenter.copyright.Copyright;
import com.baomidou.mybatisplus.extension.service.IService;
import com.glodon.ngtrade.productcenter.copyright.dto.SearchDTO;

/**
 * <p>
 * 著作权表 服务类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
public interface ICopyrightService extends IService<Copyright> {
  IPage page(SearchDTO page);
}
