package com.glodon.ngtrade.productcenter.typegmspid;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 助记符表
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TypeGmspid implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;


    private Integer gmspidRuleId;

    /**
     * 类型标识
     */
    private String type;

    /**
     * gmspid
     */
    private String gmspid;
    /**
     * 锁授权产品标识(助记符)
     */
    private String lockAuthPid;
    private String outPid;
    private String outMid;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;
}
