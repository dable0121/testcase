package com.glodon.ngtrade.productcenter.budgetproduct;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.glodon.ngtrade.productcenter.budgetproduct.BudgetProduct;
import com.baomidou.mybatisplus.extension.service.IService;
import com.glodon.ngtrade.productcenter.budgetproduct.dto.BudgetProductDTO;

/**
 * <p>
 * 预算产品表 服务类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
public interface IBudgetProductService extends IService<BudgetProduct> {

  /**
   * 分页查询
   * @param page 页数
   * @return 分页
   */
  IPage<BudgetProductDTO> selectPage(Page page);


  BudgetProduct getByIDWithException(Integer budgetProductId);
}
