package com.glodon.ngtrade.productcenter.productauthmodule.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.glodon.ngtrade.productcenter.common.UpdatePublish;
import com.glodon.ngtrade.productcenter.copyright.Copyright;
import com.glodon.ngtrade.productcenter.copyright.CopyrightMapper;
import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuota;
import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuotaDTO;
import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuotaMapper;
import com.glodon.ngtrade.productcenter.moduleauthquota.impl.ModuleAuthQuotaServiceImpl;
import com.glodon.ngtrade.productcenter.productandmodule.ProductAndModule;
import com.glodon.ngtrade.productcenter.productandmodule.impl.ProductAndModuleServiceImpl;
import com.glodon.ngtrade.productcenter.productauthmodule.IProductAuthModuleService;
import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModule;
import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModuleDTO;
import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModuleMapper;
import com.glodon.ngtrade.productcenter.typegmspid.TypeGmspid;
import com.glodon.ngtrade.productcenter.typegmspid.impl.TypeGmspidServiceImpl;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author dable
 * @since 2019-01-02
 */
@Service("productModuleService")
public class ProductAuthModuleServiceImpl extends ServiceImpl<ProductAuthModuleMapper,
        ProductAuthModule> implements IProductAuthModuleService {

    @Autowired
    private ProductAuthModuleMapper productAuthModuleMapper;

    @Autowired
    private ModuleAuthQuotaMapper moduleAuthQuotaMapper;

    @Autowired
    private TypeGmspidServiceImpl typeGmspidService;
    @Autowired
    private CopyrightMapper copyrightMapper;
    @Autowired
    private ModuleAuthQuotaServiceImpl moduleAuthQuotaService;

    @Autowired
    private ProductAndModuleServiceImpl productAndModuleService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createByDTO(List<ProductAuthModuleDTO> modules) {
        for (ProductAuthModuleDTO productAuthModuleDTO : modules) {

            ProductAuthModule duplicateNameModule =
                    productAuthModuleMapper.selectOne(new LambdaQueryWrapper<ProductAuthModule>().eq(ProductAuthModule::getAuthName, productAuthModuleDTO.getAuthName()));
            if (null != duplicateNameModule) {
                throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_UNIQUE.getCode(),
                        "模块名称不可以重复:" + productAuthModuleDTO.getAuthName());
            }

            String mid = generateId();

            ProductAuthModule productAuthModule = new ProductAuthModule();

            BeanUtils.copyProperties(productAuthModuleDTO, productAuthModule);
            productAuthModule.setId(mid);

            productAuthModuleMapper.insert(productAuthModule);
            ProductAndModule pm = new ProductAndModule();
            pm.setPid(productAuthModuleDTO.getPid());
            pm.setMid(mid);
            if (productAndModuleService.selectOne(pm) == null) {
                productAndModuleService.insert(pm);
            } else {
                throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_UNIQUE,
                        "产品模块关系已经存在了");
            }
            List<ModuleAuthQuotaDTO> moduleAuthQuotaDTOS =
                    productAuthModuleDTO.getModuleAuthQuotaDTOS();
            if (moduleAuthQuotaDTOS.size() != moduleAuthQuotaDTOS.stream().map(e -> e.getMid()).distinct().collect(Collectors.toList()).size()) {
                throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_UNIQUE.getCode(),
                        "mid重复");
            }

            for (ModuleAuthQuotaDTO moduleAuthTemplateDTO : moduleAuthQuotaDTOS) {

                ModuleAuthQuota existTemplate =
                        moduleAuthQuotaMapper.selectOne(new LambdaQueryWrapper<ModuleAuthQuota>().eq(ModuleAuthQuota::getMid, moduleAuthTemplateDTO.getMid()));

                if (null != existTemplate) {
                    throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_UNIQUE.getCode(),
                            "mid标识已经存在: " + existTemplate.getMid());
                }

                String tid = moduleAuthQuotaService.generateId();

                ModuleAuthQuota moduleAuthQuota = new ModuleAuthQuota();

                BeanUtils.copyProperties(moduleAuthTemplateDTO, moduleAuthQuota);
                moduleAuthQuota.setId(tid);
                moduleAuthQuota.setMid(mid);

                moduleAuthQuotaMapper.insert(moduleAuthQuota);
            }
        }
    }


    /**
     * M打头+7位数字
     */
    public String generateId() {
        final String FORMAT = "M%07d";
        List<ProductAuthModule> productAuthModules =
                list(new LambdaQueryWrapper<ProductAuthModule>().orderByDesc(ProductAuthModule::getId).last("limit 1"));
        if (productAuthModules.isEmpty()) {
            return String.format(FORMAT, 1);
        }
        String id = productAuthModules.get(0).getId();
        if (Long.valueOf("9999999").compareTo(Long.parseLong(id.substring(1))) < 0) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_UNIQUE.getCode(), "您的模块id已经满了:超过9999999" +
                    "，请联系管理员解决");
        }
        return String.format(FORMAT, Long.parseLong(id.substring(1)) + 1);
    }

    @Override
    public void fillLockAuthPid(List<ProductAuthModuleDTO> modules) {
        for (ProductAuthModuleDTO moduleDTO : modules) {
            if (moduleDTO.getNewLockAuthPid()) {
                TypeGmspid typeGmspid =
                        typeGmspidService.genTypeGmspid(moduleDTO.getNewLockAuthRuleId(),
                                moduleDTO.getOutProductId(), moduleDTO.getOutModuleId());
                moduleDTO.setLockAuthPid(typeGmspid.getType() + typeGmspid.getGmspid());
                moduleDTO.setNewLockAuthRuleId(moduleDTO.getNewLockAuthRuleId());
            } else {
                if (StringUtils.isNotBlank(moduleDTO.getLockAuthPid())) {
                    TypeGmspid typeGmspid =
                            typeGmspidService.getOne(new LambdaQueryWrapper<TypeGmspid>().eq(TypeGmspid::getType, moduleDTO.getLockAuthPid().substring(0, 1)).eq(TypeGmspid::getGmspid, moduleDTO.getLockAuthPid().substring(1)));
                    if (null == typeGmspid) {
                        throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND.getCode(), "助记符不存在:" + moduleDTO.getLockAuthPid());
                    }
                    moduleDTO.setNewLockAuthRuleId(typeGmspid.getGmspidRuleId());
                }
            }
        }
    }

    @Autowired
    UpdatePublish updatePublish;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void addCopyRight(String id, String copyRightCode, String copyRightName) {
        Copyright copyright =
                copyrightMapper.selectOne(new LambdaQueryWrapper<Copyright>().eq(Copyright::getCopyrightCode, copyRightCode).eq(Copyright::getCopyrightName, copyRightName));
        if (null == copyright) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND.getCode(),
                    "著作权不存在" + copyRightCode);
        }
        ProductAuthModule productAuthModule = getById(id);
        if (null == productAuthModule) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND.getCode(),
                    "模块不存在" + id);
        }
        if (StringUtils.isNotBlank(productAuthModule.getCopyrightCode()) || StringUtils.isNotBlank(productAuthModule.getCopyrightName())) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_UNIQUE.getCode(),
                    "著作权已经存在" + id);
        }
        productAuthModule.setCopyrightCode(copyRightCode);
        productAuthModule.setCopyrightName(copyRightName);
        productAuthModuleMapper.updateById(productAuthModule);
        updatePublish.updateModuleTime(id);
    }

    @Override
    public boolean hasModuleName(String productId, String moduleName) {
        List<ProductAndModule> productAndModules = productAndModuleService.selectByPid(productId);
        if (productAndModules.isEmpty()) {
            //没有关联模块，新增
            return false;
        }
        List<ProductAuthModule> productAuthModules = productAuthModuleMapper.selectBatchIds(productAndModules.stream().map(ProductAndModule::getMid).collect(Collectors.toList()));
        if (productAuthModules.isEmpty()) {
            return false;
        }
        boolean b = productAuthModules.stream().anyMatch(m -> m.getAuthName().equals(moduleName));

        List<ProductAuthModule> list = list(new LambdaQueryWrapper<ProductAuthModule>().eq(ProductAuthModule::getAuthName, moduleName));
        if (!list.isEmpty()) {
            b = true;
        }
        return b;
    }

    @Override
    public void getAuthModuleByIDWithException(String moduleId) {
        ProductAuthModule productAuthModule = productAuthModuleMapper.selectById(moduleId);
        if (productAuthModule == null) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.ERROR, "授权模块id不存在");
        }
    }

    @Override
    public Response getPageModule(Map map) {
        if (map.get("pageSize") == null || map.get("pageNum") == null) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.PARAMETER_NOT_FOUND);
        }
        if ((int) map.get("pageNum") < 1) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.PARAMETER_NOT_VALID);
        }
        Page page = new Page();
        page.setCurrent(Long.valueOf((Integer) map.get("pageNum")));
        page.setSize(Long.valueOf((Integer) map.get("pageSize")));
        Page<ProductAuthModuleDTO> modulePage = productAuthModuleMapper.getModulePage(page,
                map.get("productId") == null ? null : (String) map.get("productId"), map.get("moduleName") == null ? null : (String) map.get("moduleName"),
                map.get("lockAuthPid") == null ? null : (String) map.get("lockAuthPid"));
        return Response.successWithData(modulePage);
    }

    @Override
    public Response listPage(Map map) {
        if (map.get("pageSize") == null || map.get("pageNum") == null) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.PARAMETER_NOT_FOUND);
        }
        if ((int) map.get("pageNum") < 1) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.PARAMETER_NOT_VALID);
        }
        Page page = new Page();
        page.setCurrent(Long.valueOf((Integer) map.get("pageNum")));
        page.setSize(Long.valueOf((Integer) map.get("pageSize")));
        Page<ProductAuthModuleDTO> modulePage = productAuthModuleMapper.listPage(page,
                map.get("searchValue") == null ? null : (String) map.get("searchValue"));
        typeGmspidService.addRuleName(modulePage.getRecords());
        return Response.successWithData(modulePage);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, isolation = Isolation.REPEATABLE_READ)
    public Response copyright(Map map) {
        ProductAuthModule m = new ProductAuthModule();
        List<String> mids;
        if (map.get("productModuleIds") != null && !((List<String>) map.get(
                "productModuleIds")).isEmpty()) {
            mids = (List<String>) map.get(
                    "productModuleIds");
        } else {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.PARAMETER_NOT_FOUND);
        }
        if (map.get("copyrightName") != null && StringUtils.isNotBlank((String) map.get("copyrightName"))) {
            m.setCopyrightName((String) map.get("copyrightName"));
        } else {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.PARAMETER_NOT_FOUND);
        }
        if (map.get("copyrightCode") != null && StringUtils.isNotBlank((String) map.get("copyrightCode"))) {
            m.setCopyrightCode((String) map.get("copyrightCode"));
        } else {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.PARAMETER_NOT_FOUND);
        }
        m.setUpdateTime(LocalDateTime.now());
        productAuthModuleMapper.update(m,
                new UpdateWrapper<ProductAuthModule>().lambda().in(ProductAuthModule::getId,
                        mids));
        return Response.SUCCESS;
    }
}
