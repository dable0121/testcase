package com.glodon.ngtrade.productcenter.productandmodule;

import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 产品模块关系 服务类
 * </p>
 *
 * @author dable
 * @since 2019-04-23
 */
public interface IProductAndModuleService extends IService<ProductAndModule> {
    int insert(ProductAndModule productAndModule);
    ProductAndModule selectOne(ProductAndModule productAndModule);
    List<ProductAndModule> selectByPid(String pid);
    List<ProductAndModule> selectByMid(String mid);
    List<ProductAndModule> selectByMids(List<String> mids);
    int delByMap(Map<String, Object> columnMap);
}
