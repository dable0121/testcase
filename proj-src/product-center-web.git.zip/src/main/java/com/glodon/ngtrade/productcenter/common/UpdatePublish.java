package com.glodon.ngtrade.productcenter.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
public class UpdatePublish {
    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;

    public void updateModuleTime(String moduleId) {
        UpdateTimeEvent event = new UpdateTimeEvent(this, moduleId);
        applicationEventPublisher.publishEvent(event);
    }

}
