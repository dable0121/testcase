package com.glodon.ngtrade.productcenter.productandmodule;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 产品模块关系 前端控制器
 * </p>
 *
 * @author dable
 * @since 2019-04-23
 */
@RestController
@RequestMapping("/product-and-module")
public class ProductAndModuleController {

}

