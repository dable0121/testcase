package com.glodon.ngtrade.productcenter.productline;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.glodon.ngtrade.productcenter.productline.impl.ProductLineServiceImpl;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 产品线表 前端控制器
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@RestController
@RequestMapping("/api/product-line")
public class ProductLineController  {

  @Autowired
  ProductLineServiceImpl productLineService;

  /**
   * 创建或者修改
   * @param pl
   * @return
   */
  @PostMapping("addupdate")
  public Response addUpdate(@RequestBody ProductLine pl) {
    //判断名称是否重复
    QueryWrapper<ProductLine> queryWrapper = new QueryWrapper<>();
    if(StringUtils.isNotBlank(pl.getProductLineName())){
      queryWrapper.lambda().eq(ProductLine::getProductLineName, pl.getProductLineName());
      int count = productLineService.count(queryWrapper);
      if(count>0){
        throw NgtradeException.exception(MessageCode.MessageCodeEnum.NAME_REPEAT,"产品线名称");
      }
    }
    pl.setUpdateTime(LocalDateTime.now());
    boolean b = productLineService.saveOrUpdate(pl);
    return b ? Response.successWithData(pl)
        : Response.getErrorResponseWithNoArgs(MessageCode.MessageCodeEnum.DB_INSERT_UPDATE_ERROR);
  }

  /**
   * 列表：不分页 && 支持状态查询、全部查询
   * @param isStop
   * @return
   */
  @GetMapping("list")
  public Response list(@RequestParam(value = "isStop",required = false) Boolean isStop) {
    QueryWrapper<ProductLine> queryWrapper = new QueryWrapper<>();
    if(isStop!=null){
      queryWrapper.lambda().eq(ProductLine::getIsStop, isStop);
    }
    List<ProductLine> list = productLineService.list(queryWrapper);
    return Response.successWithData(list);
  }
}

