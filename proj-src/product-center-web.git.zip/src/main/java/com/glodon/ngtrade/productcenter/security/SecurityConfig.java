package com.glodon.ngtrade.productcenter.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;

@Configuration
@EnableWebSecurity
@Conditional(NoSecurityConfigCondition.class)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private ApplicationContext context;
    private final static Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        String property = context.getEnvironment().getProperty("security.disabled");
        logger.info("security.disabled = [{}]", property);
        if (property == null || property.length() == 0) {
            http.csrf().disable()
                    .authorizeRequests()
                        .antMatchers("/actuator/**").permitAll()
                        .antMatchers("/api/login","/api/logout").permitAll()
                        .antMatchers("/api/account").authenticated()
                        .anyRequest().hasAnyRole("ADMIN")
                    .and()
                    .exceptionHandling().authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED));
        } else {
            http.csrf().disable()
                    .authorizeRequests()
                    .anyRequest().permitAll();
        }
    }

}
