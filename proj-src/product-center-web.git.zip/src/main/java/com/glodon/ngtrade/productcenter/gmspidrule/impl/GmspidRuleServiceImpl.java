package com.glodon.ngtrade.productcenter.gmspidrule.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.glodon.ngtrade.productcenter.gmspidrule.GmspidRule;
import com.glodon.ngtrade.productcenter.gmspidrule.GmspidRuleMapper;
import com.glodon.ngtrade.productcenter.gmspidrule.IGmspidRuleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.glodon.ngtrade.productcenter.gmspidrule.dto.GmspidRuleDTO;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 助记符规则表 服务实现类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@Service
public class GmspidRuleServiceImpl extends ServiceImpl<GmspidRuleMapper, GmspidRule> implements IGmspidRuleService {

  @Override
  public List<GmspidRuleDTO> getChildren() {
    GmspidRuleDTO current = new GmspidRuleDTO();
    current.setId(0);
    recursion(current);
    return current.getChilds();
  }

  private void recursion(GmspidRuleDTO current){
    //查询子集
    QueryWrapper<GmspidRule> queryWrapper = new QueryWrapper<>();
    queryWrapper.lambda().eq(GmspidRule::getParentId,current.getId());
    List<GmspidRule> list = baseMapper.selectList(queryWrapper);
    if(!list.isEmpty()){
      //不为空转换，设置子集
      List<GmspidRuleDTO> child = new ArrayList<>();
      for (GmspidRule gr: list){
        GmspidRuleDTO gmspidRuleDTO = new GmspidRuleDTO();
        BeanUtils.copyProperties(gr,gmspidRuleDTO);
        //查询当前子集并设置
        recursion(gmspidRuleDTO);
        child.add(gmspidRuleDTO);
      }
      //设置子集
      current.setChilds(child);
    }
  }

}
