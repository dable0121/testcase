package com.glodon.ngtrade.productcenter.typegmspid;

import com.glodon.ngtrade.productcenter.budgetproduct.dto.BudgetProductDTO;
import com.glodon.ngtrade.productcenter.typegmspid.TypeGmspid;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.glodon.ngtrade.productcenter.typegmspid.dto.TypeGmspidDTO;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 助记符表 Mapper 接口
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
public interface TypeGmspidMapper extends BaseMapper<TypeGmspid> {
  /**
   * 多表分页
   * @return
   */
  List<TypeGmspidDTO> selectDtoPageWithSearch(@Param(value = "searchValue") String searchValue);
}
