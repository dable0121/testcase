package com.glodon.ngtrade.productcenter.typegmspid.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.glodon.ngtrade.productcenter.copyright.dto.SearchDTO;
import com.glodon.ngtrade.productcenter.gmspidrule.GmspidRule;
import com.glodon.ngtrade.productcenter.gmspidrule.GmspidRuleMapper;
import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModuleDTO;
import com.glodon.ngtrade.productcenter.typegmspid.ITypeGmspidService;
import com.glodon.ngtrade.productcenter.typegmspid.TypeGmspid;
import com.glodon.ngtrade.productcenter.typegmspid.TypeGmspidMapper;
import com.glodon.ngtrade.productcenter.typegmspid.dto.Pager;
import com.glodon.ngtrade.productcenter.typegmspid.dto.TypeGmspidDTO;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 助记符表 服务实现类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@Service
public class TypeGmspidServiceImpl extends ServiceImpl<TypeGmspidMapper, TypeGmspid> implements
        ITypeGmspidService {

    @Autowired
    private GmspidRuleMapper gmspidRuleMapper;

    @Autowired
    private TypeGmspidMapper typeGmspidMapper;

    @Override
    public TypeGmspid getByIDWithException(Integer id) {
        TypeGmspid typeGmspid = getById(id);

        if (null == typeGmspid) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND);
        }

        return typeGmspid;
    }


    @Override
    @Transactional(isolation = Isolation.SERIALIZABLE, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public TypeGmspid genTypeGmspid(Integer gmspidRuleId, String outPid, String outMid) {
        //获取助记符类型
        GmspidRule gr = gmspidRuleMapper.selectById(gmspidRuleId);
        if (null == gr) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND);
        }
        String type = gr.getType();
        //根据规则获取gmspid
        String start = gr.getGmspidStart();
        String end = gr.getGmspidEnd();
        if (StringUtils.isBlank(start) && StringUtils.isBlank(end)) {
            GmspidRule parent = gmspidRuleMapper.selectById(gr.getParentId());
            start = parent.getGmspidStart();
            end = parent.getGmspidEnd();
        }
        if (StringUtils.isBlank(start) && StringUtils.isBlank(end)) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.TYPE_GMSPID_START_END_NULL);
        }
        //查询当前类型的助记符
        QueryWrapper<TypeGmspid> q = new QueryWrapper();
        q.lambda().eq(TypeGmspid::getType, type);
        List<TypeGmspid> typeGmspids = typeGmspidMapper.selectList(q);
        List<Integer> ls2 = typeGmspids.isEmpty() ? new ArrayList<>(1)
                : typeGmspids.stream().map(t -> Integer.valueOf(t.getGmspid())).collect(
                Collectors.toList());
        List<Integer> ls1 = new ArrayList<>(Integer.valueOf(end) + 1 - Integer.valueOf(start));
        Integer integer = Integer.valueOf(start);
        for (int i = 0; i < Integer.valueOf(end) + 1 - Integer.valueOf(start); i++) {
            ls1.add(integer);
            integer = integer + 1;
        }
        //取差集
        List<Integer> sort = diff(ls1, ls2);
        if (sort.isEmpty()) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.TYPE_GMSPID_GET_ERROW);
        } else {
            String s = sort.get(0).toString();
            TypeGmspid tg = new TypeGmspid();
            tg.setGmspidRuleId(gr.getId());
            tg.setType(type);
            tg.setGmspid(s);
            if (StringUtils.isNotBlank(outPid)) {
                tg.setOutPid(outPid);
            }
            if (StringUtils.isNotBlank(outMid)) {
                tg.setOutMid(outMid);
            }
            tg.setLockAuthPid(type + s);
            int insert = typeGmspidMapper.insert(tg);
            return insert == 1 ? tg : null;
        }
    }

    /**
     * 差集并排序
     */
    private List<Integer> diff(List<Integer> ls1, List<Integer> ls2) {
        List<Integer> list = new ArrayList(Arrays.asList(new Object[ls1.size()]));
        Collections.copy(list, ls1);
        list.removeAll(ls2);
        list.sort(Integer::compareTo);
        return list;
    }

    @Override
    public IPage<TypeGmspidDTO> page(SearchDTO searchDTO) {
        IPage<TypeGmspidDTO> page = new Page<>();
        if (StringUtils.isNotBlank(searchDTO.getCurrent())) {
            page.setCurrent(Long.valueOf(searchDTO.getCurrent()));
        }
        if (StringUtils.isNotBlank(searchDTO.getSize())) {
            page.setSize(Long.valueOf(searchDTO.getSize()));
        }
        List<TypeGmspidDTO> typeGmspidDTOS = typeGmspidMapper
                .selectDtoPageWithSearch(searchDTO.getSearchValue());
        if (!typeGmspidDTOS.isEmpty()) {
            Pager<TypeGmspidDTO> p = Pager.create(typeGmspidDTOS, (int) page.getSize());
            page.setRecords(p.getPagedList((int) page.getCurrent()));
            page.setTotal((long) p.getPageNums());
            page.setPages(p.getPages());
            addParentRuleName(page.getRecords());
        }
        return page;
    }

    private void addParentRuleName(List<TypeGmspidDTO> list) {
        for (TypeGmspidDTO dto : list) {
            if (dto.getGmspRuleId() != null && dto.getGmspRuleId().intValue() != 0) {
                GmspidRule gr = gmspidRuleMapper.selectById(dto.getGmspRuleId());
                recursion(gr);
                dto.setTypeName(gr.getTypeName());
            }
        }
    }

    private void recursion(GmspidRule gr) {
        if (gr.getParentId().intValue() != 0) {
            GmspidRule parent = gmspidRuleMapper.selectById(gr.getParentId());
            gr.setTypeName(parent.getTypeName() + "-" + gr.getTypeName());
            gr.setParentId(parent.getParentId());
            recursion(gr);
        }
    }

    public void addRuleName(List<ProductAuthModuleDTO> list) {
        for (ProductAuthModuleDTO dto : list) {
            if (dto.getNewLockAuthRuleId() != null && dto.getNewLockAuthRuleId().intValue() != 0) {
                GmspidRule gr = gmspidRuleMapper.selectById(dto.getNewLockAuthRuleId());
                recursion(gr);
                dto.setRuleTypeName(gr.getTypeName());
            }
        }
    }


}
