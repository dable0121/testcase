package com.glodon.ngtrade.productcenter.product;

import java.time.LocalDateTime;
import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 产品表
 * </p>
 *
 * @author dable
 * @since 2018-12-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Product implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * 产品ID
   */
  private String id;

  /**
   * 产品线ID
   */
  private Integer productLineId;

  /**
   * 预算产品ID
   */
  private Integer budgetProductId;

  /**
   * 产品名称
   */
  private String name;

  /**
   * 产品状态 1.新建 2.已发布
   */
  private Integer productStatus;

  /**
   * 创建者域账号
   */
  private String domainCreator;

  /**
   * 描述
   */
  private String description;

  /**
   * 创建时间
   */
  private LocalDateTime createTime;

  /**
   * 更新时间
   */
  private LocalDateTime updateTime;

}
