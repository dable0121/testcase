package com.glodon.ngtrade.productcenter.copyright.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.glodon.ngtrade.productcenter.copyright.Copyright;
import com.glodon.ngtrade.productcenter.copyright.CopyrightMapper;
import com.glodon.ngtrade.productcenter.copyright.ICopyrightService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.glodon.ngtrade.productcenter.copyright.dto.SearchDTO;

import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 著作权表 服务实现类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@Service
public class CopyrightServiceImpl extends ServiceImpl<CopyrightMapper, Copyright> implements ICopyrightService {

  @Override
  public IPage page(SearchDTO searchDTO) {
    QueryWrapper<Copyright> query = new QueryWrapper();
    if (StringUtils.isNotBlank(searchDTO.getSearchValue())) {
      query.lambda().eq(Copyright::getCopyrightCode, searchDTO.getSearchValue()).or().eq(Copyright::getCopyrightName, searchDTO.getSearchValue());
    }
    Page page = new Page();
    page.setSize(Long.valueOf(searchDTO.getSize()));
    page.setCurrent(Long.valueOf(searchDTO.getCurrent()));
    return baseMapper.selectPage(page, query);
  }

  public Copyright findByIDWithException(Integer id) {
    Copyright copyright = getById(id);
    if (null == copyright) {
      throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND);
    }
    return copyright;
  }
}
