package com.glodon.ngtrade.productcenter.budgetproduct;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.glodon.ngtrade.productcenter.budgetproduct.impl.BudgetProductServiceImpl;
import com.glodon.ngtrade.productcenter.productline.ProductLine;
import com.glodon.ngtrade.productcenter.productline.impl.ProductLineServiceImpl;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 预算产品表 前端控制器
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@RestController
@RequestMapping("/api/budget-product")
public class BudgetProductController {

  @Autowired
  BudgetProductServiceImpl budgetProductService;

  @Autowired
  ProductLineServiceImpl productLineService;

  @GetMapping("/{id}/productLine")
  public Response productLine(@PathVariable Integer id) {

    BudgetProduct budgetProduct = budgetProductService.getById(id);

    ProductLine productLine = productLineService.getById(budgetProduct.getProductLineId());

    return Response.successWithData(productLine);
  }

  /**
   * 创建或者修改
   */
  @PostMapping("addupdate")
  public Response addUpdate(@RequestBody BudgetProduct bp) {
    //判断名称是否重复
    QueryWrapper<BudgetProduct> queryWrapper = new QueryWrapper<>();
    if (StringUtils.isNotBlank(bp.getBudgetProductName())) {
      queryWrapper.lambda().eq(BudgetProduct::getBudgetProductName, bp.getBudgetProductName());
      int count = budgetProductService.count(queryWrapper);
      if (count > 0) {
        throw NgtradeException.exception(MessageCode.MessageCodeEnum.NAME_REPEAT, "预算产品名称");
      }
    }
    bp.setUpdateTime(LocalDateTime.now());
    boolean b = budgetProductService.saveOrUpdate(bp);
    return b ? Response.successWithData(bp)
        : Response.getErrorResponseWithNoArgs(MessageCode.MessageCodeEnum.DB_INSERT_UPDATE_ERROR);
  }

  /**
   * 列表分页
   */
  @PostMapping("page")
  public Response page(@RequestBody Page page) {
    IPage page1 = budgetProductService.selectPage(page);
    return Response.successWithData(page1);
  }


  /**
   * 列表：不分页 && 支持状态查询、全部查询
   */
  @GetMapping("list")
  public Response list(@RequestParam(value = "isStop", required = false) Boolean isStop) {
    QueryWrapper<BudgetProduct> queryWrapper = new QueryWrapper<>();
    if (isStop != null) {
      queryWrapper.lambda().eq(BudgetProduct::getIsStop, isStop);
    }
    List<BudgetProduct> list = budgetProductService.list(queryWrapper);
    return Response.successWithData(list);
  }
}

