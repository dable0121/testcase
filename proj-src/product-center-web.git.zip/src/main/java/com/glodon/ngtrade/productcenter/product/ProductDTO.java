package com.glodon.ngtrade.productcenter.product;

import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModuleDTO;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 产品表
 * </p>
 *
 * @author dable
 * @since 2018-12-11
 */
@Data
public class ProductDTO implements Serializable {

  private static final long serialVersionUID = 1L;

  /**
   * 产品ID
   */
  private String id;

  /**
   * 产品线ID
   */
  @NotNull
  private Integer productLineId;

  /**
   * 产品线名称
   */
  private String productLineName;

  /**
   * 预算产品ID
   */
  @NotNull
  private Integer budgetProductId;

  /**
   * 预算产品
   */
  private String budgetProductName;

  /**
   * 产品名称
   */
  @NotBlank
  @Length(max = 255)
  private String name;

  /**
   * 产品状态 1.新建 2.已发布
   */
  private Integer productStatus;

  /**
   * 创建者域账号
   */
  @NotBlank
  private String domainCreator;

  /**
   * 描述
   */
  private String description;

  /**
   * 创建时间
   */
  private LocalDateTime createTime;

  /**
   * 更新时间
   */
  private LocalDateTime updateTime;

  @Valid
  /**
   * 授权模块信息
   */
  private List<ProductAuthModuleDTO> productAuthModuleDTOS;

}