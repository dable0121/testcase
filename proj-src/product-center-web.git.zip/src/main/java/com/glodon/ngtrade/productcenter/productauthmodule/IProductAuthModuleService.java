package com.glodon.ngtrade.productcenter.productauthmodule;

import com.baomidou.mybatisplus.extension.service.IService;
import com.glodon.ngtrade.util.common.response.Response;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author dable
 * @since 2019-01-02
 */
public interface IProductAuthModuleService extends IService<ProductAuthModule> {

    void createByDTO(List<ProductAuthModuleDTO> modules);

    void fillLockAuthPid(List<ProductAuthModuleDTO> modules);

    void addCopyRight(String id, String copyRightCode, String copyRightName);

    String generateId();

    boolean hasModuleName(String productId, String moduleName);

    void getAuthModuleByIDWithException(String moduleId);

    Response getPageModule(Map map);

    Response listPage(Map map);

    Response copyright(Map map);
}
