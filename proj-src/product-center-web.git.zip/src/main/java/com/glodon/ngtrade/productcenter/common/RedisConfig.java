package com.glodon.ngtrade.productcenter.common;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.commons.lang3.StringUtils;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.cache.RedisCacheWriter;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.time.Duration;

/**
 * Created by xial-a on 2017/5/17.
 */
@Configuration
public class RedisConfig {

  /**
   * 实例化redisTemplate.
   */
  @Bean
  public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory connectionFactory) {

    RedisTemplate<Object, Object> template = new RedisTemplate<>();
    template.setConnectionFactory(connectionFactory);
    template.setKeySerializer(new StringRedisSerializer());

    Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer(
        Object.class);
    ObjectMapper om = new ObjectMapper();
    om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
    om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
    jackson2JsonRedisSerializer.setObjectMapper(om);
    template.setValueSerializer(jackson2JsonRedisSerializer);

    template.setHashKeySerializer(jackson2JsonRedisSerializer);
    template.setHashValueSerializer(jackson2JsonRedisSerializer);

    return template;
  }

  @Bean
  public CacheManager redisCacheManager(RedisConnectionFactory connectionFactory,
                                        @Value("${cache.redis.default.timeout:300}") long timeout) {

    Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer(
        Object.class);
    ObjectMapper om = new ObjectMapper();
    om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
    om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
    jackson2JsonRedisSerializer.setObjectMapper(om);

    RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
        .entryTtl(Duration.ofSeconds(timeout))
        .disableCachingNullValues()
        .serializeKeysWith(RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
        .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(jackson2JsonRedisSerializer));

    RedisCacheManager cm = RedisCacheManager.builder(RedisCacheWriter.lockingRedisCacheWriter(connectionFactory))
        .cacheDefaults(config)
        .transactionAware()
        .build();

    return cm;
  }

  /**
   * redission 配置
   */
  @Bean
  public RedissonClient redissonClient(@Value("${spring.redis.host}") String host, @Value("${spring.redis.port}") String port, @Value("${spring.redis.password}") String password) {
    Config config = new Config();
    if (StringUtils.isNotBlank(password)) {
      config.useSingleServer()
          // 地址
          .setAddress(String.format("redis://%s:%s", host, port))
          // 命令等待超时，单位：毫秒
          .setTimeout(10000)
          // 连接超时，单位：毫秒
          .setConnectTimeout(10000)
          // ping超时
          .setPingTimeout(1000)
          // 命令失败重试次数
          .setRetryAttempts(3)
          // 命令重试发送时间间隔，单位：毫秒
          .setRetryInterval(1500)
          // 最小空闲连接数
          .setConnectionMinimumIdleSize(5)
          // 连接池大小
          .setConnectionPoolSize(20)
          // 密码
          .setPassword(password);
    } else {
      config.useSingleServer()
          // 地址
          .setAddress(String.format("redis://%s:%s", host, port))
          // 命令等待超时，单位：毫秒
          .setTimeout(10000)
          // 连接超时，单位：毫秒
          .setConnectTimeout(10000)
          // ping超时
          .setPingTimeout(1000)
          // 命令失败重试次数
          .setRetryAttempts(3)
          // 命令重试发送时间间隔，单位：毫秒
          .setRetryInterval(1500)
          // 最小空闲连接数
          .setConnectionMinimumIdleSize(5)
          // 连接池大小
          .setConnectionPoolSize(20);
      // 密码
    }
    RedissonClient redisson = Redisson.create(config);
    return redisson;
  }
}