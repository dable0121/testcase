package com.glodon.ngtrade.productcenter.moduleauthquota.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.glodon.ngtrade.productcenter.common.UpdatePublish;
import com.glodon.ngtrade.productcenter.moduleauthquota.IModuleAuthQuotaService;
import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuota;
import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuotaDTO;
import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuotaMapper;
import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModule;
import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModuleMapper;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author dable
 * @since 2018-12-12
 */
@Service("moduleAuthTemplateService")
public class ModuleAuthQuotaServiceImpl extends ServiceImpl<ModuleAuthQuotaMapper, ModuleAuthQuota> implements
        IModuleAuthQuotaService {

    @Autowired
    private ModuleAuthQuotaMapper moduleAuthQuotaMapper;

    @Autowired
    private ProductAuthModuleMapper productAuthModuleMapper;


    @Autowired
    UpdatePublish updatePublish;
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void createByDTO(List<ModuleAuthQuotaDTO> authTemplates) {
        for (ModuleAuthQuotaDTO moduleAuthTemplateDTO : authTemplates) {

            ProductAuthModule productAuthModule = productAuthModuleMapper.selectById(moduleAuthTemplateDTO.getMid());

            if (null == productAuthModule) {
                throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_FOUND.getCode(), "模块不存在" + moduleAuthTemplateDTO.getMid());
            }

            String tid = generateId();

            ModuleAuthQuota moduleAuthTemplate = new ModuleAuthQuota();

            BeanUtils.copyProperties(moduleAuthTemplateDTO, moduleAuthTemplate);
            moduleAuthTemplate.setId(tid);

            moduleAuthQuotaMapper.insert(moduleAuthTemplate);
            updatePublish.updateModuleTime(moduleAuthTemplate.getMid());
        }
    }

    /**
     * Q打头+7位数字
     */
    public String generateId() {
        final String FORMAT = "Q%07d";
        List<ModuleAuthQuota> moduleAuthQuotas =
                list(new LambdaQueryWrapper<ModuleAuthQuota>().orderByDesc(ModuleAuthQuota::getId).last("limit 1"));
        if (moduleAuthQuotas.isEmpty()) {
            return String.format(FORMAT, 1);
        }
        String id = moduleAuthQuotas.get(0).getId();
        if (Long.valueOf("9999999").compareTo(Long.parseLong(id.substring(1))) < 0) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.DATA_NOT_UNIQUE.getCode(), "您的配额id已经满了:超过9999999" +
                    "，请联系管理员解决");
        }
        return String.format(FORMAT, Long.parseLong(id.substring(1)) + 1);
    }
}
