package com.glodon.ngtrade.productcenter.productandmodule;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 产品模块关系
 * </p>
 *
 * @author dable
 * @since 2019-04-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ProductAndModule implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 产品id
     */
    private String pid;

    /**
     * 模块id
     */
    private String mid;


}
