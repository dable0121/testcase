package com.glodon.ngtrade.productcenter.product;

import com.glodon.ngtrade.productcenter.product.Product;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 产品表 Mapper 接口
 * </p>
 *
 * @author dable
 * @since 2018-12-11
 */
public interface ProductMapper extends BaseMapper<Product> {

}
