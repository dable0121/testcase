package com.glodon.ngtrade.productcenter.productandmodule.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.glodon.ngtrade.productcenter.productandmodule.IProductAndModuleService;
import com.glodon.ngtrade.productcenter.productandmodule.ProductAndModule;
import com.glodon.ngtrade.productcenter.productandmodule.ProductAndModuleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 产品模块关系 服务实现类
 * </p>
 *
 * @author dable
 * @since 2019-04-23
 */
@Service
public class ProductAndModuleServiceImpl extends ServiceImpl<ProductAndModuleMapper,
        ProductAndModule> implements IProductAndModuleService {
    @Autowired
    private ProductAndModuleMapper productAndModuleMapper;

    @Override
    public List<ProductAndModule> selectByPid(String pid) {
        return productAndModuleMapper.selectByPid(pid);
    }

    @Override
    public List<ProductAndModule> selectByMid(String mid) {
        return productAndModuleMapper.selectByMid(mid);
    }

    @Override
    public List<ProductAndModule> selectByMids(List<String> mids) {
        return productAndModuleMapper.selectByMids(mids);
    }

    @Override
    public int insert(ProductAndModule productAndModule) {
        return productAndModuleMapper.insert(productAndModule);
    }

    @Override
    public ProductAndModule selectOne(ProductAndModule productAndModule) {
        return productAndModuleMapper.selectOne(productAndModule);
    }

    @Override
    public int delByMap(Map<String, Object> columnMap) {
        return productAndModuleMapper.deleteByMap(columnMap);
    }
}
