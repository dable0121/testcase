package com.glodon.ngtrade.productcenter.typegmspid;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.glodon.ngtrade.productcenter.copyright.dto.SearchDTO;

/**
 * <p>
 * 助记符表 服务类
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
public interface ITypeGmspidService extends IService<TypeGmspid> {

  /**
   * 获取助记符
   */
  TypeGmspid getByIDWithException(Integer id);

  /**
   * 创建助记符
   * @param gmspidRuleId
   * @param outPid
   * @param outMid
   * @return
   */
  TypeGmspid genTypeGmspid(Integer gmspidRuleId,String outPid,String outMid);

  /**
   * 助记符搜索分页
   */
  IPage page(SearchDTO searchDTO);
}
