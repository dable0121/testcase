package com.glodon.ngtrade.productcenter.budgetproduct;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 预算产品表
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class BudgetProduct implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 产品线id
     */
    private Integer productLineId;

    /**
     * 预算产品
     */
    private String budgetProductName;

    /**
     * 是否停用：0否1是
     */
    private Boolean isStop;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;


}
