package com.glodon.ngtrade.productcenter.copyright;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 著作权表
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Copyright implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 著作权编号
     */
    private String copyrightCode;

    /**
     * 著作权名称
     */
    private String copyrightName;

    /**
     * 是否停用：0否1是
     */
    private Boolean isStop;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;


}
