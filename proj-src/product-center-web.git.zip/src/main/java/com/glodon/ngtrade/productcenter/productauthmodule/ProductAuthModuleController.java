package com.glodon.ngtrade.productcenter.productauthmodule;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.glodon.ngtrade.productcenter.common.UpdatePublish;
import com.glodon.ngtrade.productcenter.product.IProductService;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author dable
 * @since 2019-01-02
 */
@RestController
@RequestMapping("/api/product-module")
public class ProductAuthModuleController {

    private final static Logger logger = LoggerFactory.getLogger(ProductAuthModuleController.class);

    @Autowired
    private IProductAuthModuleService productModuleService;

    @Autowired
    private IProductService productService;

    @PostMapping
    public Response create(@RequestBody @Valid ProductAuthModuleListDTO modules) {

        logger.info("create[{}]", modules);
        for (ProductAuthModuleDTO productModuleDTO : modules.getModules()) {
            productService.getProductByIDWithException(productModuleDTO.getPid());
        }

        productModuleService.fillLockAuthPid(modules.getModules());

        productModuleService.createByDTO(modules.getModules());

        return Response.SUCCESS;
    }
    @Autowired
    UpdatePublish updatePublish;
    @PutMapping
    @Transactional
    public Response update(@RequestBody ProductAuthModuleDTO productAuthModuleDTO) {
        productService.getProductByIDWithException(productAuthModuleDTO.getPid());
        if (productAuthModuleDTO.getId() == null ||
                productModuleService.getById(productAuthModuleDTO.getId()) == null) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.ERROR, "授权模块更新，模块id不能为空，必须存在");
        }
        productAuthModuleDTO.setUpdateTime(LocalDateTime.now());
        ProductAuthModule productAuthModule = new ProductAuthModule();
        BeanUtils.copyProperties(productAuthModuleDTO, productAuthModule);
        boolean b = productModuleService.updateById(productAuthModule);
        updatePublish.updateModuleTime(productAuthModuleDTO.getId());
        return b ?
                Response.SUCCESS : Response.getErrorResponseWithNoArgs(MessageCode.MessageCodeEnum.DB_INSERT_UPDATE_ERROR);
    }

    @PostMapping("/{id}/addCopyRight")
    public Response addCopyRight(@PathVariable String id, @RequestParam String copyRightName,
                                 @RequestParam String copyRightCode) {

        productModuleService.addCopyRight(id, copyRightCode, copyRightName);
        return Response.SUCCESS;
    }

    @GetMapping("/hasModuleName")
    public Response hasModuleName(@RequestParam String productId,
                                  @RequestParam String moduleName) {
        return Response.successWithData(productModuleService.hasModuleName(productId, moduleName));
    }


    @PostMapping("/page")
    public Response getPageModule(@RequestBody Map map) {
        return productModuleService.getPageModule(map);
    }

    @PostMapping("/list")
    public JSONObject list(@RequestBody Map map) {
        Response response = productModuleService.listPage(map);
        return JSON.parseObject(JSON.toJSONString(response));
    }


    @PutMapping("/copyright")
    public Response copyright(@RequestBody Map map) {
        return productModuleService.copyright(map);
    }
}

