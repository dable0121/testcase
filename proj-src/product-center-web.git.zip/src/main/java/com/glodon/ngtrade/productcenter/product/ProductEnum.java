package com.glodon.ngtrade.productcenter.product;

public class ProductEnum {
  public enum ProductStatusEnum {
    NEW(1), PUBLISHED(2);

    ProductStatusEnum(Integer status) {
      this.status = status;
    }

    public Integer getStatus() {
      return status;
    }

    private Integer status;
  }

  public enum ProductTypeEnum {
    SOFTWARE(1, "程序"),
    QUOTA(2, "定额"),
    RULE(3, "规则"),
    INTERNET(4, "互联网"),
    SERVICE(5, "服务");
    private Integer type;
    private String typeName;

    ProductTypeEnum(Integer type, String typeName) {
      this.type = type;
      this.typeName = typeName;
    }

    public Integer getType() {
      return type;
    }

    public String getTypeName() {
      return typeName;
    }

    public static String getTypeNameByType(Integer type) {
      for (ProductTypeEnum productTypeEnum : values()) {
        if (productTypeEnum.type.equals(type)) {
          return productTypeEnum.typeName;
        }
      }
      return SOFTWARE.typeName;
    }
  }
}
