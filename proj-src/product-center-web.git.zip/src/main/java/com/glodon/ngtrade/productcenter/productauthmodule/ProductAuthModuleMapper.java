package com.glodon.ngtrade.productcenter.productauthmodule;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.glodon.ngtrade.productcenter.moduleauthquota.ModuleAuthQuotaDTO;
import com.glodon.ngtrade.productcenter.product.ProductDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author dable
 * @since 2019-01-02
 */
public interface ProductAuthModuleMapper extends BaseMapper<ProductAuthModule> {
    Page<ProductAuthModuleDTO> getModulePage(Page page, @Param("productId") String productId, @Param("moduleName") String moduleName, @Param("lockAuthPid") String lockAuthPid);

    List<ModuleAuthQuotaDTO> queryAllQuotas(@Param("mid") String mid);

    List<ProductDTO> qps(@Param("mid") String mid);

    Page<ProductAuthModuleDTO> listPage(Page page, @Param("searchValue") String searchValue);
}
