package com.glodon.ngtrade.productcenter.typegmspid.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class PMDTO implements Serializable {

  private String productModuleId;
  private String productId;
  private String productName;
  private String productModuleName;
}
