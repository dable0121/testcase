package com.glodon.ngtrade.productcenter.copyright.dto;

import java.io.Serializable;
import lombok.Data;

@Data
public class SearchDTO implements Serializable {

  private String searchValue;
  private String size;
  private String current;
}
