package com.glodon.ngtrade.productcenter.gmspidrule;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 助记符规则表
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class GmspidRule implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 类型名称
     */
    private String typeName;

    /**
     * 父id
     */
    private Integer parentId;

    /**
     * 描述
     */
    private String description;

    /**
     * 类型标识
     */
    private String type;

    /**
     * gmspid起始数
     */
    private String gmspidStart;

    /**
     * gmspid结束数
     */
    private String gmspidEnd;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;


}
