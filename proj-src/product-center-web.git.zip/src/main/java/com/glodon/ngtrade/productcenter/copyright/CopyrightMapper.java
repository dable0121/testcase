package com.glodon.ngtrade.productcenter.copyright;

import com.glodon.ngtrade.productcenter.copyright.Copyright;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 著作权表 Mapper 接口
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
public interface CopyrightMapper extends BaseMapper<Copyright> {

}
