package com.glodon.ngtrade.productcenter.budgetproduct;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.glodon.ngtrade.productcenter.budgetproduct.dto.BudgetProductDTO;
import java.util.List;
import org.apache.ibatis.annotations.Select;

/**
 * <p>
 * 预算产品表 Mapper 接口
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
public interface BudgetProductMapper extends BaseMapper<BudgetProduct> {

  /**
   * 多表分页
   * @return
   */
  List<BudgetProductDTO> selectDtoPage();
}
