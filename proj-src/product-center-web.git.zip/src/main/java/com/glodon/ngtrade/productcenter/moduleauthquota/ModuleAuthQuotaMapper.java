package com.glodon.ngtrade.productcenter.moduleauthquota;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author dable
 * @since 2018-12-12
 */
public interface ModuleAuthQuotaMapper extends BaseMapper<ModuleAuthQuota> {

}
