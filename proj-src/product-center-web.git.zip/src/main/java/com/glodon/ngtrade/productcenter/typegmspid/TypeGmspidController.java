package com.glodon.ngtrade.productcenter.typegmspid;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.glodon.ngtrade.productcenter.copyright.dto.SearchDTO;
import com.glodon.ngtrade.productcenter.typegmspid.dto.TypeGmspidDTO;
import com.glodon.ngtrade.productcenter.typegmspid.impl.TypeGmspidServiceImpl;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 助记符表 前端控制器
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@RestController
@RequestMapping("/api/type-gmspid")
public class TypeGmspidController {

    @Autowired
    TypeGmspidServiceImpl typeGmspidService;

    @GetMapping("/{typegmspid}")
    public Response exist(@PathVariable("typegmspid") String typegmspid) {
        if (StringUtils.isBlank(typegmspid) || typegmspid.length() < 2) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.TYPE_GMSPID_LENGTH_ERROR);
        }
        QueryWrapper<TypeGmspid> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(TypeGmspid::getType, typegmspid.substring(0, 1)).eq(TypeGmspid::getGmspid, typegmspid.substring(1));
        List<TypeGmspid> list = typeGmspidService.list(queryWrapper);
        return !list.isEmpty() && list.size() == 1 ? Response.successWithData(list.get(0).getId()) : Response.successWithData(null);
    }

    @PostMapping("/saveorupdate")
    public Response add(@RequestBody TypeGmspid typeGmspid) {
        typeGmspid.setLockAuthPid(typeGmspid.getType()+typeGmspid.getGmspid());
        boolean save = typeGmspidService.saveOrUpdate(typeGmspid);
        return save ? Response.successWithData(typeGmspid) : Response.SYSTEM_ERROR;
    }

    /**
     * 列表分页
     */
    @PostMapping("listpage")
    public Response listPage(@RequestBody SearchDTO searchDTO) {
        IPage<TypeGmspidDTO> page = typeGmspidService.page(searchDTO);
        return Response.successWithData(page);
    }

}

