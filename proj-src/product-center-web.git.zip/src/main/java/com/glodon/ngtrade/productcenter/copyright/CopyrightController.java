package com.glodon.ngtrade.productcenter.copyright;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.glodon.ngtrade.productcenter.copyright.dto.CopyrightDTO;
import com.glodon.ngtrade.productcenter.copyright.dto.SearchDTO;
import com.glodon.ngtrade.productcenter.copyright.impl.CopyrightServiceImpl;
import com.glodon.ngtrade.productcenter.productauthmodule.ProductAuthModule;
import com.glodon.ngtrade.productcenter.productauthmodule.impl.ProductAuthModuleServiceImpl;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 著作权表 前端控制器
 * </p>
 *
 * @author dable
 * @since 2018-12-10
 */
@RestController
@RequestMapping("/api/copyright")
public class CopyrightController {

    @Autowired
    CopyrightServiceImpl copyrightService;
    @Autowired
    ProductAuthModuleServiceImpl productModuleService;


    /**
     * 创建或者修改
     */
    @PostMapping("addupdate")
    public Response addUpdate(@RequestBody Copyright bp) {
        //判断名称是否重复
        if (StringUtils.isNotBlank(bp.getCopyrightName())) {
            QueryWrapper<Copyright> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().eq(Copyright::getCopyrightName, bp.getCopyrightName());
            int count = copyrightService.count(queryWrapper);
            if (count > 0) {
                throw NgtradeException.exception(MessageCode.MessageCodeEnum.NAME_REPEAT, "著作权名称");
            }
        }
        //判断编码是否重复
        if (StringUtils.isNotBlank(bp.getCopyrightCode())) {
            QueryWrapper<Copyright> queryWrapper = new QueryWrapper<>();
            queryWrapper.lambda().eq(Copyright::getCopyrightCode, bp.getCopyrightCode());
            int count = copyrightService.count(queryWrapper);
            if (count > 0) {
                throw NgtradeException.exception(MessageCode.MessageCodeEnum.NAME_REPEAT, "著作权编码");
            }
        }
        bp.setUpdateTime(LocalDateTime.now());
        boolean b = copyrightService.saveOrUpdate(bp);
        return b ? Response.successWithData(bp)
                : Response.getErrorResponseWithNoArgs(MessageCode.MessageCodeEnum.DB_INSERT_UPDATE_ERROR);
    }

    /**
     * 列表分页
     */
    @PostMapping("page")
    public Response page(@RequestBody Page page) {
        IPage<Copyright> page1 = copyrightService.page(page);
        IPage<CopyrightDTO> page2 = new Page<>();
        page2.setCurrent(page1.getCurrent());
        page2.setPages(page1.getPages());
        page2.setSize(page1.getSize());
        page2.setTotal(page1.getTotal());
        page2.setRecords(getProducts(page1.getRecords()));
        return Response.successWithData(page2);
    }

    /**
     * 搜索条件分页
     */
    @PostMapping("search")
    public Response page(@RequestBody SearchDTO page) {
        IPage page1 = copyrightService.page(page);
        IPage<CopyrightDTO> page2 = new Page<>();
        page2.setCurrent(page1.getCurrent());
        page2.setPages(page1.getPages());
        page2.setSize(page1.getSize());
        page2.setTotal(page1.getTotal());
        page2.setRecords(getProducts(page1.getRecords()));
        return Response.successWithData(page2);
    }


    /**
     * 列表：不分页 && 支持状态查询、全部查询
     */
    @GetMapping("list")
    public Response list(@RequestParam(value = "isStop", required = false) Boolean isStop) {
        QueryWrapper<Copyright> queryWrapper = new QueryWrapper<>();
        if (isStop != null) {
            queryWrapper.lambda().eq(Copyright::getIsStop, isStop);
        }
        List<Copyright> list = copyrightService.list(queryWrapper);
        List<CopyrightDTO> relist = getProducts(list);
        return Response.successWithData(relist);
    }

    /**
     * 不带模块的著作权列表
     */
    @GetMapping("listpure")
    public Response pure() {
        QueryWrapper<Copyright> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda().eq(Copyright::getIsStop, false);
        List<Copyright> list = copyrightService.list(queryWrapper);
        return Response.successWithData(list);
    }

    private List<CopyrightDTO> getProducts(List<Copyright> records) {
        List<CopyrightDTO> list = new ArrayList<>();
        if (!records.isEmpty()) {
            for (Copyright c : records) {
                CopyrightDTO dto = new CopyrightDTO();
                BeanUtils.copyProperties(c, dto);
                QueryWrapper<ProductAuthModule> queryWrapper = new QueryWrapper();
                queryWrapper.lambda().eq(ProductAuthModule::getCopyrightCode, c.getCopyrightCode());
                List<ProductAuthModule> productAuthModules = productModuleService
                        .list(queryWrapper);
                dto.setProductAuthModuleDTOS(productAuthModules);
                list.add(dto);
            }
        }
        return list;
    }
}

