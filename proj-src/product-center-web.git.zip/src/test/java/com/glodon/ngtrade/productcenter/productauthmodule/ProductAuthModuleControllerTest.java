package com.glodon.ngtrade.productcenter.productauthmodule;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.glodon.ngtrade.productcenter.security.User;
import com.glodon.ngtrade.util.common.code.MessageCode;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class ProductAuthModuleControllerTest {
    /**
     * logger
     */
    private static final Logger logger = LoggerFactory.getLogger(ProductAuthModuleControllerTest.class);
    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;
    private MockHttpSession mockHttpSession;

    @Before
    public void setupMockMvc() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build(); //初始化MockMvc对象
        mockHttpSession = new MockHttpSession();
        List<String> roles = new ArrayList<>();
        roles.add("admin");
        User user = new User("zs", roles);
        mockHttpSession.setAttribute("user", user); //拦截器那边会判断用户是否登录，所以这里注入一个用户
    }

    @Test
    public void getPageModule() throws Exception {
        String url = "/api/product-module/page";
        Map dto = new HashMap();
        dto.put("productId", "P00090");
//        dto.put("lockAuthPid","26");
//        dto.put("moduleName","北京");
        dto.put("pageNum", 1L);
        dto.put("pageSize", 1L);
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(dto);
        logger.info("getPageModule request json={}", json);
        //查询产品模块分页
        this.mockMvc
                .perform(
                        MockMvcRequestBuilders.post(url)
                                .accept(MediaType.APPLICATION_JSON_UTF8)
                                .contentType(MediaType.APPLICATION_JSON_UTF8)
                                .content(json)
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
                .andDo(print());
    }

    @Test
    public void list() throws Exception {
        String url = "/api/product-module/list";
        Map dto = new HashMap();
        dto.put("searchValue", "广联达定额排版系统");
        dto.put("pageNum", 1L);
        dto.put("pageSize", 10L);
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(dto);
        logger.info("list request json={}", json);
        //查询产品模块分页
        this.mockMvc
                .perform(
                        MockMvcRequestBuilders.post(url)
                                .accept(MediaType.APPLICATION_JSON_UTF8)
                                .contentType(MediaType.APPLICATION_JSON_UTF8)
                                .content(json)
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
                .andDo(print());
    }
}