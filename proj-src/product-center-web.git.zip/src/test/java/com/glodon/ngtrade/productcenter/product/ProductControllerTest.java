package com.glodon.ngtrade.productcenter.product;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.glodon.ngtrade.productcenter.budgetproduct.BudgetProduct;
import com.glodon.ngtrade.productcenter.budgetproduct.impl.BudgetProductServiceImpl;
import com.glodon.ngtrade.productcenter.productline.ProductLine;
import com.glodon.ngtrade.productcenter.productline.ProductLineControllerTest;
import com.glodon.ngtrade.productcenter.productline.impl.ProductLineServiceImpl;
import com.glodon.ngtrade.productcenter.security.User;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.jayway.jsonpath.JsonPath;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class ProductControllerTest {

    /**
     * logger
     */
    private static final Logger logger = LoggerFactory.getLogger(ProductLineControllerTest.class);
    @Autowired
    private WebApplicationContext webApplicationContext;
    @Autowired
    IProductService productService;
    @Autowired
    ProductLineServiceImpl productLineService;
    @Autowired
    BudgetProductServiceImpl budgetProductService;
    private MockMvc mockMvc;
    private MockHttpSession mockHttpSession;

    @Before
    public void setupMockMvc() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build(); //初始化MockMvc对象
        mockHttpSession = new MockHttpSession();
        List<String> roles = new ArrayList<>();
        roles.add("admin");
        User user = new User("zs", roles);
        mockHttpSession.setAttribute("user", user); //拦截器那边会判断用户是否登录，所以这里注入一个用户
    }

    @Test
    public void get() throws Exception {

        String Pid = "00000004";
        Product product = new Product();
        product.setId(Pid);
        product.setName("product-test");
        String url1 = "/api/budget-product/addupdate";
        //add
        BudgetProduct bp = new BudgetProduct();
        bp.setProductLineId(20);
        bp.setBudgetProductName("预算产品tet1");
        ObjectMapper mapper1 = new ObjectMapper();
        String json1 = mapper1.writeValueAsString(bp);
        logger.info("add request json1={}", json1);
        MvcResult mvcResult1 = this.mockMvc.perform(
                post(url1)
                        .accept(MediaType.APPLICATION_JSON_UTF8)
                        .contentType(MediaType.APPLICATION_JSON_UTF8)
                        .content(json1)
        )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
                .andDo(print())
                .andReturn();
        product.setBudgetProductId(JsonPath.read(mvcResult1.getResponse().getContentAsString(),
                "$.data.id"));
        String url2 = "/api/product-line/addupdate";
        //add
        ProductLine pl = new ProductLine();
        pl.setProductLineName("新产品线test1");
        ObjectMapper mapper2 = new ObjectMapper();
        String json2 = mapper2.writeValueAsString(pl);
        logger.info("add request json={}", json2);
        MvcResult mvcResult2 = this.mockMvc.perform(
                post(url2)
                        .accept(MediaType.APPLICATION_JSON_UTF8)
                        .contentType(MediaType.APPLICATION_JSON_UTF8)
                        .content(json2)
        )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
                .andDo(print())
                .andReturn();
        //modify name
        String responseJson2 = mvcResult2.getResponse().getContentAsString();
        product.setProductLineId(JsonPath.read(responseJson2, "$.data.id"));
        product.setDomainCreator("dc");
        product.setCreateTime(LocalDateTime.now());
        product.setUpdateTime(LocalDateTime.now());
        productService.saveOrUpdate(product);
        String url3 = "/api/product/{id}";
        //查询启用状态
        this.mockMvc
                .perform(
                        MockMvcRequestBuilders.
                                get(url3, Pid)
                                .accept(MediaType.APPLICATION_JSON_UTF8)
                )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
                .andDo(print());
    }
}