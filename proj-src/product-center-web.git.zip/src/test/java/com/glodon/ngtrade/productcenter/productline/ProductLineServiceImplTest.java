package com.glodon.ngtrade.productcenter.productline;

import com.glodon.ngtrade.productcenter.productline.impl.ProductLineServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class ProductLineServiceImplTest {

  @Autowired
  ProductLineServiceImpl productLineService;

  @Test
  public void saveOrUpdateTest() {
    ProductLine pl = new ProductLine();
    pl.setProductLineName("产品线1test");
    boolean a = productLineService.saveOrUpdate(pl);
    pl.setProductLineName("产品线modify1");
    boolean b = productLineService.saveOrUpdate(pl);
    Assert.assertTrue(a);
    Assert.assertTrue(b);
  }
}