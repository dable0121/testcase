package com.glodon.ngtrade.productcenter.budgetproduct;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.glodon.ngtrade.productcenter.security.User;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.jayway.jsonpath.JsonPath;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class BudgetProductControllerTest {

  /**
   * logger
   */
  private static final Logger logger = LoggerFactory
      .getLogger(com.glodon.ngtrade.productcenter.productline.ProductLineControllerTest.class);
  @Autowired
  private WebApplicationContext webApplicationContext;

  private MockMvc mockMvc;
  private MockHttpSession mockHttpSession;

  @Before
  public void setupMockMvc() {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build(); //初始化MockMvc对象
    mockHttpSession = new MockHttpSession();
    List<String> roles = new ArrayList<>();
    roles.add("admin");
    User user = new User("zs", roles);
    mockHttpSession.setAttribute("user", user); //拦截器那边会判断用户是否登录，所以这里注入一个用户
  }

  @Test
  public void addUpdateTest() throws Exception {
    String url = "/api/budget-product/addupdate";
    //add
    BudgetProduct bp = new BudgetProduct();
    bp.setProductLineId(20);
    bp.setBudgetProductName("预算产品tet1");
    ObjectMapper mapper = new ObjectMapper();
    String json = mapper.writeValueAsString(bp);
    logger.info("add request json={}", json);
    MvcResult mvcResult = this.mockMvc.perform(
        post(url)
            .accept(MediaType.APPLICATION_JSON_UTF8)
            .contentType(MediaType.APPLICATION_JSON_UTF8)
            .content(json)
    )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
        .andDo(print())
        .andReturn();
    logger.info("repeat add request json={}", json);
    this.mockMvc.perform(
        post(url)
            .accept(MediaType.APPLICATION_JSON_UTF8)
            .contentType(MediaType.APPLICATION_JSON_UTF8)
            .content(json)
    )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.NAME_REPEAT.getCode()))
        .andExpect(jsonPath("$.message").value("预算产品名称重复"))
        .andDo(print());
    //modify name
    String responseJson = mvcResult.getResponse().getContentAsString();
    BudgetProduct bp1 = new BudgetProduct();
    bp1.setId(JsonPath.read(responseJson, "$.data.id"));
    bp1.setBudgetProductName("预算产品modify1");
    bp1.setProductLineId(19);
    json = mapper.writeValueAsString(bp1);
    logger.info("modify name request json={}", json);
    MvcResult mvcResult1 = this.mockMvc.perform(
        MockMvcRequestBuilders.post(url)
            .accept(MediaType.APPLICATION_JSON_UTF8)
            .contentType(MediaType.APPLICATION_JSON_UTF8)
            .content(json)
    )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
        .andDo(print())
        .andReturn();
    //stop
    String stop = mvcResult1.getResponse().getContentAsString();
    BudgetProduct bp2 = new BudgetProduct();
    bp2.setId(JsonPath.read(stop, "$.data.id"));
    bp2.setIsStop(true);
    json = mapper.writeValueAsString(bp2);
    //stop
    logger.info("stop request json={}", json);
    this.mockMvc.perform(
        MockMvcRequestBuilders.post(url)
            .accept(MediaType.APPLICATION_JSON_UTF8)
            .contentType(MediaType.APPLICATION_JSON_UTF8)
            .content(json)
    )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
        .andDo(print())
        .andReturn();
    //enable
    bp2.setIsStop(false);
    json = mapper.writeValueAsString(bp2);
    logger.info("enable request json={}", json);
    this.mockMvc.perform(
        post(url)
            .accept(MediaType.APPLICATION_JSON_UTF8)
            .contentType(MediaType.APPLICATION_JSON_UTF8)
            .content(json)
    )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
        .andDo(print())
        .andReturn();
  }

  @Test
  public void pageTest() throws Exception {
    String url = "/api/budget-product/page";
    logger.info("page={}", "{}");
    //查询分页
    this.mockMvc
        .perform(
            post(url)
                .accept(MediaType.APPLICATION_JSON_UTF8)
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content("{}")
        )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
        .andDo(print());
    //查询设置每页条数
    Page page = new Page();
    page.setSize(3L);
    ObjectMapper mapper = new ObjectMapper();
    logger.info("page={}", mapper.writeValueAsString(page));
    this.mockMvc
        .perform(
            post(url)
                .accept(MediaType.APPLICATION_JSON_UTF8)
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content(mapper.writeValueAsString(page))
        )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
        .andDo(print());
  }


  @Test
  public void listTest() throws Exception {
    String url = "/api/budget-product/list";
    //查询启用状态
    this.mockMvc
        .perform(
            get(url)
                .param("isStop", "0")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
        )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
        .andDo(print());
    //查询全部状态
    this.mockMvc
        .perform(
            get(url)
                .contentType(MediaType.APPLICATION_JSON_UTF8)
        )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.code").value(MessageCode.MessageCodeEnum.SUCCESS.getCode()))
        .andDo(print());
  }
}