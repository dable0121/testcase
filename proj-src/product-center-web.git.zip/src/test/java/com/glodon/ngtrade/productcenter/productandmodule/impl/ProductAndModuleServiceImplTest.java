package com.glodon.ngtrade.productcenter.productandmodule.impl;

import com.glodon.ngtrade.productcenter.product.IProductService;
import com.glodon.ngtrade.productcenter.product.Product;
import com.glodon.ngtrade.productcenter.productandmodule.ProductAndModule;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class ProductAndModuleServiceImplTest {
    @Autowired
    ProductAndModuleServiceImpl iProductAndModuleService;
    @Autowired
    IProductService productService;

    final String PID = "00000654";


    @Test
    public void selectByPid() {
        Product product = new Product();
        product.setId(PID);
        product.setName("product-test");
        product.setBudgetProductId(1);
        product.setProductLineId(1);
        product.setDomainCreator("dc");
        product.setCreateTime(LocalDateTime.now());
        product.setUpdateTime(LocalDateTime.now());
        productService.saveOrUpdate(product);
        List<ProductAndModule> NullPM = iProductAndModuleService.selectByPid(PID);
        Assert.assertTrue(NullPM.isEmpty());
    }

}