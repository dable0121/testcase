package com.glodon.ngtrade.productcenter.gmspidrule.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.glodon.ngtrade.productcenter.gmspidrule.dto.GmspidRuleDTO;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class GmspidRuleServiceImplTest {

  /**
   * logger
   */
  private static final Logger logger = LoggerFactory.getLogger(GmspidRuleServiceImplTest.class);
  @Autowired
  GmspidRuleServiceImpl gmspidRuleService;

  @Test
  public void getChildren() throws JsonProcessingException {
    List<GmspidRuleDTO> children = gmspidRuleService.getChildren();
    ObjectMapper om = new ObjectMapper();
    String s = om.writeValueAsString(children);
    logger.info("查询助记符规则列表结果:{}",s);
  }
}