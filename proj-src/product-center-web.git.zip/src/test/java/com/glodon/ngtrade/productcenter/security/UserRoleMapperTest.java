package com.glodon.ngtrade.productcenter.security;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class UserRoleMapperTest {
    @Autowired
    private UserRoleMapper userRoleMapper;
    @Test
    public void test(){
        Map<String,Object> map = new HashMap<>();
        map.put("user_name","zx");
//        List<UserRole> userRoles = userRoleMapper.selectByMap(map);
//        System.out.println(userRoles);

    }

}