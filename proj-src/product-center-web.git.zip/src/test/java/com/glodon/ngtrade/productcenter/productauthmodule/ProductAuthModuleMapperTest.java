package com.glodon.ngtrade.productcenter.productauthmodule;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class ProductAuthModuleMapperTest {
    private final static Logger logger = LoggerFactory.getLogger(ProductAuthModuleMapperTest.class);
    @Autowired
    ProductAuthModuleMapper productAuthModuleMapper;

    @Test
    public void testGetModulePage() {
        Page page = new Page();
        page.setCurrent(2);
        page.setSize(10);
        Page<ProductAuthModuleDTO> modulePage = productAuthModuleMapper.getModulePage(page,
                "P00005", null, null);
        logger.info(JSON.toJSONString(modulePage) + "一共" + modulePage.getTotal() + "条");
    }

    @Test
    public void testListPage() {
        Page page = new Page();
        page.setCurrent(2);
        page.setSize(10);
        Page<ProductAuthModuleDTO> modulePage = productAuthModuleMapper.listPage(page,
                "广联达BIM");
        logger.info(JSON.toJSONString(modulePage) + "一共" + modulePage.getTotal() + "条");
    }

    @Test
    public void updateBatch() {
        ProductAuthModule m = new ProductAuthModule();
        m.setCopyrightCode("test1234");
        List<String> mids = new ArrayList<>();
        mids.add("M0000001");
        mids.add("M0000002");
        Assert.assertEquals(productAuthModuleMapper.update(m,
                new UpdateWrapper<ProductAuthModule>().lambda().in(ProductAuthModule::getId,
                        mids)), 2);
    }
}