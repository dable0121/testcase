package com.glodon.ngtrade.productcenter.typegmspid.impl;

import static org.junit.Assert.*;

import com.glodon.ngtrade.productcenter.typegmspid.TypeGmspid;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class TypeGmspidServiceImplTest {

  @Autowired
  TypeGmspidServiceImpl typeGmspidService;
  @Test
  public void genTypeGmspid() {
    TypeGmspid typeGmspid = typeGmspidService.genTypeGmspid(1, "", "");
    TypeGmspid typeGmspid1 = typeGmspidService.genTypeGmspid(1, "aaa", "bbb");
    Assert.assertNotNull(typeGmspid.getId());
    Assert.assertNotNull(typeGmspid1.getId());
    Assert.assertEquals("aaa",typeGmspid1.getOutPid());
    Assert.assertEquals("bbb",typeGmspid1.getOutMid());
  }
}