package com.glodon.ngtrade.productcenter.productauthmodule.impl;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductAuthModuleServiceImplTest {
    @Autowired
    ProductAuthModuleServiceImpl productAuthModuleService;

    @Test
    public void genId() {
        String s = productAuthModuleService.generateId();
        Assert.assertTrue(s.startsWith("M"));
        Assert.assertTrue(s.length() == 8);
    }

}