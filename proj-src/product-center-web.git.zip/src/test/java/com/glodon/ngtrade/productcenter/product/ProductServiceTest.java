package com.glodon.ngtrade.productcenter.product;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.HashMap;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
@Rollback
@Transactional(transactionManager = "transactionManager")
public class ProductServiceTest {

    @Autowired
    IProductService productService;

    final String PID = "P00001";

    @Before
    public void init() {
        Product product = new Product();
        product.setId(PID);
        product.setName("product-test");
        product.setBudgetProductId(1);
        product.setProductLineId(1);
        product.setDomainCreator("dc");
        product.setCreateTime(LocalDateTime.now());
        product.setUpdateTime(LocalDateTime.now());
        productService.saveOrUpdate(product);
    }

    @After
    public void cleanup() {
        productService.remove(new LambdaQueryWrapper<Product>().eq(Product::getId, PID));
    }

    @Test
    public void listByMap() {
        Collection<Product> productList = productService.listByMap(new HashMap<String, Object>() {{
            put("id", PID);
        }});

        assertThat(productList).isNotEmpty();

    }

    @Test
    public void getOne() {
        Product product =
                productService.getOne(new LambdaQueryWrapper<Product>().eq(Product::getId, PID));
        assertThat(product).isNotNull();
    }

    @Test
    public void getPage() {
        IPage<Product> productIPage = productService.page(new Page<>(1, 1),
                new LambdaQueryWrapper<Product>().eq(Product::getName, "product-test"));
        IPage<ProductDTO> productDTOIPage = productIPage.convert(product -> {
            ProductDTO productDTO = new ProductDTO();

            BeanUtils.copyProperties(product, productDTO);
            return productDTO;
        });

        assertThat(productDTOIPage.getSize()).isEqualTo(1);

    }

    @Test
    public void genId() {
        String s = productService.generateId();
        Assert.assertTrue(s.startsWith("P"));
        Assert.assertTrue(s.length() == 6);
    }
}
