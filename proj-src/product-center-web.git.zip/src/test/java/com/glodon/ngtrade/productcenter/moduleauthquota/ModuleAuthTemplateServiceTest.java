package com.glodon.ngtrade.productcenter.moduleauthquota;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.glodon.ngtrade.productcenter.moduleauthquota.impl.ModuleAuthQuotaServiceImpl;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ModuleAuthTemplateServiceTest {

  @Autowired
  ModuleAuthQuotaServiceImpl productAttrTemplateService;

  @Before
  public void init() {
    ModuleAuthQuota productAttrTemplate = new ModuleAuthQuota();
    productAttrTemplate.setId("1111");
    productAttrTemplate.setQuotaDefaultValue("111111");
    productAttrTemplate.setQuotaName("空间");
    productAttrTemplate.setQuotaType(1);
    productAttrTemplate.setMid("M0000001");

    productAttrTemplateService.saveOrUpdate(productAttrTemplate);
  }

  @After
  public void cleanup() {
    productAttrTemplateService.remove(new LambdaQueryWrapper<ModuleAuthQuota>().eq(
        ModuleAuthQuota::getMid, "M0000001"));
  }

  @Test
  public void listByMap() {
    List<ModuleAuthQuota> productAttrTemplateList = productAttrTemplateService.list(new LambdaQueryWrapper<ModuleAuthQuota>().eq(
        ModuleAuthQuota::getMid, "M0000001"));

    assertThat(productAttrTemplateList).isNotEmpty();
  }

  @Test
  public void getOne() {
    ModuleAuthQuota productAttrTemplate = productAttrTemplateService.getOne(new LambdaQueryWrapper<ModuleAuthQuota>().eq(
        ModuleAuthQuota::getMid, "M0000001"));

    assertThat(productAttrTemplate).isNotNull();
  }
}
