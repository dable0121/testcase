import com.baomidou.mybatisplus.core.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import org.apache.commons.lang3.StringUtils;

import java.util.Scanner;

// 演示例子，执行 main 方法控制台输入模块表名回车自动生成对应项目目录中
public class CodeGenerator {

  /**
   * <p>
   * 读取控制台内容
   * </p>
   */
  public static String scanner(String tip) {
    Scanner scanner = new Scanner(System.in);
    StringBuilder help = new StringBuilder();
    help.append("请输入" + tip + "：");
    System.out.println(help.toString());
    if (scanner.hasNext()) {
      String ipt = scanner.next();
      if (StringUtils.isNotEmpty(ipt)) {
        return ipt;
      }
    }
    throw new MybatisPlusException("请输入正确的" + tip + "！");
  }

  public static void main(String[] args) {
//    // 代码生成器
//    AutoGenerator mpg = new AutoGenerator();
//
//    // 全局配置
//    GlobalConfig gc = new GlobalConfig();
//    String projectPath = System.getProperty("user.dir");
//    gc.setOutputDir(projectPath + "/product-center-web/src/main/java");
//    gc.setAuthor("dable");
//    gc.setOpen(false);
//    mpg.setGlobalConfig(gc);
//
//    // 数据源配置
//    DataSourceConfig dsc = new DataSourceConfig();
//    dsc.setUrl(
//        "jdbc:mysql://mysql.me.glodon.com:3306/product_center?useUnicode=true&useSSL=false&characterEncoding=utf8&serverTimezone=Asia/Shanghai");
//    dsc.setDriverName("com.mysql.cj.jdbc.Driver");
//    dsc.setUsername("root");
//    dsc.setPassword("123456");
//    mpg.setDataSource(dsc);
    //统一存放包位置配置
//    // 包配置
//    PackageConfig pc = new PackageConfig();
//    pc.setModuleName("productcenter");
//    pc.setParent("com.glodon.ngtrade");
//    mpg.setPackageInfo(pc);
//    mpg.setTemplate(new TemplateConfig().setXml(null));
//    // 策略配置
//    StrategyConfig strategy = new StrategyConfig();
//    strategy.setNaming(NamingStrategy.underline_to_camel);
//    strategy.setColumnNaming(NamingStrategy.underline_to_camel);
//    strategy.setEntityLombokModel(true);
//    strategy.setRestControllerStyle(true);
//    strategy.setInclude("product_line","budget_product","copyright","copyright_product_relationship","gmspid_rule","type_gmspid");
//    strategy.setControllerMappingHyphenStyle(true);
    //分开存放包配置
    String[] tables = {"product_and_module"};
    for (int i = 0; i < tables.length; i++) {
      // 代码生成器
      AutoGenerator mpg = new AutoGenerator();

      // 全局配置
      GlobalConfig gc = new GlobalConfig();
      String projectPath = System.getProperty("user.dir");
      gc.setOutputDir(projectPath + "/product-center-web.git/src/main/java");
      gc.setAuthor("dable");
      gc.setOpen(false);
      mpg.setGlobalConfig(gc);

      // 数据源配置
      DataSourceConfig dsc = new DataSourceConfig();
      dsc.setUrl(
          "jdbc:mysql://mysql.me.glodon.com:43306/product_center?useUnicode=true&useSSL=false&characterEncoding=utf8" +
                  "&serverTimezone=Asia/Shanghai");
      dsc.setDriverName("com.mysql.cj.jdbc.Driver");
      dsc.setUsername("root");
      dsc.setPassword("123456");
      mpg.setDataSource(dsc);
      // 包配置
      PackageConfig pc = new PackageConfig();
      StrategyConfig sc = new StrategyConfig();
      String pc_name = tables[i].replace("_", "");
      pc.setParent("com.glodon.ngtrade.productcenter");
//    pc.setModuleName(pc_name);
      //设置包自定定义目录，相对模块包的位置，如"productline"
      pc.setController(pc_name);
      pc.setEntity(pc_name);
      pc.setMapper(pc_name);
      pc.setXml(pc_name);
      pc.setService(pc_name);
      pc.setServiceImpl(pc_name + ".impl");
      mpg.setPackageInfo(pc);
      mpg.setTemplate(new TemplateConfig().setXml(null));

      // 策略配置
      sc.setNaming(NamingStrategy.underline_to_camel);
      sc.setColumnNaming(NamingStrategy.underline_to_camel);
      sc.setEntityLombokModel(true);
      sc.setRestControllerStyle(true);
      sc.setInclude(tables[i]);
//      sc.setSuperControllerClass("com.glodon.ngtrade.productcenter.common.BaseController");
      sc.setControllerMappingHyphenStyle(true);
      mpg.setStrategy(sc);
      mpg.execute();
    }
  }

}