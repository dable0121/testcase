package com.glodon.ngtrade.util.crm.ws;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Asset")
public class Asset {
    private String accountId;
    private String accountNum;
    private String accountName;
    private String login;
    private String lockId;
    private String lockNum;
    private String lockMode;
    private String lockType;
    private String prodId;
    private String prodName;
    private String prodPartNum;
    private String prodType;
    private String prodSubType;
    private String packageType;
    private String nodeNum;
    private String installDate;
    private String effStartDate;
    private String effEndDate;
    private String assetId;
    private String parAssetId;
    private String rootAssetId;

    @XmlElement(name = "AccountId")
    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    @XmlElement(name = "AccountNum")
    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    @XmlElement(name = "AccountName")
    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    @XmlElement(name = "LockId")
    public String getLockId() {
        return lockId;
    }

    public void setLockId(String lockId) {
        this.lockId = lockId;
    }

    @XmlElement(name = "LockNum")
    public String getLockNum() {
        return lockNum;
    }

    public void setLockNum(String lockNum) {
        this.lockNum = lockNum;
    }

    @XmlElement(name = "LockMode")
    public String getLockMode() {
        return lockMode;
    }

    public void setLockMode(String lockMode) {
        this.lockMode = lockMode;
    }

    @XmlElement(name = "LockType")
    public String getLockType() {
        return lockType;
    }

    public void setLockType(String lockType) {
        this.lockType = lockType;
    }

    @XmlElement(name = "ProdName")
    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    @XmlElement(name = "Login")
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @XmlElement(name = "ProdId")
    public String getProdId() {
        return prodId;
    }

    public void setProdId(String prodId) {
        this.prodId = prodId;
    }

    @XmlElement(name = "ProdPartNum")
    public String getProdPartNum() {
        return prodPartNum;
    }

    public void setProdPartNum(String prodPartNum) {
        this.prodPartNum = prodPartNum;
    }

    @XmlElement(name = "ProdType")
    public String getProdType() {
        return prodType;
    }

    public void setProdType(String prodType) {
        this.prodType = prodType;
    }

    @XmlElement(name = "ProdSubType")
    public String getProdSubType() {
        return prodSubType;
    }

    public void setProdSubType(String prodSubType) {
        this.prodSubType = prodSubType;
    }

    @XmlElement(name = "PackageType")
    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    @XmlElement(name = "NodeNum")
    public String getNodeNum() {
        return nodeNum;
    }

    public void setNodeNum(String nodeNum) {
        this.nodeNum = nodeNum;
    }

    @XmlElement(name = "InstallDate")
    public String getInstallDate() {
        return installDate;
    }

    public void setInstallDate(String installDate) {
        this.installDate = installDate;
    }

    @XmlElement(name = "EffStartDate")
    public String getEffStartDate() {
        return effStartDate;
    }

    public void setEffStartDate(String effStartDate) {
        this.effStartDate = effStartDate;
    }

    @XmlElement(name = "EffEndDate")
    public String getEffEndDate() {
        return effEndDate;
    }

    public void setEffEndDate(String effEndDate) {
        this.effEndDate = effEndDate;
    }

    @XmlElement(name = "AssetId")
    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    @XmlElement(name = "ParAssetId")
    public String getParAssetId() {
        return parAssetId;
    }

    public void setParAssetId(String parAssetId) {
        this.parAssetId = parAssetId;
    }

    @XmlElement(name = "RootAssetId")
    public String getRootAssetId() {
        return rootAssetId;
    }

    public void setRootAssetId(String rootAssetId) {
        this.rootAssetId = rootAssetId;
    }
}
