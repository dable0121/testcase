package com.glodon.ngtrade.util.crm.config;

import javax.annotation.PostConstruct;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.feature.LoggingFeature;
import org.apache.cxf.interceptor.AbstractLoggingInterceptor;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource({ "classpath:META-INF/cxf/cxf.xml", "classpath:META-INF/cxf/cxf-extension-soap.xml" })
public class CxfConfig {

  @Autowired
  private SpringBus springBus;

  @PostConstruct
  public void activateLoggingFeature() {
    springBus.getInInterceptors().add(logInInterceptor());
    springBus.getInFaultInterceptors().add(logInInterceptor());
    springBus.getOutInterceptors().add(logOutInterceptor());
    springBus.getOutFaultInterceptors().add(logOutInterceptor());
  }

  @Bean
  public LoggingFeature loggingFeature() {
    LoggingFeature logFeature = new LoggingFeature();
    logFeature.setPrettyLogging(true);
    logFeature.initialize(springBus);
    springBus.getFeatures().add(logFeature);
    return logFeature;
  }

  public AbstractLoggingInterceptor logInInterceptor() {
    return new LoggingInInterceptor();
  }

  public AbstractLoggingInterceptor logOutInterceptor() {
    LoggingOutInterceptor logOutInterceptor = new LoggingOutInterceptor();
    logOutInterceptor.setPrettyLogging(true);
    return logOutInterceptor;
  }

}
