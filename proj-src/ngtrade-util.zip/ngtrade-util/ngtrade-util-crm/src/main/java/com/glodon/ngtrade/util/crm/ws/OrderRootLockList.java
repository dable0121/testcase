package com.glodon.ngtrade.util.crm.ws;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "LockList")
public class OrderRootLockList {
    private List<OrderLockItem> orderLockItemList;

    @XmlElement(name = "Lock")
    public List<OrderLockItem> getOrderLockItemList() {
        return orderLockItemList;
    }

    public void setOrderLockItemList(List<OrderLockItem> orderLockItemList) {
        this.orderLockItemList = orderLockItemList;
    }

    @Override
    public String toString() {
        return "OrderRootLockList{" +
                "orderLockItemList=" + orderLockItemList +
                '}';
    }
}