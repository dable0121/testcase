package com.glodon.ngtrade.util.crm.ws;

public class OrderResp {
    private String orderId;
    private String orderNum;
    private String orderStatus;

    public OrderResp(String orderId, String orderNum, String orderStatus) {
        this.orderId = orderId;
        this.orderNum = orderNum;
        this.orderStatus = orderStatus;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    @Override
    public String toString() {
        return "OrderResp{" +
                "orderId='" + orderId + '\'' +
                ", orderNum='" + orderNum + '\'' +
                ", orderStatus='" + orderStatus + '\'' +
                '}';
    }
}
