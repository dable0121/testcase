package com.glodon.ngtrade.util.crm.ws;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "Lock")
@XmlType(propOrder = {"num", "orderLockProductList"})
public class OrderLockItem {
    private String num;
    private OrderLockProductList orderLockProductList;

    @XmlElement(name = "Num")
    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    @XmlElement(name = "ProdList")
    public OrderLockProductList getOrderLockProductList() {
        return orderLockProductList;
    }

    public void setOrderLockProductList(OrderLockProductList orderLockProductList) {
        this.orderLockProductList = orderLockProductList;
    }

    @Override
    public String toString() {
        return "OrderLockItem{" +
                ", num='" + num + '\'' +
                ", orderLockProductList=" + orderLockProductList +
                '}';
    }
}
