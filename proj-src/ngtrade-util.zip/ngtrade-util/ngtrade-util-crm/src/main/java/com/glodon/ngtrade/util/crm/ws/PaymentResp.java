package com.glodon.ngtrade.util.crm.ws;

public class PaymentResp {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
