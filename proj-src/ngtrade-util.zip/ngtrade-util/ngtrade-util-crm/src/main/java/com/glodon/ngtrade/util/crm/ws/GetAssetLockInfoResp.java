package com.glodon.ngtrade.util.crm.ws;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "LockList")
public class GetAssetLockInfoResp {
    private List<Lock> locks;

    @XmlElement(name = "Lock")
    public List<Lock> getLocks() {
        return locks;
    }

    public void setLocks(List<Lock> locks) {
        this.locks = locks;
    }

    @Override
    public String toString() {
        return "GetAssetLockInfoResp{" +
                "locks=" + locks +
                '}';
    }
}
