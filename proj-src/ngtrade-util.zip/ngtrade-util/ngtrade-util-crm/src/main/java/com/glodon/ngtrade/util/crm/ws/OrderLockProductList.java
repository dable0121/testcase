package com.glodon.ngtrade.util.crm.ws;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "ProdList")
public class OrderLockProductList {
    private List<OrderLockProductItem> orderLockProductItemList;

    @XmlElement(name = "Prod")
    public List<OrderLockProductItem> getOrderLockProductItemList() {
        return orderLockProductItemList;
    }

    public void setOrderLockProductItemList(List<OrderLockProductItem> orderLockProductItemList) {
        this.orderLockProductItemList = orderLockProductItemList;
    }

    @Override
    public String toString() {
        return "OrderLockProductList{" +
                "orderLockProductItemList=" + orderLockProductItemList +
                '}';
    }
}
