package com.glodon.ngtrade.util.crm.ws;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Lock")
public class Lock {
    private String lockNum;
    private String prodId;
    private String prodName;
    private String prodPartNum;
    private String prodType;
    private String prodSubType;
    private String packageType;
    private String nodeNum;
    private String installDate;
    private String effStartDate;
    private String effEndDate;
    private String assetId;
    private String parAssetId;
    private String rootAssetId;

    @XmlElement(name = "LockNum")
    public String getLockNum() {
        return lockNum;
    }

    public void setLockNum(String lockNum) {
        this.lockNum = lockNum;
    }

    @XmlElement(name = "ProdId")
    public String getProdId() {
        return prodId;
    }

    public void setProdId(String prodId) {
        this.prodId = prodId;
    }

    @XmlElement(name = "ProdName")
    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    @XmlElement(name = "ProdPartNum")
    public String getProdPartNum() {
        return prodPartNum;
    }

    public void setProdPartNum(String prodPartNum) {
        this.prodPartNum = prodPartNum;
    }

    @XmlElement(name = "ProdType")
    public String getProdType() {
        return prodType;
    }

    public void setProdType(String prodType) {
        this.prodType = prodType;
    }

    @XmlElement(name = "ProdSubType")
    public String getProdSubType() {
        return prodSubType;
    }

    public void setProdSubType(String prodSubType) {
        this.prodSubType = prodSubType;
    }

    @XmlElement(name = "PackageType")
    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    @XmlElement(name = "NodeNum")
    public String getNodeNum() {
        return nodeNum;
    }

    public void setNodeNum(String nodeNum) {
        this.nodeNum = nodeNum;
    }

    @XmlElement(name = "InstallDate")
    public String getInstallDate() {
        return installDate;
    }

    public void setInstallDate(String installDate) {
        this.installDate = installDate;
    }

    @XmlElement(name = "EffStartDate")
    public String getEffStartDate() {
        return effStartDate;
    }

    public void setEffStartDate(String effStartDate) {
        this.effStartDate = effStartDate;
    }

    @XmlElement(name = "EffEndDate")
    public String getEffEndDate() {
        return effEndDate;
    }

    public void setEffEndDate(String effEndDate) {
        this.effEndDate = effEndDate;
    }

    @XmlElement(name = "AssetId")
    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }

    @XmlElement(name = "ParAssetId")
    public String getParAssetId() {
        return parAssetId;
    }

    public void setParAssetId(String parAssetId) {
        this.parAssetId = parAssetId;
    }

    @XmlElement(name = "RootAssetId")
    public String getRootAssetId() {
        return rootAssetId;
    }

    public void setRootAssetId(String rootAssetId) {
        this.rootAssetId = rootAssetId;
    }

    @Override
    public String toString() {
        return "Lock{" +
                "lockNum='" + lockNum + '\'' +
                ", prodId='" + prodId + '\'' +
                ", prodName='" + prodName + '\'' +
                ", prodPartNum='" + prodPartNum + '\'' +
                ", prodType='" + prodType + '\'' +
                ", prodSubType='" + prodSubType + '\'' +
                ", packageType='" + packageType + '\'' +
                ", nodeNum='" + nodeNum + '\'' +
                ", installDate='" + installDate + '\'' +
                ", effStartDate='" + effStartDate + '\'' +
                ", effEndDate='" + effEndDate + '\'' +
                ", assetId='" + assetId + '\'' +
                ", parAssetId='" + parAssetId + '\'' +
                ", rootAssetId='" + rootAssetId + '\'' +
                '}';
    }
}
