package com.glodon.ngtrade.util.crm.ws;

public class CommonResp {
}
