package com.glodon.ngtrade.util.crm.ws;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "AssetList")
public class GetAssetInfoResp {
    private List<Asset> assets;

    @XmlElement(name = "Asset")
    public List<Asset> getAssets() {
        return assets;
    }

    public void setAssets(List<Asset> assets) {
        this.assets = assets;
    }

    @Override
    public String toString() {
        return "GetAssetInfoResp{" +
                "assets=" + assets +
                '}';
    }
}
