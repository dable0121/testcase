package com.glodon.ngtrade.util.crm.ws;

import com.glodon.ngtrade.util.crm.Main;
import com.glodon.soa.utilities.servicemonitor.schema.customsoapheader.v1.CustomSOAPHeader;
import com.siebel.customui.GLDSpcZCMSpcInterfaceSpcBS;
import com.siebel.customui.GLDSpcZCMSpcInterfaceSpcBS_Service;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;
import org.apache.cxf.headers.Header;
import org.apache.cxf.jaxb.JAXBDataBinding;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Main.class)
public class CrmCommonServiceTest {

  private GLDSpcZCMSpcInterfaceSpcBS gldSpcZCMSpcInterfaceSpcBS;

  Holder<String> errorCode = new Holder<>();
  Holder<String> errorMessage = new Holder<>();
  Holder<String> outputXml = new Holder<>();
  Holder<CustomSOAPHeader> customSOAPHeaderHolder = new Holder<>();

  Holder<String> orderId = new Holder<>();
  Holder<String> orderNum = new Holder<>();
  Holder<String> orderStatus = new Holder<>();

  @Before
  public void init() throws MalformedURLException, JAXBException {
    GLDSpcZCMSpcInterfaceSpcBS_Service webService = new GLDSpcZCMSpcInterfaceSpcBS_Service();
    gldSpcZCMSpcInterfaceSpcBS = webService.getPort(GLDSpcZCMSpcInterfaceSpcBS.class);

    BindingProvider bp = (BindingProvider) gldSpcZCMSpcInterfaceSpcBS;
    Map<String, Object> context = bp.getRequestContext();
    context.put("ws-security.username", "gmall_sys");
    context.put("ws-security.password", "gmall@2#s$d%");

    ArrayList<Header> headers = new ArrayList<Header>(1);

    CustomSOAPHeader conservationHeader = new CustomSOAPHeader();
    conservationHeader.setConversationId("");

    Header soapHeader = new Header(
        new QName("http://www.glodon.com/soa/utilities/servicemonitor/schema/CustomSoapHeader/V1.0",
            "CustomSOAPHeader"),
        conservationHeader,
        new JAXBDataBinding(CustomSOAPHeader.class));
    headers.add(soapHeader);
    bp.getRequestContext().put(Header.HEADER_LIST, headers);
  }

  @Test
  public void getAccountLockList() throws MalformedURLException, JAXBException {

    gldSpcZCMSpcInterfaceSpcBS
        .getAccountLockList("1-4EWKYR", customSOAPHeaderHolder, errorCode, errorMessage, outputXml);

    printResp();

    GetAccountLockListResp getAccountLockListResp = unMarshal(outputXml.value,
        GetAccountLockListResp.class);
  }

  @Test
  public void getAssetInfo() throws MalformedURLException, JAXBException {
    gldSpcZCMSpcInterfaceSpcBS
        .getAssetInfo("2017420", customSOAPHeaderHolder, errorCode, errorMessage, outputXml);

    printResp();

    GetAssetInfoResp getAssetInfoResp = unMarshal(outputXml.value, GetAssetInfoResp.class);

    for (Asset asset : getAssetInfoResp.getAssets()) {
      System.out.println(asset);
    }
  }

  @Test
  public void getAssetLockInfo() throws MalformedURLException, JAXBException {
    gldSpcZCMSpcInterfaceSpcBS
        .getAssetLockInfo("1-2OR1DG", customSOAPHeaderHolder, errorCode, errorMessage, outputXml);

    printResp();

    GetAssetLockInfoResp getAssetLockInfoResp = unMarshal(outputXml.value,
        GetAssetLockInfoResp.class);

    for (Lock lock : getAssetLockInfoResp.getLocks()) {
      System.out.println(lock);
    }
  }

  @Test
  public void getAssetLockList() throws MalformedURLException, JAXBException {
    gldSpcZCMSpcInterfaceSpcBS
        .getAssetLockList("2017420", customSOAPHeaderHolder, errorCode, errorMessage, outputXml);

    printResp();

    GetAssetLockListResp getAssetLockListResp = unMarshal(outputXml.value,
        GetAssetLockListResp.class);

    for (Asset asset : getAssetLockListResp.getAssets()) {
      System.out.println(asset);
    }
  }

  @Test
  public void getOrderStatus() throws MalformedURLException, JAXBException {
    gldSpcZCMSpcInterfaceSpcBS
        .getOrderStatus("1-4I0SPQ", customSOAPHeaderHolder, errorCode, errorMessage, outputXml);

    printResp();
  }

//    @Test
//    public void createOrder() throws JAXBException {
//        String itemStr = marshalString();
//        String login = "WANLB";
//        String accountId = "1-518HV9";
//        String sourceOrderId = UUIDUtils.uuidStr();
//        String orderSource = "trade-test";
//        gldSpcZCMSpcInterfaceSpcBS.createOrder2(itemStr, sourceOrderId, login, accountId, orderSource, "", errorCode, errorMessage, orderId, orderNum, orderStatus);
//
//        printCreateResp();
//    }

  @Test
  public void CreateOrderPlus2() throws JAXBException {
    System.out.println("CreateOrderPlus2");
    String lockNum = "A02017420";
    String outOrderId = UUID.randomUUID().toString();
    String orderSource = "trade-test";
    String itemStr = marshalString2();
//        gldSpcZCMSpcInterfaceSpcBS.createOrderPlus2(itemStr, lockNum, outOrderId, orderSource, "", errorCode, errorMessage, orderId, orderNum, orderStatus);

    printCreateResp();
  }

//    private String marshalString() throws JAXBException {
//        OrderRootLockList orderRootLockList = new OrderRootLockList();
//
//        List<OrderLockItem> orderLockItems = new ArrayList<>();
//
//        OrderLockItem orderLockItem = new OrderLockItem();
//
//        orderLockItem.setId("1-59-2117");
//        orderLockItem.setMode("");
//        orderLockItem.setNum(" A02017420");
//        orderLockItem.setType("单机版");
//
//        OrderLockProductList orderLockProductList = new OrderLockProductList();
//
//        List<OrderLockProductItem> orderLockProductItems = new ArrayList<>();
//        OrderLockProductItem orderLockProductItem = new OrderLockProductItem();
//        orderLockProductItem.setProdId("1-59-657");
//        orderLockProductItem.setNode("1");
//        orderLockProductItem.setUnitPrice("1000");
//        orderLockProductItem.setPrice("1000");
//        orderLockProductItem.setStartDate("01/01/2015");
//        orderLockProductItem.setEndDate("01/01/2019");
//        orderLockProductItem.setCardNum("");
//        orderLockProductItems.add(orderLockProductItem);
//        orderLockProductList.setOrderLockProductItemList(orderLockProductItems);
//
//        orderLockItem.setOrderLockProductList(orderLockProductList);
//
//        orderLockItems.add(orderLockItem);
//
//
//        orderRootLockList.setOrderLockItemList(orderLockItems);
//
//        Writer w = new StringWriter();
//
//        JAXBContext jaxbContext = JAXBContext.newInstance(OrderRootLockList.class);
//        Marshaller marshaller = jaxbContext.createMarshaller();
//        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
//        marshaller.marshal(orderRootLockList, w);
//
//        return w.toString();
//    }

  private String marshalString2() throws JAXBException {
    OrderRootLockList orderRootLockList = new OrderRootLockList();

    List<OrderLockItem> orderLockItems = new ArrayList<>();

    OrderLockItem orderLockItem = new OrderLockItem();

    orderLockItem.setNum("A02017420");

    OrderLockProductList orderLockProductList = new OrderLockProductList();

    List<OrderLockProductItem> orderLockProductItems = new ArrayList<>();
    OrderLockProductItem orderLockProductItem = new OrderLockProductItem();
    orderLockProductItem.setProdId("1-59-657");
    orderLockProductItem.setNode("1");
    orderLockProductItem.setUnitPrice("1000");
    orderLockProductItem.setPrice("1000");
    orderLockProductItem.setStartDate("01/01/2015");
    orderLockProductItem.setEndDate("01/01/2019");
    orderLockProductItem.setCardNum("");
    orderLockProductItems.add(orderLockProductItem);
    orderLockProductList.setOrderLockProductItemList(orderLockProductItems);

    orderLockItem.setOrderLockProductList(orderLockProductList);

    orderLockItems.add(orderLockItem);

    orderRootLockList.setOrderLockItemList(orderLockItems);

    Writer w = new StringWriter();

    JAXBContext jaxbContext = JAXBContext.newInstance(OrderRootLockList.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
    marshaller.marshal(orderRootLockList, w);

    return w.toString();
  }

  private <T> T unMarshal(String bodyXml, Class<T> t) throws JAXBException {
    JAXBContext jaxbContext = JAXBContext.newInstance(t);
    Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
    InputStream inputStream = new ByteArrayInputStream(bodyXml.getBytes());
    T item = (T) unmarshaller.unmarshal(inputStream);
    return item;
  }

  private void printResp() {
    System.out.println(errorCode.value);
    System.out.println(errorMessage.value);
    System.out.println(outputXml.value);
  }

  private void printCreateResp() {
    System.out.println(errorCode.value);
    System.out.println(errorMessage.value);
    System.out.println(orderId.value);
    System.out.println(orderNum.value);
    System.out.println(orderStatus.value);
  }
}
