package com.glodon.ngtrade.util.crm.ws;

import com.glodon.soa.utilities.servicemonitor.schema.customsoapheader.v1.CustomSOAPHeader;
import com.siebel.asi.GLDPaymentInboundForERP;
import com.siebel.asi.GLDSpcPaymentSpcInboundSpcForSpcERPSpcBS;
import javax.xml.ws.Holder;
import org.junit.BeforeClass;
import org.junit.Test;

public class CrmPaymentServiceTest {

  private static GLDPaymentInboundForERP gldPaymentInboundForERP;
  private static GLDSpcPaymentSpcInboundSpcForSpcERPSpcBS gldSpcPaymentSpcInboundSpcForSpcERPSpcBS;

  Holder<String> errorCode = new Holder<>();
  Holder<String> errorMessage = new Holder<>();
  Holder<CustomSOAPHeader> customSOAPHeaderHolder = new Holder<>();

  @BeforeClass
  public static void init() {
    gldPaymentInboundForERP = new GLDPaymentInboundForERP();
    gldSpcPaymentSpcInboundSpcForSpcERPSpcBS = gldPaymentInboundForERP
        .getGLDSpcPaymentSpcInboundSpcForSpcERPSpcBS();
  }

  @Test
  public void createPayment() {
    String type = "付款";//收款类型
    String paymentId = "111111113";//核销ID
    String receiptId = "";//收款ID
    String orderNum = "1-344588161";//CRM订单编号
    String accountNum = "";//CRM客户编号
    String receiptNum = "";//收款编号
    String invoiceNum = "";//发票号
    String amount = "16600";//发生金额
    String receiptDate = "05/25/2017 12:00:00";//支付日期
    String paymentType = "现金";//支付方式
    String advanceFlg = "";//使用预收款
    String advanceId = "";//预付款ID
    String advanceAmount = "";//预付款总额
    String advanceBalance = "";//预付款余额
    String paymentCorp = "";//付款单位
    String invoiceCorp = "";//开票单位
    String currency = "CNY";//币种
    String comments = "";//备注
    String source = "交易平台测试来源";//来源

    gldSpcPaymentSpcInboundSpcForSpcERPSpcBS
        .createPayment(invoiceNum, paymentType, invoiceCorp, comments, advanceId, paymentId,
            accountNum, receiptDate, receiptId, orderNum, advanceAmount, paymentCorp, amount, type,
            currency, receiptNum, advanceFlg, source, advanceBalance, customSOAPHeaderHolder,
            errorCode, errorMessage);

    printResp();
  }

  private void printResp() {
    System.out.println(errorCode.value);
    System.out.println(errorMessage.value);
  }
}
