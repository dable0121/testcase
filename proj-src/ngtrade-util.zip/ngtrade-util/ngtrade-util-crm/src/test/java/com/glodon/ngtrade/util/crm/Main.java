package com.glodon.ngtrade.util.crm;

import com.glodon.ngtrade.util.crm.config.CxfConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackageClasses = CxfConfig.class)
public class Main {

  public static void main(String[] args) {
    SpringApplication.run(Main.class, args);
  }
}

