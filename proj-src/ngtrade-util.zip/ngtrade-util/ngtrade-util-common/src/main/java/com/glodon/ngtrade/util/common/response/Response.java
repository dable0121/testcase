package com.glodon.ngtrade.util.common.response;

import com.alibaba.fastjson.JSON;
import com.glodon.ngtrade.util.common.code.MessageCode;

/**
 * 操作结果集
 *
 * @modify by dable
 */
public class Response<T> {
    /**
     * 成功
     */
    public static final Response SUCCESS = new Response(MessageCode.SUCCESS);
    /**
     * 系统异常
     */
    public static final Response SYSTEM_ERROR = new Response(MessageCode.ERROR);

    private String code;
    private String message;
    private T data;

    public Response() {
        this(MessageCode.SUCCESS);
    }
    public Response(String code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public boolean successOrNot(){
        return this.code.equals(MessageCode.MessageCodeEnum.SUCCESS.getCode());
    }

    public Response(T result) {
        this(MessageCode.SUCCESS, result);
    }

    public Response(String code) {
        this(code, MessageCode.getMsg(code), null);
    }

    public Response(String code, Object... args) {
        this(code, MessageCode.getMsg(code, args), null);
    }

    public Response(String code, T data) {
        this(code, MessageCode.getMsg(code), data);
    }

    public Response(String code, String message) {
        this(code, message, null);
    }

    public static Response<?> errorWithOtherMsg(String code,String otherMsg) {
        return new Response(code,otherMsg);
    }

    public static Response<?> successWithData(Object data) {
        return new Response(data);
    }

    public static Response<?> getErrorResponseWithNoArgs(String code) {
        return new Response(code);
    }

    public static Response<?> getErrorResponseWithNoArgs(MessageCode.MessageCodeEnum codeEnum) {
        return new Response(codeEnum.getCode());
    }

    public static Response<?> getErrorResponseWithArgs(MessageCode.MessageCodeEnum codeEnum, Object... args) {
        return new Response(codeEnum.getCode(),args);
    }

    public static Response<?> getErrorResponseWithArgs(String code, Object... args) {
        return new Response(code, args);
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setCodeMessageData(String code, String message, T bean) {
        this.code = code;
        this.message = message;
        this.data = bean;
    }

    public void setSuccCodeData(String code, T bean) {
        this.code = code;
        this.message = MessageCode.getMsg(code);
        this.data = bean;
    }

    public void setSuccCodeMsgBean(String code, String message, T bean) {
        this.code = code;
        this.message = message;
        this.data = bean;
    }

    public void setCodeMessage(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


	@Override
	public String toString() {
		return JSON.toJSONString(this, false);
	}


}
