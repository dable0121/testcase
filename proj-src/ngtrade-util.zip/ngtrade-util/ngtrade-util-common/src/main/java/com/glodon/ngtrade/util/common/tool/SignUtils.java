package com.glodon.ngtrade.util.common.tool;

import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.constant.common.NgtradeConstant;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import org.apache.commons.codec.CharEncoding;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.digest.MessageDigestAlgorithms;
import org.apache.http.HttpHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by littlell on 2017/5/8.
 */
public class SignUtils {

  /**
   * logger
   */
  private static final Logger logger = LoggerFactory.getLogger(SignUtils.class);


  /**
   * 验证制定签名算法和编码的签名方法
   */
  public void checkSignWithExceptionForBasicHttp(HttpServletRequest request,
      String alg,
      String inputCharset, String appSecret) {
    String sign = SignUtils.getSignFromRequest(request);
    String contentSrcObj = SignUtils
        .convert2AscSortQueryString(HttpUtils.getMapFromHttpRequest(request),
            NgtradeConstant.GLODON_SIGNATURE_PARAM_NAME);
    String contentSrcObjWithSecret = String.format("%s&%s", contentSrcObj, appSecret);
    if (!SignUtils.validateSign(contentSrcObjWithSecret, sign, alg, inputCharset)) {
      throw NgtradeException.exception(MessageCode.MessageCodeEnum.SIGNATURE_INVALID);
    }
  }


  /**
   * 验证sha256，utf8签名
   */
  public static void checkSignSHA256ForQueryStringRequest(HttpServletRequest request,
      String appSecret) {
    String sign = getSignFromRequest(request);
    String contentSrcObj = SignUtils
        .convert2AscSortQueryString(HttpUtils.getMapFromHttpRequest(request),
            NgtradeConstant.GLODON_SIGNATURE_PARAM_NAME);
    String contentSrcObjWithSecret = String.format("%s&%s", contentSrcObj, appSecret);
    if (!validateSign(contentSrcObjWithSecret, sign, MessageDigestAlgorithms.SHA_256,
        CharEncoding.UTF_8)) {
      throw NgtradeException.exception(MessageCode.MessageCodeEnum.SIGNATURE_INVALID);
    }
  }

  /**
   * 根据querystring请求，获取sha256签名string
   * @param request
   * @param appSecret
   * @return
   */
  public  static String signSHA256QueryStringByHttpRequest(HttpServletRequest request,
      String appSecret){
    String contentSrcObj = SignUtils
        .convert2AscSortQueryString(HttpUtils.getMapFromHttpRequest(request),
            NgtradeConstant.GLODON_SIGNATURE_PARAM_NAME);
    return DigestUtils.sha256Hex(String.format("%s&%s", contentSrcObj, appSecret)) ;
  }

  /**
   * 验证签名
   */
  public static boolean validateSign(String signContent, String sign, String alg,
      String inputCharset) {
    logger.info("signContent:[{}]", signContent);
    try {
      if (alg.equals(MessageDigestAlgorithms.MD5)) {
        logger.info("signature[{}]", SignUtils.signMD5(signContent, inputCharset));
        return SignUtils.signVerifyMD5(signContent, sign, inputCharset);
      } else if (alg.equals(MessageDigestAlgorithms.SHA_1)) {
        logger.info("signature[{}]", SignUtils.signSha1(signContent, inputCharset));
        return SignUtils.signVerifySha1(signContent, sign, inputCharset);
      } else if (alg.equals(MessageDigestAlgorithms.SHA_256)) {
        logger.info("signature[{}]", SignUtils.signSha256(signContent, inputCharset));
        return SignUtils.signVerifySha256(signContent, sign, inputCharset);
      } else {
        throw NgtradeException.exception(MessageCode.MessageCodeEnum.NOT_SUPPORTED.getCode(),
            "sign alg not support");
      }
    } catch (UnsupportedEncodingException e) {
      throw NgtradeException.exception(MessageCode.MessageCodeEnum.ENCODING_ERROR);
    }
  }

  /**
   * 获取签名
   */
  public static String getSignFromRequest(HttpServletRequest request) {
    String header = request.getHeader(HttpHeaders.AUTHORIZATION);
    if (null != header) {
      return header;
    }
    header = request.getParameter(NgtradeConstant.GLODON_SIGNATURE_PARAM_NAME);
    if (null != header) {
      return header;
    }
    throw NgtradeException.exception(MessageCode.MessageCodeEnum.SIGNATURE_NOT_FOUND);
  }

  /**
   * 将map对象转换成按Key做字母升序排列的字符串
   */
  public static String convert2AscSortQueryString(Map<String, String> map,
      String... excludeFields) {
    Map<String, String> resultMap = new TreeMap<>();
    map.entrySet().removeIf((e) -> {
      if (e.getValue() == null) {
        return true;
      }
      if (e.getValue().equals("null")) {
        return true;
      }
      for (String excludeFiled : excludeFields) {
        if (excludeFiled.equalsIgnoreCase(e.getKey())) {
          return true;
        }
      }
      return false;
    });

    map.forEach((k, v) -> resultMap.put(k, String.valueOf(v)));
    StringBuilder sb = new StringBuilder();
    for (String key : resultMap.keySet()) {
      sb.append(key).append("=").append(resultMap.get(key)).append("&");
    }
    return sb.length() > 0 ? sb.deleteCharAt(sb.length() - 1).toString() : sb.toString();
  }

  /**
   * 计算MD5签名
   */
  public static String signMD5(String text, String input_charset)
      throws UnsupportedEncodingException {
    return DigestUtils.md5Hex(text.getBytes(input_charset)).toUpperCase();
  }

  /**
   * 验证MD5签名
   */
  public static boolean signVerifyMD5(String text, String sign, String input_charset)
      throws UnsupportedEncodingException {
    String targetSign = DigestUtils.md5Hex(text.getBytes(input_charset));
    return targetSign.equalsIgnoreCase(sign);
  }

  /**
   * 计算SHA1签名
   */
  public static String signSha1(String text, String input_charset)
      throws UnsupportedEncodingException {
    return DigestUtils.sha1Hex(text.getBytes(input_charset));
  }

  /**
   * 验证Sha1签名
   */
  public static boolean signVerifySha1(String text, String sign, String input_charset)
      throws UnsupportedEncodingException {
    String targetSign = DigestUtils.sha1Hex(text.getBytes(input_charset));
    return targetSign.equalsIgnoreCase(sign);
  }

  /**
   * 计算SHA256签名
   */
  public static String signSha256(String text, String input_charset)
      throws UnsupportedEncodingException {
    return DigestUtils.sha256Hex(text.getBytes(input_charset));
  }

  /**
   * 验证Sha256签名
   */
  public static boolean signVerifySha256(String text, String sign, String input_charset)
      throws UnsupportedEncodingException {
    String targetSign = DigestUtils.sha256Hex(text.getBytes(input_charset));
    return targetSign.equalsIgnoreCase(sign);
  }
}
