package com.glodon.ngtrade.util.common.xml;

import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement(name = "root")
public class AccountInfo {

  private String code;
  private String msg;
  private Data data;

  @XmlElement(name = "code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getMsg() {
    return msg;
  }
  @XmlElement(name = "msg")
  public void setMsg(String msg) {
    this.msg = msg;
  }

  public Data getData() {
    return data;
  }
  @XmlElement(name = "data")
  public void setData(Data data) {
    this.data = data;
  }

  public AccountInfo() {
    super();
  }

  public static class Data {

    private List<Info> info;
    @XmlElement(name = "info")
    public List<Info> getInfo() {
      return info;
    }

    public void setInfo(List<Info> info) {
      this.info = info;
    }
  }

  public static class Info {

    private String account;
    private String gid;
    private Date beginTime;
    private Date expireTime;
    @XmlElement(name = "account")
    public String getAccount() {
      return account;
    }

    public void setAccount(String account) {
      this.account = account;
    }
    @XmlElement(name = "gid")
    public String getGid() {
      return gid;
    }

    public void setGid(String gid) {
      this.gid = gid;
    }
    @XmlElement(name = "beginTime")
    @XmlJavaTypeAdapter(JaxbDateAdapter.class)
    public Date getBeginTime() {
      return beginTime;
    }

    public void setBeginTime(Date beginTime) {
      this.beginTime = beginTime;

    }
    @XmlElement(name = "expireTime")
    @XmlJavaTypeAdapter(JaxbDateAdapter.class)
    public Date getExpireTime() {
      return expireTime;
    }

    public void setExpireTime(Date expireTime) {
      this.expireTime = expireTime;

    }
  }
}
