package com.glodon.ngtrade.util.common.xml;

import java.io.StringReader;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XmlParse {

  /**
   * logger
   */
  private static final Logger logger = LoggerFactory.getLogger(XmlParse.class);

  public static <T> T fromXml(String xmlStr, Class<T> clazz) {
    T rtnObj = null;
    try {
      JAXBContext context = JAXBContext.newInstance(clazz);
      Marshaller marshaller = context.createMarshaller();
      // 是否格式 化
      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
      marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
      // 省略头信息
      marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
      Unmarshaller unmarshaller = context.createUnmarshaller();
      rtnObj = (T) unmarshaller.unmarshal(new StringReader(xmlStr));
    } catch (JAXBException e) {
      e.printStackTrace();
    }
    return rtnObj;
  }
}
