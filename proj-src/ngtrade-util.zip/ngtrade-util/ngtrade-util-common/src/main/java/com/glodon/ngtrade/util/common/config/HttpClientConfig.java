package com.glodon.ngtrade.util.common.config;

import java.util.concurrent.TimeUnit;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * Created by Dable on 2017/5/10 19:58.
 */
@Configuration
@ComponentScan(basePackages = "com.glodon.ngtrade.util.common.config")
public class HttpClientConfig {
	//初始化httpclientservice时用
	@Bean
	public RequestConfig requestConfig() {
		RequestConfig.Builder b = RequestConfig.custom();
		b.setConnectTimeout(5000);
		b.setConnectionRequestTimeout(1000);
		b.setSocketTimeout(300000);
		RequestConfig build = b.build();
		return build;
	}

	@Bean(destroyMethod = "close")
	public PoolingHttpClientConnectionManager poolingHttpClientConnectionManager() {
		PoolingHttpClientConnectionManager p = new PoolingHttpClientConnectionManager();
		p.setMaxTotal(400);
		p.setDefaultMaxPerRoute(200);
		return p;
	}

	@Bean
	public HttpClientBuilder httpClientBuilder(@Autowired PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) {
		HttpClientBuilder hcb = HttpClientBuilder.create();
		hcb.setConnectionManager(poolingHttpClientConnectionManager);
		hcb.setConnectionTimeToLive(90L, TimeUnit.SECONDS);
		return hcb;
	}


	@Bean(destroyMethod = "shutdown")
	public IdleConnectionEvictor idleConnectionEvictor(@Autowired PoolingHttpClientConnectionManager poolingHttpClientConnectionManager) {
		//60秒一次清理
		IdleConnectionEvictor i = new IdleConnectionEvictor(poolingHttpClientConnectionManager, 600000);
		return i;
	}


	@Bean(name = "authHttpClient")
	@Scope(value = "singleton")
	public CloseableHttpClient authHttpClient(@Autowired HttpClientBuilder httpClientBuilder) {
		CloseableHttpClient hcb = httpClientBuilder.build();
		return hcb;
	}

	@Bean(name = "driverHttpClient")
	@Scope(value = "singleton")
	public CloseableHttpClient driverHttpClient(@Autowired HttpClientBuilder httpClientBuilder) {
		CloseableHttpClient hcb = httpClientBuilder.build();
		return hcb;
	}

	@Bean(name = "notifyHttpClient")
	@Scope(value = "singleton")
	public CloseableHttpClient notifyHttpClient(@Autowired HttpClientBuilder httpClientBuilder) {
		CloseableHttpClient hcb = httpClientBuilder.build();
		return hcb;
	}

	@Bean(name = "orderHttpClient")
	@Scope(value = "singleton")
	public CloseableHttpClient orderHttpClient(@Autowired HttpClientBuilder httpClientBuilder) {
		CloseableHttpClient hcb = httpClientBuilder.build();
		return hcb;
	}

	@Bean(name = "offlinePayHttpClient")
	@Scope(value = "singleton")
	public CloseableHttpClient offlinePayHttpClient(@Autowired HttpClientBuilder httpClientBuilder) {
		CloseableHttpClient hcb = httpClientBuilder.build();
		return hcb;
	}


	public static class IdleConnectionEvictor extends Thread {

		private final HttpClientConnectionManager connMgr;

		private volatile boolean shutdown;
		private long waitTime;

		public IdleConnectionEvictor(HttpClientConnectionManager connMgr, @Value("${http.cleanConnectionEvictor}") long waitTime) {
			this.connMgr = connMgr;
			this.waitTime = waitTime;
			// 启动当前线程
			this.start();
		}

		@Override
		public void run() {
			try {
				while (!shutdown) {
					synchronized (this) {
						wait(waitTime);
						// 关闭失效的连接
						connMgr.closeExpiredConnections();
					}
				}
			} catch (InterruptedException ex) {
				// 结束
			}
		}

		public void shutdown() {
			shutdown = true;
			synchronized (this) {
				notifyAll();
			}
		}
	}
}
