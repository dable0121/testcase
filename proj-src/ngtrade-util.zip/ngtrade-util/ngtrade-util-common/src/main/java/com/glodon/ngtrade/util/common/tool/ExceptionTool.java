package com.glodon.ngtrade.util.common.tool;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Created by Dable on 2017/12/25 15:47.
 */
public class ExceptionTool {

	/**
	 * 获取异常堆栈信息
	 *
	 * @param e
	 * @return
	 */
	public static String stackTrace2String(Throwable e) {
		StringWriter writer = new StringWriter();
		e.printStackTrace(new PrintWriter(writer, true));
		return writer.toString();
	}

}
