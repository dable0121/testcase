package com.glodon.ngtrade.util.common.constant.common;

public class NgtradePayTypeConstant {
    /**
     * 在线支付
     */
    public static final int ONLINE_PAY = 1;
    /**
     * 货到付款
     */
    public static final int PAY_ON_DELIVERY = 2;
    /**
     * 公司转账
     */
    public static final int COMPANY_TRANSFER = 3;
}
