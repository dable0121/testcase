package com.glodon.ngtrade.util.common.constant.common;

public class NgtradeConstant {

  /**
   * 订单系统期望的成功处理返回结果
   */
  public static final String ORDER_EXPECT_SUCCESS_RESP = "success";
  /**
   * 订单系统期望的失败处理返回结果
   */
  public static final String ORDER_EXPECT_FAILURE_RESP = "failure";
  /**
   * 签名key
   */
  public static final String NGTRADE_SIGNATURE_PARAM_NAME = "gSignature";
  /**
   * 广联云签名key
   */
  public static final String GLODON_SIGNATURE_PARAM_NAME = "g_signature";
  /**
   * null字符串
   */
  public static final String NULL_STR = "null";
  /**
   * 0b 0000 0001
   */
  public static final int ONLY_RIGHT_FIRST_BIT_ONE = 1;
  /**
   * 0b 0000 0010
   */
  public static final int ONLY_RIGHT_SECOND_BIT_ONE = 2;
  /**
   * 0b 0000 0100
   */
  public static final int ONLY_RIGHT_THIRD_BIT_ONE = 4;
  /**
   * 整数0
   */
  public static final int INTEGER_ZERO = 0;
  /**
   * 整数1
   */
  public static final int INTEGER_ONE = 1;
  /**
   * 整数2
   */
  public static final int INTEGER_TWO = 2;
  /**
   * 整数3
   */
  public static final int INTEGER_THREE = 3;
  /**
   * 整数100
   */
  public static final int INTEGER_ONE_HUNDRED = 100;
  /**
   * 短整数0
   */
  public static final short SHORT_INTEGER_ZERO = 0;
  /**
   * 短整数1
   */
  public static final short SHORT_INTEGER_ONE = 1;
  /**
   * 长整型-1
   */
  public static final long LONG_MINUS_ONE = -1;
  /**
   * 字符串0.
   */
  public static final String ZERO_STRING = "0";
  /**
   * 比特0.
   */
  public static final byte BYTE_ZERO = 0b0;
  /**
   * 比特1.
   */
  public static final byte BYTE_ONE = 0b1;
  /**
   * 比特2.
   */
  public static final byte BYTE_TOW = 0b10;
  /**
   * 比特9.
   */
  public static final byte BYTE_NINE = 0b1001;
  /**
   * 通用业务成功返回状态码.
   */
  public static final String NGTRADE_RESP_SUCCESS_CODE = "000000";
}
