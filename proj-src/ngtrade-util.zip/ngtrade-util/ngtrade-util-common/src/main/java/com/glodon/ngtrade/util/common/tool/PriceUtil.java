package com.glodon.ngtrade.util.common.tool;

import com.glodon.ngtrade.util.common.exception.NgtradeException;
import java.util.Calendar;

/**
 * Created by Dable on 2017/8/4 10:31.
 */
public class PriceUtil {
	public static long getYearPrice(long lockPrice,int weightSum,int baseNum,long perPrice){
		int diff  = weightSum - baseNum;
		diff = diff<0?0:diff;
		long year = diff * perPrice + lockPrice;
		return year;
	}

	/**
	 * 取整数部分
	 * @param startDate
	 * @param endDate
	 * @param yearPrice
	 * @return
	 */
	public static long getPayPrice(Long startDate,Long endDate,long yearPrice){
		Calendar startC = Calendar.getInstance();
		startC.setTimeInMillis(startDate);
		Calendar endC = Calendar.getInstance();
		endC.setTimeInMillis(endDate);
		int sYear =  startC.get(Calendar.YEAR);
		int sMonth = startC.get(Calendar.MONTH);
		int sDay = startC.get(Calendar.DAY_OF_MONTH);
		int eYear =  endC.get(Calendar.YEAR);
		int eMonth = endC.get(Calendar.MONTH);
		int eDay = endC.get(Calendar.DAY_OF_MONTH);
		long payPrice = 0l;
		int diffDay = DateUtils.daysBetween(startC.getTime(),endC.getTime());
		if(sMonth==eMonth&&sDay==eDay&&sYear!=eYear){
			payPrice = (eYear-sYear)*yearPrice;
		}else if(diffDay>0){
			payPrice = diffDay*yearPrice/365l;
		}else{
			throw NgtradeException.exception("999999","请传入不同的日期");
		}
		return payPrice;
	}

}
