package com.glodon.ngtrade.util.common.exception;


import com.glodon.ngtrade.util.common.code.MessageCode;

/**
 * @author Dable
 * @date 2015年10月13日
 */
public class NgtradeException extends BaseException {

    private static final long serialVersionUID = 1L;

    public static NgtradeException exception(MessageCode.MessageCodeEnum messageCodeEnum, String... args) {
        return NgtradeException.exception(messageCodeEnum.getCode(), MessageCode.getMsg(messageCodeEnum.getCode(), args));
    }

    public static NgtradeException exception(String errorCode) {
        return new NgtradeException(errorCode);
    }

    public static NgtradeException exception(String errorCode, String errorMessage) {
        return new NgtradeException(errorCode, errorMessage);
    }

    public static NgtradeException exception(MessageCode.MessageCodeEnum messageCodeEnum) {
        return NgtradeException.exception(messageCodeEnum.getCode(), messageCodeEnum.getMessage());
    }

    private NgtradeException() {
        super();
    }

    /**
     * @param errorCode 自定义错误编码
     */
    private NgtradeException(String errorCode) {
        super(errorCode);
    }


    /**
     * @param errorCode    自定义错误编码
     * @param errorMessage 自定义错误信息
     */
    private NgtradeException(String errorCode, String errorMessage) {
        super(errorCode, errorMessage);
    }


}
