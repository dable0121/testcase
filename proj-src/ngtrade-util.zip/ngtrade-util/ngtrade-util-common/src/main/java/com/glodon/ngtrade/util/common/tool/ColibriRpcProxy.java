package com.glodon.ngtrade.util.common.tool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.paas.colibri.bean.EmailMessage;
import com.glodon.paas.colibri.bean.SmsMessage;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;
import com.sun.jersey.core.util.Base64;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.ws.rs.core.MediaType;
import java.util.Map;

@Service
@Slf4j
public class ColibriRpcProxy {
    @Value("${colibri.service.key:9j7p95yBTBnTKRHJpeeu8913K2nlQuRD}")
    String appKey;
    @Value("${colibri.service.secret:tHnb8zYi6P1e5jtFdE4D8EXEbL97tD0U}")
    String appSec;
    @Value("${colibri.account.server.url:https://account.glodon.com}/oauth2/token?grant_type=client_credentials")
    String accountServerUrl;
    @Value("${colibri.url.email:https://colibri-test.glodon.com/colibri/api/email}")
    String apiColibriUrlEmail;
    @Value("${colibri.url.sms:https://colibri-test.glodon.com/colibri/api/security/sms}")
    String apiColibriUrlSms;
    private static Client client;


    static {
        ClientConfig config = new DefaultClientConfig();
        config.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
        client = Client.create(config);
    }


    public boolean sendEmail(EmailMessage message, boolean throwException) {
        log.info("EmailMessage=" + JSON.toJSONString(message));
        ClientResponse resp = client.resource(apiColibriUrlEmail)
                .header("Authorization", getAuthorization()).entity(message)
                .type(MediaType.APPLICATION_JSON_TYPE).post(ClientResponse.class);

        if (resp.getStatus() == 200) {
            return true;
        }

        String body = resp.getEntity(String.class);
        log.error("发送邮件异常url={}status={}body={}", apiColibriUrlEmail, resp.getStatus(), body);
        if (throwException) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.SEND_EMAIL_ERROR);
        }
        return false;
    }

    public boolean sendSms(String[] phones, Map<String, Object> params, String templateId,
                           boolean throwException) {
        SmsMessage message = new SmsMessage();
        message.setMobiles(phones);
        message.setTemplateId(templateId);
        message.setParams(params);
        log.info("SmsMessage=" + JSON.toJSONString(message));
        ClientResponse resp = client.resource(apiColibriUrlSms)
                .header("Authorization", getAuthorization()).entity(message)
                .type(MediaType.APPLICATION_JSON_TYPE).post(ClientResponse.class);
        String body = resp.getEntity(String.class);
        if (resp.getStatus() == 200) {
            log.info("短信发送成功 手机号{} 模版id{} 发送内容={}", JSON.toJSONString(phones), templateId,
                    JSON.toJSONString(params));
            return true;
        }
        log.error("发送短信异常url={}status={}body={}", apiColibriUrlSms, resp.getStatus(), body);

        if (throwException) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.SEND_SMS_ERROR);
        }
        return false;
    }


    public String getAuthorization() {
        String authorization;
        ClientResponse resp = client.resource(accountServerUrl)
                .header("Authorization", "Basic " + new String(Base64.encode(appKey + ":" + appSec)))
                .post(ClientResponse.class);
        try {
            String body = resp.getEntity(String.class);
            if (resp.getStatus() == 200) {
                JSONObject json = JSON.parseObject(body);
                log.info("token=" + body);
                authorization = "Bearer " + json.getString("access_token");
            } else {
                log.error("获取Authorization异常url={}status={}body={}", accountServerUrl, resp.getStatus(), body);
                throw NgtradeException.exception(MessageCode.MessageCodeEnum.AUTH_ERROR);
            }
        } catch (Exception e) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.AUTH_ERROR);
        }
        return authorization;
    }


}

