package com.glodon.ngtrade.util.common.excel.dto;

import java.io.InputStream;
import lombok.Data;

@Data
public class LockExcelRequestDTO {
private InputStream inputStream;
private String appKey;
private String appName;
}
