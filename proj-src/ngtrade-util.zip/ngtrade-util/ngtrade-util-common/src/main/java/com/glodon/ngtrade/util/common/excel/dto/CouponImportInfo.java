package com.glodon.ngtrade.util.common.excel.dto;

import com.alibaba.excel.metadata.BaseRowModel;
import lombok.Getter;
import lombok.Setter;
import lombok.SneakyThrows;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author daib
 */
public class CouponImportInfo extends BaseRowModel {

  @Setter
  @Getter
  private Integer serialNumber;

  @Setter
  @Getter
  private String activityNmae;

  @Setter
  @Getter
  private String lockNum;

  @Setter
  @Getter
  private String couponType;


  @Setter
  @Getter
  private String paramValue;


  private Date effectiveTime;


  private Date expiredTime;

  public Date getEffectiveTime() {
    return effectiveTime;
  }

  public void setEffectiveTime(Date effectiveTime) {
    this.effectiveTime = effectiveTime;
  }

  @SneakyThrows
  public void setEffectiveTime(String effectiveTime) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.ddhhmmss");
    this.effectiveTime = sdf
        .parse(new StringBuilder(effectiveTime.trim()).append("000000").toString());
  }

  public Date getExpiredTime() {
    return expiredTime;
  }

  public void setExpiredTime(Date expiredTime) {
    this.expiredTime = expiredTime;
  }

  @SneakyThrows
  public void setExpiredTime(String expiredTime) {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.ddhhmmss");
    this.expiredTime = sdf.parse(new StringBuilder(expiredTime.trim()).append("235959").toString());
  }
}
