package com.glodon.ngtrade.util.common.tool;

import java.security.SecureRandom;

public class Code16CharsGenerate {
  /**
   * 每位允许的字符
   */
  private static final String POSSIBLE_CHARS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

  /**
   * 生产一个指定长度的随机字符串
   */
  public static String generateRandomString() {
    int len = 16;
    StringBuilder sb = new StringBuilder(len);
    SecureRandom random = new SecureRandom();
    for (int i = 0; i < len; i++) {
      sb.append(POSSIBLE_CHARS.charAt(random.nextInt(POSSIBLE_CHARS.length())));
    }
    return sb.toString();
  }
}
