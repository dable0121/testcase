package com.glodon.ngtrade.util.common.tool;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 日期操作工具类
 *
 * @author dable
 */
public class DateUtils {

    private static Logger log = LoggerFactory.getLogger(DateUtils.class);
    public static final String yyyy_MM_dd="yyyy-MM-dd";
    public static final String yyyy_MM_dd_HH_mm_ss="yyyy-MM-dd HH:mm:ss";
    public static final String yyyy_MM_dd_HH_mm_ss_S="yyyy-MM-dd HH:mm:ss.S";
    public static final String yyyyMMddHHmmss="yyyyMMddHHmmss";
    public static final String yyyyMMdd="yyyyMMdd";
    public static final int YYYY_MM_DD_TYPE = 11;
    public static final int YYYYMMDDHHMMSS_TYPE = 5;
    public static final int MMDDYYYY_TYPE = 13;
    public static final int YYYY_MM_DD_HH_MM_SS_TYPE = 12;

    /**
     * 该日期是当月的第几天
     *
     * @param date
     * @return
     * @author dable
     * @time 2014年12月31日下午3:02:29
     */
    public static int getDays(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * 获取当前时间距离明日凌晨的秒数
     *
     * @return
     */
    public static int getCutToZeroTime() {
        Calendar c = Calendar.getInstance();
        long newMills = c.getTimeInMillis();
        c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DATE) + 1, 0, 0, 0);
        long endMills = c.getTimeInMillis();

        return (int) ((endMills - newMills) / 1000);
    }

    /**
     * 根据数字匹配转换格式将日期转换成字符串
     *
     * @param date
     * @param type
     * @return
     */
    public static String dateToStr(Date date, int type) {
        switch (type) {
            case 0:
                return dateToStr(date);
            case 1:
                return dateToStr(date, "yyyy/MM");
            case 2:
                return dateToStr(date, "yyyyMMdd");
            case 11:
                return dateToStr(date, "yyyy-MM-dd");
            case 3:
                return dateToStr(date, "yyyyMM");
            case 4:
                return dateToStr(date, "yyyy/MM/dd HH:mm:ss");
            case 5:
                return dateToStr(date, "yyyyMMddHHmmss");
            case 6:
                return dateToStr(date, "yyyy/MM/dd HH:mm");
            case 7:
                return dateToStr(date, "HH:mm:ss");
            case 8:
                return dateToStr(date, "HH:mm");
            case 9:
                return dateToStr(date, "HHmmss");
            case 10:
                return dateToStr(date, "HHmm");
            case 12:
                return dateToStr(date, "yyyy-MM-dd HH:mm:ss");
            case 13:
                return dateToStr(date, "MM/dd/yyyy");
            case 14:
                return dateToStr(date, "MM/dd/yyyy HH:mm:ss");
            case 15:
                return dateToStr(date, "yyyy-MM-dd HH:mm:ss SSS");
        }
        throw new IllegalArgumentException("Type undefined : " + type);
    }

    public static String dateToStr(Date date, String pattern) {
        if ((date == null) || StringUtils.isBlank(pattern))
            return null;
        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        return formatter.format(date);
    }

    public static String dateToStr(Date date) {
        return dateToStr(date, "yyyy/MM/dd");
    }

    /**
     * 计算两个日期之间相差的天数
     *
     * @param smdate 较小的时间
     * @param bdate  较大的时间
     * @return 相差天数
     */
    public static int daysBetween(Date smdate, Date bdate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            smdate = sdf.parse(sdf.format(smdate));
            bdate = sdf.parse(sdf.format(bdate));
        } catch (ParseException e) {
            log.error("daysBetween error ", e);
            return 0;
        }
        Calendar cal = Calendar.getInstance();
        cal.setTime(smdate);
        long time1 = cal.getTimeInMillis();
        cal.setTime(bdate);
        long time2 = cal.getTimeInMillis();
        long between_days = (time2 - time1) / (1000 * 3600 * 24);

        return Integer.parseInt(String.valueOf(between_days));
    }

    public static Date strToDate(String date, String format) {
        try {
            SimpleDateFormat fmt = new SimpleDateFormat(format);
            return fmt.parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    public static Date longToDate(String time) {
        try {
            Date date = new Date();
            date.setTime(Long.valueOf(time));
            return date;
        } catch (Exception e) {
            log.error("longToDate error ", e);
            return null;
        }
    }

    /**
     * 计算两个日期之间相差的年数(只精确到具体的月)，结果保留1位小数
     *
     * @param smDate 较小的日期
     * @param bDate  较大的日期
     * @return
     * @author dable
     */
    public static double yearsBetween(Date smDate, Date bDate) {
        Calendar smCal = Calendar.getInstance();
        smCal.setTime(smDate);
        Calendar bCal = Calendar.getInstance();
        bCal.setTime(bDate);
        double result = 0;
        double bYear = bCal.get(Calendar.YEAR);
        double bMonth = bCal.get(Calendar.MONTH);
        double smYear = smCal.get(Calendar.YEAR);
        double smMonth = smCal.get(Calendar.MONTH);
        double y = bYear - smYear;
        if (y > 0) {
            result = (y - 1) + Math.round((12 - smMonth + bMonth) / 12d * 10) / 10d;
        } else {
            result = Math.round((bMonth - smMonth) / 12 * 10) / 10d;
        }
        return result;
    }

    /**
     * 在当前日期上加上几天
     *
     * @param curDate
     * @param days
     * @return
     * @author dable
     */
    public static Date addDays(Date curDate, int days) {
        if (curDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(curDate);
            c.add(Calendar.DAY_OF_MONTH, days);
            return c.getTime();
        }
        return null;
    }

    /**
     * 在当前日期上加上几天
     *
     * @param curDate
     * @param years
     * @return
     * @author dable
     */
    public static Date addYears(Date curDate, int years) {
        if (curDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(curDate);
            c.add(Calendar.YEAR, years);
            return c.getTime();
        }
        return null;
    }

    /**
     * 在当前日期上加上几月
     *
     * @param curDate
     * @param Months
     * @return
     * @author dable
     */
    public static Date addMonths(Date curDate, int Months) {
        if (curDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(curDate);
            c.add(Calendar.MONTH, Months);
            return c.getTime();
        }
        return null;
    }

    /**
     * 在当前日期上加上几分钟
     *
     * @param curDate
     * @param minutes
     * @return
     * @author dable
     */
    public static Date addMinutes(Date curDate, int minutes) {
        if (curDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(curDate);
            c.add(Calendar.MINUTE, minutes);
            return c.getTime();
        }
        return null;
    }

    /**
     * 授权终止时间的计算规则
     *
     * @return
     * @throws ParseException
     */
    public static Date calcLimitEndTime(Date limitExpireDate, int monthCount) {
        Date now = Calendar.getInstance().getTime();
        if (limitExpireDate.before(now)) {
            return DateUtils.addMonths(now, monthCount);
        } else {
            return DateUtils.addMonths(limitExpireDate, monthCount);
        }
    }


    public static Date parseDate(String dateStr, String format) throws ParseException {
        SimpleDateFormat sf = new SimpleDateFormat(format);
        return sf.parse(dateStr);
    }

    /**
     * 根据时间戳获取日月年数组
     * @param times
     * @return
     */
    public static short[] getDayMonthYearByTime(long times) {
        Calendar cd = Calendar.getInstance();
        cd.setTimeInMillis(times);
        short sYear = (short)cd.get(Calendar.YEAR);
        short sMonth = (short) (cd.get(Calendar.MONTH)+1);
        short sDay = (short)cd.get(Calendar.DAY_OF_MONTH);
        return new short[]{sDay, sMonth, sYear};
    }

}
