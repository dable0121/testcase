package com.glodon.ngtrade.util.common.tool;

import com.alibaba.fastjson.JSON;
import com.glodon.ngtrade.util.common.xml.AccountInfo;
import com.glodon.ngtrade.util.common.xml.XmlParse;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XmlParseTest {
/** logger */
private static final Logger logger = LoggerFactory.getLogger(XmlParseTest.class);
  @Test
  public void fromXml() {
    String xmlStr =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"   +
        "<root><code>200</code><msg>调用成功</msg><data><info><account>vip250777</account><gid>6050198123841867879</gid><beginTime>2047-12-03 00:00:00.0</beginTime><expireTime>2048-12-02 23:59:59.0</expireTime></info><info><account>vip1803070258</account><gid>6376992469758292279</gid><beginTime>2018-03-12 00:00:00.0</beginTime><expireTime>2019-03-13 23:59:59.0</expireTime></info></data></root>";
    AccountInfo info = XmlParse.fromXml(xmlStr,AccountInfo.class);
    logger.info("转换对象后：{}", JSON.toJSONString(info,false));
  }
}