package com.glodon.ngtrade.util.auth.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author liaolh
 */
@Data
public class EnterpriseCustomerDto implements Serializable {

    // CRM客户ID
    private String crmCustomerId;
    // 客户名称
    private String customerName;
    // 客户分支名称
    private String branchName;


}
