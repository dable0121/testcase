/*
 * Copyright 2016 Glodon Inc. all right reserved. http://www.glodon.com/
 */
package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * 产品功能点
 * </p>
 * 
 * @category LicenseOrderProductFeatureEntity
 * @author zhutw 2016年8月5日
 */
public class LicenseOrderProductFeatureEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    // 功能点编码
    private String featureCode;
    // 功能点名称
    private String featureName;
    // 功能点值
    private String featureValue;
    // 功能点值类型
    private String featureValueType;
    // 是否试用 0 非试用 1试用
    private int trial;
    // 试用结束时间
    private Date trialEndDate;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getFeatureCode() {
        return featureCode;
    }

    public void setFeatureCode(String featureCode) {
        this.featureCode = featureCode;
    }

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }

    public String getFeatureValue() {
        return featureValue;
    }

    public void setFeatureValue(String featureValue) {
        this.featureValue = featureValue;
    }

    public String getFeatureValueType() {
        return featureValueType;
    }

    public void setFeatureValueType(String featureValueType) {
        this.featureValueType = featureValueType;
    }

    public int getTrial() {
        return trial;
    }

    public void setTrial(int trial) {
        this.trial = trial;
    }

    public Date getTrialEndDate() {
        return trialEndDate;
    }

    public void setTrialEndDate(Date trialEndDate) {
        this.trialEndDate = trialEndDate;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
