/*
 * Copyright 2016 Glodon Inc. all right reserved. http://www.glodon.com/
 */
package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.List;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * 授权订单服务参数传输对象
 * </p>
 * 
 * @category 授权订单
 * @author zhutw 2016年8月5日
 */
public class LicenseOrderEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    // 渠道订单号
    private String channelOrderId;
    // 授权客户id
    private String customerId;
    // 客户名称
    private String customerName;
    // 渠道客户编码
    private String channelCustomerId;
    // CRM客户编号
    private String crmCustomerId;
    // 管理员名称
    private String adminName;
    // 管理员邮箱
    private String adminEmail;
    // 管理员手机号码
    private String adminCellNumber;
    // 客户类型
    private String customerType;

    // 宽限期
    private int licenseOfflineValidDays;
    // 渠道编码
    private String channelCode;
    // 渠道名称
    private String channelName;
    // 分支编码
    private String branchCode;
    // 分支名称
    private String branchName;
    // 授权类型
    private String licenseType;
    // 订单下资产
    private List<LicenseOrderAssetEntity> assets;
    // 原订单id，撤销订单使用
    private String srcLicenseOrderId;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getLicenseType() {
        return licenseType;
    }

    public String getCrmCustomerId() {
        return crmCustomerId;
    }

    public void setCrmCustomerId(String crmCustomerId) {
        this.crmCustomerId = crmCustomerId;
    }

    public String getSrcLicenseOrderId() {
        return srcLicenseOrderId;
    }

    public void setSrcLicenseOrderId(String srcLicenseOrderId) {
        this.srcLicenseOrderId = srcLicenseOrderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getChannelOrderId() {
        return channelOrderId;
    }

    public void setChannelOrderId(String channelOrderId) {
        this.channelOrderId = channelOrderId;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }


    public List<LicenseOrderAssetEntity> getAssets() {
        return assets;
    }

    public void setAssets(List<LicenseOrderAssetEntity> assets) {
        this.assets = assets;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getAdminEmail() {
        return adminEmail;
    }

    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }

    public String getAdminCellNumber() {
        return adminCellNumber;
    }

    public void setAdminCellNumber(String adminCellNumber) {
        this.adminCellNumber = adminCellNumber;
    }



    public void setLicenseType(String licenseType) {
        this.licenseType = licenseType;
    }

    public int getLicenseOfflineValidDays() {
        return licenseOfflineValidDays;
    }

    public void setLicenseOfflineValidDays(int licenseOfflineValidDays) {
        this.licenseOfflineValidDays = licenseOfflineValidDays;
    }

    public String getChannelCustomerId() {
        return channelCustomerId;
    }

    public void setChannelCustomerId(String channelCustomerId) {
        this.channelCustomerId = channelCustomerId;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
