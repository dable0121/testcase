package com.glodon.ngtrade.util.auth.rest;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.glodon.ngtrade.util.auth.dto.*;
import com.glodon.ngtrade.util.common.code.MessageCode.MessageCodeEnum;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import com.glodon.ngtrade.util.common.tool.CrmUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.UnknownHttpStatusCodeException;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.MessageFormat;
import java.util.*;

/**
 * @author Dable
 * @date 2017/5/10 21:02
 */
@EnableRetry
@Component
public class NewAuthUtil {

    public final Logger logger = LoggerFactory.getLogger(NewAuthUtil.class);
    @Value("${auth.new.url:http://order-auth-test.glodon.com}/api/order/v1/licenseOrder/newBuy")
    private String authNewUrlBuyUrl;
    @Value("${auth.new.url:http://order-auth-test.glodon.com}/api/order/v1/licenseOrder/queryAsset/")
    private String authLockQueryUrl;
    @Value("${auth.new.url:http://order-auth-test.glodon.com}/api/order/v1/renewOrder/renew")
    private String authNewApiRenewUrl;
    @Value("${auth.new.url:http://order-auth-test.glodon.com}/api/order/v1/licenseOrder/deleteLicenses")
    private String authNewApiDelUrl;
    @Value("${auth.new.url:http://order-auth-test.glodon.com}/api/order/v1/enterprise/user/create")
    private String authCreateAccountUrl;

    @Resource(name = "authRestTemplate")
    private RestTemplate restTemplate;


    @Value("${auth.new.api.url:http://api-auth-test.glodon.com}/api/public/v1/license/list/usbKey/")
    private String authNewApiQueryLicenseUrl;
    @Value("${auth.new.api.url:http://api-auth-test.glodon.com}/api/public/v1/customer/{0}/proInfoAdmin/list")
    private String queryVIPAccountUrl;
    @Value("${auth.new.api.url:http://api-auth-test.glodon.com}/api/public/v1/customer/vip/product")
    private String queryVIPProductInfoUrl;

    /**
     * 重试发送，间隔时间倍增
     */
    public Response authBuyNewWithLockInfo(LicenseOrderEntity authOrderJson, String appKey,
                                           String appSecret) throws IOException {
        StringBuilder url = new StringBuilder(authNewUrlBuyUrl);
        Map<String, String> params = new HashMap<>();
        params.put("appKey", appKey);
        String sign = authSign(url.toString(), JSON.toJSONString(authOrderJson, SerializerFeature.BrowserSecure), appSecret, params);
        url.append("?appKey=").append(appKey);
        logger
                .info("调用[授权接口],url={}body={}appsecret={}sign={}", url.toString(), authOrderJson, appSecret,
                        sign);
        ResponseEntity<JSONObject> restResp = postForResponseAuth(url.toString(), sign, authOrderJson);
        logger.debug("调用[授权接口],返回状态码是：{}", restResp.getStatusCodeValue());
        int statusCode = restResp.getStatusCodeValue();
        if (statusCode == 200) {
            return Response.SUCCESS;
        } else {
            logger.error("调用授权接口返回结果失败，返回状态码是：" + restResp.getStatusCodeValue());
            return Response.SYSTEM_ERROR;
        }
    }


    /**
     * 根据锁号查询授权
     *
     * @param lockNum 纯数字锁号
     */
    public Response<JSONObject> authQueryByLockNoRetry(String lockNum, String appKey,
                                                       String appSecret) throws Exception {
        lockNum = CrmUtil.getDigitAndRemoveLeftZeroFromString(lockNum);
        StringBuilder url = new StringBuilder(authLockQueryUrl);
        url.append(lockNum).append("/");
        Map<String, String> params = new HashMap<>();
        params.put("appKey", appKey);
        String sign = authSign(url.toString(), null, appSecret, params);
        url.append("?appKey=").append(appKey);
        logger.info("locknum{}调用授权查询开始，URL={}", lockNum, url.toString());
        String result = getForStringAuth(url, sign);
        logger.debug("locknum{}调用授权查询返回结果是：{}", lockNum, result);
        JSONObject json = JSON.parseObject(result);
        int statusCode = json.getIntValue("code");
        if (statusCode == 0 && json.get("data") != null) {
            return (Response<JSONObject>) Response.successWithData(json.get("data"));
        } else {
            logger.error("lockNum" + lockNum + "调用授权查询返回结果失败，返回信息：" + result);
            return Response.SYSTEM_ERROR;
        }
    }


    /**
     * 通过锁号查询授权许可信息
     *
     * @param lockNum 锁号,可以是全锁号带字母
     */
    public Response<JSONArray> authQueryGmsidAndLicenseId(String lockNum, String channelOrderIds,
                                                          String featureValues, String productUris, String appKey, String appSecret) {
        logger.info("锁号{}查询授权截止时间开始", lockNum);
        long t1 = System.currentTimeMillis();
        StringBuilder url = new StringBuilder();
        url.append(authNewApiQueryLicenseUrl).append(lockNum);
        Map<String, String> params = new HashMap<>();
        params.put("appKey", appKey);
        if (StringUtils.isNotEmpty(channelOrderIds)) {
            params.put("channelOrderIds", channelOrderIds);
        }
        if (StringUtils.isNotEmpty(featureValues)) {
            params.put("featureKey", "packageId");
            params.put("featureValues", featureValues);
        }
        if (StringUtils.isNotEmpty(productUris)) {
            params.put("productUris", productUris);
        }
        String sign = authSign(url.toString(), null, appSecret, params);
        url.append("?appKey=").append(appKey);
        if (StringUtils.isNotEmpty(channelOrderIds)) {
            url.append("&channelOrderIds=").append(channelOrderIds);
        }
        if (StringUtils.isNotEmpty(featureValues)) {
            url.append("&featureKey=").append("packageId");
            url.append("&featureValues=").append(featureValues);
        }
        if (StringUtils.isNotEmpty(productUris)) {
            url.append("&productUris=").append(productUris);
        }
        logger.info("locknum{}调用[查询授权许可信息]开始，URL={}[sign:{}]", lockNum, url.toString(), sign);
        String result = getForStringAuth(url, sign);
        logger.debug("locknum{}调用[查询授权许可信息]返回结果是：{}", lockNum, result);
        logger.info("锁号{}查询授权截止时间结束", lockNum);
        long t2 = System.currentTimeMillis();
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t2 - t1);
        logger.warn("锁号{}查询授权截止时间耗时: " + c.get(Calendar.MINUTE) + "分 "
                + c.get(Calendar.SECOND) + "秒 "
                + c.get(Calendar.MILLISECOND) + "毫秒", lockNum);
        JSONObject json = JSON.parseObject(result);
        int statusCode = json.getIntValue("code");
        if (statusCode == 0 && json.get("data") != null) {
            return (Response<JSONArray>) Response.successWithData(json.getJSONArray("data"));
        } else {
            logger.error("lockNum" + lockNum + "调用授权查询返回结果失败，返回信息：" + result);
            return Response.SYSTEM_ERROR;
        }
    }


    /**
     * 续费授权接口/删除许可接口
     *
     * @param opt = add , del
     */
    @Retryable(value = {
            NgtradeException.class}, maxAttempts = 2, backoff = @Backoff(delay = 5000L, multiplier = 3))
    public <T> Response<?> authInvoke(Opt opt, T auth, String appKey, String appSecret) {
        Object o = null;
        StringBuilder url = new StringBuilder();
        String optName = null;
        switch (opt) {
            case ADD:
                url.append(authNewApiRenewUrl);
                optName = "续费";
                o = (RenewAuthDTO) auth;
                break;
            case DEL:
                url.append(authNewApiDelUrl);
                optName = "删除";
                o = (DelLicenseDTO) auth;
                break;
        }
        Map<String, String> params = new HashMap<>();
        params.put("appKey", appKey);
        String sign = authSign(url.toString(), JSON.toJSONString(o, SerializerFeature.BrowserSecure), appSecret, params);
        url.append("?appKey=").append(appKey);
        logger.info("调用[{}授权接口]开始，URL={};sign={}", optName, url.toString(), sign);
        ResponseEntity<JSONObject> restResp = postForResponseAuth(url.toString(), sign, o);
        logger.info("调用[{}授权接口]返回状态码是：{}", optName, restResp.getStatusCodeValue());
        int statusCode = restResp.getStatusCodeValue();
        if (statusCode == 200) {
            return Response.SUCCESS;
        } else {
            logger.error("调用" + optName +
                    "授权接口返回结果失败，返回状态码是：" + restResp.getStatusCodeValue());
            return Response.SYSTEM_ERROR;
        }
    }

    @Recover
    public Response recover(NgtradeException e) {
        logger.error("调用授权接口返回结果失败", e);
        return Response.errorWithOtherMsg(e.getErrorCode(), e.getErrorMsg());
    }

    public enum Opt {
        ADD, DEL;

        private Opt() {
        }
    }

    private String getForStringAuth(StringBuilder url, String sign) {
        String result = null;
        try {
            url.append("&g-signature=").append(sign);
            result = restTemplate.getForObject(url.toString(), String.class);
        } catch (UnknownHttpStatusCodeException uhsce) {
            int statusCode = uhsce.getRawStatusCode();
            String jsonStr = uhsce.getResponseBodyAsString();
            if (statusCode == 299) {
                JSONObject json = JSON.parseObject(jsonStr);
                logger.error("调用授权返回状态码(299)异常：" + jsonStr);
                throw NgtradeException.exception(json.getString("code"),
                        json.getString("cause") + "(" + json.getString("message") + ")");
            }
        } catch (Exception e) {
            logger.error("调用授权异常", e);
            throw NgtradeException.exception(MessageCodeEnum.AUTH_ERROR);
        }
        return result;
    }

    private <T> ResponseEntity<JSONObject> postForResponseAuth(String url, String sign, T authJson) {
        ResponseEntity<JSONObject> restResp = null;
        try {
            HttpHeaders headers = new HttpHeaders();
            List<String> list = new ArrayList<>();
            list.add(sign);
            headers.put("g-signature", list);
            headers.put(HttpHeaders.CONTENT_TYPE, Arrays.asList(MediaType.APPLICATION_JSON_UTF8_VALUE));
            HttpEntity<T> httpEntity = new HttpEntity(authJson, headers);
            restResp = restTemplate.postForEntity(url, httpEntity, JSONObject.class);
        } catch (UnknownHttpStatusCodeException uhsce) {
            int statusCode = uhsce.getRawStatusCode();
            String jsonStr = uhsce.getResponseBodyAsString();
            if (statusCode == 299) {
                JSONObject json = JSON.parseObject(jsonStr);
                logger.error("调用[授权接口]返回状态码(299)异常：" + jsonStr);
                throw NgtradeException.exception(json.getString("code"),
                        json.getString("cause") + "(" + json.getString("message") + ")");
            }
        } catch (Exception e) {
            logger.error("调用[授权接口]异常", e);
            throw NgtradeException.exception(MessageCodeEnum.AUTH_ERROR);
        }
        return restResp;
    }

    /**
     * 计算授权申请签名
     *
     * @param jsonBody 要求有序的json
     */
    private String authSign(String url, String jsonBody, String appSecret,
                            Map<String, String> params) {
        Map<String, String> sortedMap = getSortedParamMap(params);
        StringBuilder sb = new StringBuilder(url);
        for (Map.Entry<String, String> entry : sortedMap.entrySet()) {
            String value = null;
            if (entry.getValue() != null) {
                value = entry.getValue();
            }
            //g-signature不参与签名运算
            sb.append("&").append(value);
        }
        if (jsonBody != null) {
            sb.append("&").append(jsonBody);
        }
        sb.append("&").append(appSecret);
        try {
            logger.info("签名串拼接结果：{}", sb.toString());
            byte[] bytes = sb.toString().getBytes("UTF-8");
            String signMsg = DigestUtils.md5Hex(bytes);
            String sign = signMsg.toUpperCase();
            return sign;
        } catch (UnsupportedEncodingException e) {
            logger.error("签名异常", e);
            return null;
        }
    }

    //从request中获取排序的参数列表
    private Map<String, String> getSortedParamMap(Map<String, String> params) {
        Map<String, String> sortedParams = new TreeMap<String, String>();
        for (Map.Entry<String, String> entry : params.entrySet()) {
            String key = entry.getKey();
            if (entry.getValue() != null) {
                sortedParams.put(key, entry.getValue());
                if (logger.isDebugEnabled()) {
                    logger.debug("param:" + key + ":" + (entry.getValue() == null ? null : entry.getValue()));
                }
            }
        }
        return sortedParams;
    }

    private void makeUpAuthUrl(StringBuilder url, String appKey, String sign, String r) {

        String param = "?appKey={0}&g-signature={1}&g_nonce={2}";
        url.append(MessageFormat.format(param, appKey, sign, r));
    }

    /**
     * 获取授权vip账号列表
     *
     * @param crmCustomerId crm 客户id
     */
    public Response<List<GlobalAccount>> getVIPAccounts(String crmCustomerId, String appKey,
                                                        String appSecret) {
        StringBuilder url = new StringBuilder();
        url.append(MessageFormat.format(queryVIPAccountUrl, crmCustomerId));
        Map<String, String> params = new HashMap<>();
        params.put("appKey", appKey);
        double rodam = Math.random();
        String r = String.valueOf(rodam);
        params.put("g_nonce", r);
        String sign = authSign(url.toString(), null, appSecret, params);
        makeUpAuthUrl(url, appKey, sign, r);
        logger.info("获取vip账号列表url为 {}", url.toString());
        try {
            JSONObject result = restTemplate.getForObject(url.toString(), JSONObject.class);
            if (result.getIntValue("code") == 0) {
                JSONArray accountList = result.getJSONArray("data");
                List<GlobalAccount> vipAccounts = new ArrayList<>();
                for (Object jso : accountList) {
                    GlobalAccount ga = new GlobalAccount();
                    JSONObject j = (JSONObject) jso;
                    if (StringUtils.isNotBlank(j.getString("memberGlobalId"))) {
                        ga.setMgid(j.getString("memberGlobalId"));
                    }
                    if (StringUtils.isNotBlank(j.getString("enterpriseGlobalId"))) {
                        ga.setEgid(j.getString("enterpriseGlobalId"));
                    }
                    if (StringUtils.isNotBlank(j.getString("memberAccountIdentity"))) {
                        ga.setAccount(j.getString("memberAccountIdentity"));
                    }
                    vipAccounts.add(ga);
                }
                return (Response<List<GlobalAccount>>) Response.successWithData(vipAccounts);
            } else {
                return (Response<List<GlobalAccount>>) Response
                        .errorWithOtherMsg(result.getIntValue("code") + "", result.getString("cause"));
            }
        } catch (Exception e) {
            logger.error("调用授权异常", e);
            throw NgtradeException.exception(MessageCodeEnum.AUTH_ERROR);
        }
    }

    /**
     * 批量查询vip账号下所有资产数据。包括产品包和产品。
     */
    public Response<Map<String, List<ProductInstance>>> getVipProductInfo(String appKey, String appSecret,
                                                                          String vips,
                                                                          String gmspids,
                                                                          boolean showMerchandiseInstanceList) {
        JSONObject request = new JSONObject();
        request.put("containMerchandise", String.valueOf(showMerchandiseInstanceList));
        if (StringUtils.isNotBlank(gmspids)) {
            request.put("gmsPids", gmspids);
        }
        request.put("licenseType", "cloud_customer");
        if (StringUtils.isNotBlank(vips)) {
            request.put("vipGlobalIds", vips);
        }
        StringBuilder url = new StringBuilder();
        url.append(queryVIPProductInfoUrl);
        Map<String, String> params = new HashMap<>();
        params.put("appKey", appKey);
        String sign = authSign(url.toString(), JSON.toJSONString(request, SerializerFeature.BrowserSecure), appSecret, params);
        url.append("?appKey=").append(appKey);
        logger.info("批量查询vip账号下所有资产数据url为 {}", url.toString());

        try {
            HttpHeaders headers = new HttpHeaders();
            List<String> list = new ArrayList<>();
            list.add(sign);
            headers.put("g-signature", list);
            headers.put(HttpHeaders.CONTENT_TYPE, Arrays.asList(MediaType.APPLICATION_JSON_UTF8_VALUE));
            HttpEntity<JSONObject> httpEntity = new HttpEntity(request, headers);
            ResponseEntity<JSONObject> jsonObjectResponseEntity = restTemplate
                    .postForEntity(url.toString(), httpEntity, JSONObject.class);
            JSONObject result = jsonObjectResponseEntity.getBody();
            if (result.getIntValue("code") == 0) {
                JSONArray returnProd = result.getJSONArray("data");
                Map<String, List<ProductInstance>> rMap = new HashMap<>();
                for (Object o : returnProd) {
                    JSONObject jo = (JSONObject) o;
                    rMap.put(jo.getString("vipGlobalId"), JSONObject.parseArray(jo.getJSONObject("productInfo").getJSONArray("productInstanceList").toJSONString(), ProductInstance.class));
                }
                return (Response<Map<String, List<ProductInstance>>>) Response.successWithData(rMap);
            } else {
                return (Response<Map<String, List<ProductInstance>>>) Response
                        .errorWithOtherMsg(result.getIntValue("code") + "", result.getString("cause"));
            }
        } catch (Exception e) {
            logger.error("调用授权异常", e);
            throw NgtradeException.exception(MessageCodeEnum.AUTH_ERROR);
        }
    }


    /**
     * 创建客户子账号
     *
     * @param crmCustomerId 客户id，必填
     * @param customerName  客户名称，必填
     * @param branchName    分支名称，选填，不填传""
     * @param appKey
     * @param appSecret
     * @return
     */
    public EnterpriseCustomerResponseDto authCreateAccount(String crmCustomerId, String customerName, String branchName, String appKey,
                                                           String appSecret) {
        EnterpriseCustomerResponseDto dto;
        JSONObject request = new JSONObject(true);
        request.put("crmCustomerId", crmCustomerId);
        request.put("customerName", customerName);
        request.put("branchName", branchName);
        StringBuilder url = new StringBuilder(authCreateAccountUrl);
        Map<String, String> params = new HashMap<>();
        params.put("appKey", appKey);
        String sign = authSign(url.toString(), JSON.toJSONString(request, SerializerFeature.BrowserSecure),
                appSecret, params);
        url.append("?appKey=").append(appKey);
        logger
                .info("调用[授权创建客户子账号接口],url={},body={},appsecret={},sign={}", url.toString(),
                        JSON.toJSONString(request, SerializerFeature.BrowserSecure), appSecret,
                        sign);
        ResponseEntity<JSONObject> restResp = postForResponseAuth(url.toString(), sign, request);
        logger.info("调用[授权创建客户子账号接口],返回状态码是：{}", restResp.getStatusCodeValue());
        int statusCode = restResp.getStatusCodeValue();
        if (statusCode == 200 && restResp.getBody() != null) {
            dto =
                    restResp.getBody().getJSONObject("data").toJavaObject(EnterpriseCustomerResponseDto.class);
        } else {
            logger.error("调用[授权创建客户子账号接口] 失败,返回状态码是:{}返回报文是:{}", restResp.getStatusCodeValue(),
                    JSON.toJSONString(restResp.getBody()));
            throw NgtradeException.exception(MessageCodeEnum.ERROR.getCode(), MessageFormat.format("调用[授权创建客户子账号接口] " +
                            "失败,返回状态码是:{0}返回报文是:{1}", restResp.getStatusCodeValue(),
                    JSON.toJSONString(restResp.getBody()))
            );
        }
        return dto;
    }
}
