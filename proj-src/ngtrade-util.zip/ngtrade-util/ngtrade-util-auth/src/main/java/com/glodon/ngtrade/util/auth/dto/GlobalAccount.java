package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import lombok.Data;

@Data
public class GlobalAccount implements Serializable {

  private String account;
  private String mgid;//成员id
  private String egid;//企业id
}
