package com.glodon.ngtrade.util.auth.dto;


import java.io.Serializable;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * 商品实例对象
 *
 * @author wangcf-a
 */
public class MerchandiseInstance extends MerchandiseAndProdBaseEntity implements Serializable {

  private static final long serialVersionUID = 2638204682240865358L;

  private Long id;

  private Constants.LicenseType licenseType;

  private String merchandiseNum;

  private String merchandiseName;

  private Long parentId;

  private String parentMerchandiseNum;

  private String customerId;

  private String licenseOrderId;

  private String channelOrderId;

  private Date createTime;

  private Date updateTime;

  private String channelCode;

  private String timeDurationExpression;

  /**
   * 原订单号
   */
  private String srcLicenseOrderId;

  private List<MerchandiseInstance> children;

  private List<ProductInstance> productInstanceList;

  private String crmProductId;

  public String getCrmProductId() {
    return crmProductId;
  }

  public void setCrmProductId(String crmProductId) {
    this.crmProductId = crmProductId;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Constants.LicenseType getLicenseType() {
    return licenseType;
  }

  public void setLicenseType(Constants.LicenseType licenseType) {
    this.licenseType = licenseType;
  }

  public String getMerchandiseNum() {
    return merchandiseNum;
  }

  public void setMerchandiseNum(String merchandiseNum) {
    this.merchandiseNum = merchandiseNum;
  }

  public Long getParentId() {
    return parentId;
  }

  public void setParentId(Long parentId) {
    this.parentId = parentId;
  }

  public String getParentMerchandiseNum() {
    return parentMerchandiseNum;
  }

  public void setParentMerchandiseNum(String parentMerchandiseNum) {
    this.parentMerchandiseNum = parentMerchandiseNum;
  }

  public String getMerchandiseName() {
    return merchandiseName;
  }

  public void setMerchandiseName(String merchandiseName) {
    this.merchandiseName = merchandiseName;
  }

  public String getCustomerId() {
    return customerId;
  }

  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  public String getLicenseOrderId() {
    return licenseOrderId;
  }

  public void setLicenseOrderId(String licenseOrderId) {
    this.licenseOrderId = licenseOrderId;
  }

  public String getChannelOrderId() {
    return channelOrderId;
  }

  public void setChannelOrderId(String channelOrderId) {
    this.channelOrderId = channelOrderId;
  }

  public Date getCreateTime() {
    return createTime;
  }

  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }

  public Date getUpdateTime() {
    return updateTime;
  }

  public void setUpdateTime(Date updateTime) {
    this.updateTime = updateTime;
  }

  public String getChannelCode() {
    return channelCode;
  }

  public void setChannelCode(String channelCode) {
    this.channelCode = channelCode;
  }

  public String getTimeDurationExpression() {
    return timeDurationExpression;
  }

  public void setTimeDurationExpression(String timeDurationExpression) {
    this.timeDurationExpression = timeDurationExpression;
  }

  public String getSrcLicenseOrderId() {
    return srcLicenseOrderId;
  }

  public void setSrcLicenseOrderId(String srcLicenseOrderId) {
    this.srcLicenseOrderId = srcLicenseOrderId;
  }

  public List<MerchandiseInstance> getChildren() {
    return children;
  }

  public void setChildren(List<MerchandiseInstance> children) {
    this.children = children;
  }

  public List<ProductInstance> getProductInstanceList() {
    return productInstanceList;
  }

  public void setProductInstanceList(List<ProductInstance> productInstanceList) {
    this.productInstanceList = productInstanceList;
  }

  public void addProductIntance(List<ProductInstance> productInstances) {
    if (productInstanceList == null) {
      initProductInstanceList();
    }
    productInstanceList.addAll(productInstances);
  }

  public void addProductIntance(ProductInstance productInstance) {
    if (productInstanceList == null) {
      productInstanceList = new LinkedList<>();
    }
    productInstanceList.add(productInstance);
  }

  public void addMerchandiseInstance(List<MerchandiseInstance> merchandiseInstances) {
    if (children == null) {
      initChildren();
    }
    children.addAll(merchandiseInstances);
  }

  public void addMerchandiseInstance(MerchandiseInstance merchandiseInstance) {
    if (children == null) {
      initChildren();
    }
    children.add(merchandiseInstance);
  }

  private synchronized void initProductInstanceList() {
    if (productInstanceList == null) {
      productInstanceList = new LinkedList<>();
    }
  }

  private synchronized void initChildren() {
    if (children == null) {
      children = new LinkedList<>();
    }
  }
}
