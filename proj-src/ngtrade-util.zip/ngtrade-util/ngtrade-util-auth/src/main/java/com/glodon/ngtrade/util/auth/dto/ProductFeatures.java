/**
  * Copyright 2017 bejson.com 
  */
package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;

/**
 * Auto-generated: 2017-08-06 14:19:25
 *
 * @author dable
 */
public class ProductFeatures implements Serializable {
    private String featureId;
    private String featureName="包Id";// 扩展属性名，必填
    private String featureKey="packageId";// key 为包Id
    private String featureValueType;
    private String featureValue;
    public void setFeatureId(String featureId) {
         this.featureId = featureId;
     }
     public String getFeatureId() {
         return featureId;
     }

    public void setFeatureName(String featureName) {
         this.featureName = featureName;
     }
     public String getFeatureName() {
         return featureName;
     }

    public void setFeatureKey(String featureKey) {
         this.featureKey = featureKey;
     }
     public String getFeatureKey() {
         return featureKey;
     }

    public void setFeatureValueType(String featureValueType) {
         this.featureValueType = featureValueType;
     }
     public String getFeatureValueType() {
         return featureValueType;
     }

    public void setFeatureValue(String featureValue) {
         this.featureValue = featureValue;
     }
     public String getFeatureValue() {
         return featureValue;
     }

}