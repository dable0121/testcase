/**
  * Copyright 2017 bejson.com 
  */
package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Auto-generated: 2017-08-06 14:19:25
 *
 * @author dable
 */
public class RenewAuthDTO implements Serializable {

    private String channelCode;
    private String channelName;
    private String channelOrderId;
    private String branchName;
    private String branchCode;
    private List<AssetProducts> assets;
    public void setChannelCode(String channelCode) {
         this.channelCode = channelCode;
     }
     public String getChannelCode() {
         return channelCode;
     }

    public void setChannelName(String channelName) {
         this.channelName = channelName;
     }
     public String getChannelName() {
         return channelName;
     }

    public void setChannelOrderId(String channelOrderId) {
         this.channelOrderId = channelOrderId;
     }
     public String getChannelOrderId() {
         return channelOrderId;
     }

    public void setBranchName(String branchName) {
         this.branchName = branchName;
     }
     public String getBranchName() {
         return branchName;
     }

    public void setBranchCode(String branchCode) {
         this.branchCode = branchCode;
     }
     public String getBranchCode() {
         return branchCode;
     }

    public void setAssets(List<AssetProducts> assets) {
         this.assets = assets;
     }
     public List<AssetProducts> getAssets() {
         return assets;
     }

}