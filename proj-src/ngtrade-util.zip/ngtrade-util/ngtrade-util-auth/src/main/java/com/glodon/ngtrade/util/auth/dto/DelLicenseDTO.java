/**
 * Copyright 2017 bejson.com
 */
package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Auto-generated: 2017-08-06 15:40:25
 *
 * @author dable

 */
public class DelLicenseDTO implements Serializable{

	private String channelCode;
	private String channelName;
	private String channelOrderId;
	private String branchCode;
	private String branchName;
	private List<DeleteAssets> deleteAssets;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public String getChannelOrderId() {
		return channelOrderId;
	}

	public void setChannelOrderId(String channelOrderId) {
		this.channelOrderId = channelOrderId;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public List<DeleteAssets> getDeleteAssets() {
		return deleteAssets;
	}

	public void setDeleteAssets(List<DeleteAssets> deleteAssets) {
		this.deleteAssets = deleteAssets;
	}
}