/**
  * Copyright 2017 bejson.com 
  */
package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Auto-generated: 2017-08-06 14:19:25
 *
 * @author dable
 */
public class AssetProducts implements Serializable {
    private String assetNum;
    private List<Products> products;
    public void setAssetNum(String assetNum) {
         this.assetNum = assetNum;
     }
     public String getAssetNum() {
         return assetNum;
     }

    public void setProducts(List<Products> products) {
         this.products = products;
     }
     public List<Products> getProducts() {
         return products;
     }

}