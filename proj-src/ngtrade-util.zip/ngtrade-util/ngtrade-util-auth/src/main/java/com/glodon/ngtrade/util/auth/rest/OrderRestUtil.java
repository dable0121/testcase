package com.glodon.ngtrade.util.auth.rest;

import com.alibaba.fastjson.JSON;
import com.glodon.ngtrade.util.common.constant.common.NgtradeConstant;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.response.Response;
import com.glodon.ngtrade.util.common.tool.HttpUtils;
import com.glodon.ngtrade.util.common.tool.SignUtils;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * Created by Dable on 2017/8/19 21:02.
 */
@Retryable
@Component
public class OrderRestUtil<T> {

  public final Logger logger = LoggerFactory.getLogger(OrderRestUtil.class);
  @Value("${order.server.url:http://order.glodon.com}/auth/add")
  private String authAddUrl;
  @Value("${order.server.url:http://order.glodon.com}/auth/del")
  private String authDelUrl;

  @Resource(name = "orderRestTemplate")
  private RestTemplate orderRestTemplate;


  /**
   * @param authT
   * @param appSecret
   * @return
   * @throws Exception
   */
  @Retryable(value = {
      RuntimeException.class}, maxAttempts = 3, backoff = @Backoff(delay = 5000l, multiplier = 3))
  public Response<?> orderAuth(NewAuthUtil.Opt opt, T authT,String appKey, String appSecret) {
    StringBuilder url = new StringBuilder();
    switch (opt) {
      case ADD:
        url.append(authAddUrl);
        break;
      case DEL:
        url.append(authDelUrl);
        break;
    }
    url.append("?appKey=").append(appKey);
    String sign = buildSignString(authT, appSecret);
    logger.info("调用[订单授权接口]开始，URL={};sign={}", url.toString(), sign);
    try {
      HttpHeaders headers = new HttpHeaders();
      headers.put(HttpHeaders.AUTHORIZATION, Arrays.asList(sign));
      headers.put(HttpHeaders.CONTENT_TYPE, Arrays.asList(MediaType.APPLICATION_JSON_UTF8_VALUE));
      HttpEntity httpEntity = new HttpEntity(authT, headers);
      Response restResp = orderRestTemplate
          .postForObject(url.toString(), httpEntity, Response.class);
      logger.info("调用[订单授权接口]返回状态码是：{}", restResp.getCode());
      return restResp;
    } catch (Exception e) {
      logger.error("调用[续费授权接口]异常", e);
      throw e;
    }
  }


  /**
   * 根据querystring请求order系统方法
   */
  @Retryable(value = {
      RuntimeException.class}, maxAttempts = 3, backoff = @Backoff(delay = 5000l, multiplier = 3))
  public Response<?> restByQueryString(HttpServletRequest request, String url, String appSecret) {
    String sign = SignUtils
        .signSHA256QueryStringByHttpRequest(request, appSecret);
    String contentSrcObj = SignUtils
        .convert2AscSortQueryString(HttpUtils.getMapFromHttpRequest(request),
            NgtradeConstant.GLODON_SIGNATURE_PARAM_NAME);
    logger.info("调用[订单接口]开始，URL={};sign={}", url.toString(), sign);
    try {
      StringBuilder sb = new StringBuilder(url);
      sb.append("?");
      sb.append(contentSrcObj);
      sb.append("&").append(NgtradeConstant.GLODON_SIGNATURE_PARAM_NAME).append("=").append(sign);
      Response restResp = orderRestTemplate.getForObject(sb.toString(), Response.class);
      logger.info("调用[订单接口]返回状态码是：{}", restResp.getCode());
      return restResp;
    } catch (Exception e) {
      logger.error("调用[订单接口]异常", e);
      throw e;
    }
  }
  /**
   * 根据querystring请求order系统方法
   */
  @Retryable(value = {
      RuntimeException.class}, maxAttempts = 3, backoff = @Backoff(delay = 5000l, multiplier = 3))
  public Response<?> restByQueryString( String orderId, String url, String appSecret) {
    String sign = buildSignString("orderId="+orderId,appSecret);
    logger.info("调用[订单接口]开始，URL={};sign={}", url.toString(), sign);
    try {
      StringBuilder sb = new StringBuilder(url);
      sb.append("?");
      sb.append("orderId=").append(orderId);
      sb.append("&").append(NgtradeConstant.GLODON_SIGNATURE_PARAM_NAME).append("=").append(sign);
      Response restResp = orderRestTemplate.getForObject(sb.toString(), Response.class);
      logger.info("调用[订单接口]返回状态码是：{}", restResp.getCode());
      return restResp;
    } catch (Exception e) {
      logger.error("调用[订单接口]异常", e);
      throw e;
    }
  }

  /**
   * 构造加密的数据
   */
  protected String buildSignString(T authT, String appSecret) {
    StringBuilder sb = new StringBuilder();
    sb.append(JSON.toJSONString(authT)).append("&").append(appSecret);
    return DigestUtils.sha256Hex(sb.toString());
  }
 /**
   * 构造加密的数据
   */
  protected String buildSignString(String queryString, String appSecret) {
    StringBuilder sb = new StringBuilder();
    sb.append(queryString).append("&").append(appSecret);
    return DigestUtils.sha256Hex(sb.toString());
  }


}
