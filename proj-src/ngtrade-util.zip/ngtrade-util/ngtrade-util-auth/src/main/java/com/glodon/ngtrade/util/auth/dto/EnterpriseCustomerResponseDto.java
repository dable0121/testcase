package com.glodon.ngtrade.util.auth.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author liaolh
 */
@Data
public class EnterpriseCustomerResponseDto implements Serializable {

    private String enterpriseGlobalId;
    private String defaultType;
    private String limitStartTime;
    private String limitEndTime;

    private EnterpriseMember[] members;


}
