package com.glodon.ngtrade.util.auth.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;


/**
 * 常量及枚举定义
 *
 * @author wangcf-a
 */
public class Constants {

  public static final String IMPORTANT_CONFIG_VALUE_ENCRYPT_KEY = "5B3A5EEEE8CC4C37B10E0366D9B09E53";
  public static final int DEFAULT_LICENSE_OFFLINE_VALID_DAYS = 7;
  public static final String DEFAULT_FIXED_ADMIN_PREFIX = "GLODON-";
  public static final String DEFAULT_CLOUD_ACCOUNT_PASSWORD = "88888888";
  public static final String DEFAULT_OPERATOR = "system";
  public static final OperatorType DEFAULT_OPERATORTYPE = OperatorType.systemAuto;

  public static final String KEY_OPERATOR_ID = "operatorId";
  public static final String KEY_OPERATOR_TYPE = "operatorType";

  // session key定义
  public static final String USER_CELL_NUMBER_KAPTCHA_SESSION_KEY = "USER_CELL_NUMBER_KAPTCHA_SESSION_KEY";
  public static final String USER_CELL_NUMBER_SENDING_SESSION_KEY = "USER_CELL_NUMBER_SENDING_SESSION_KEY";
  public static final String REMAINDER_USER_KAPTCHA_TRY_TIMES_SESSION_KEY = "REMAINDER_USER_KAPTCHA_TRY_TIMES_SESSION_KEY";
  public static final String USER_CELL_NUMBER_VALIDATE_RESULT_SESSION_KEY = "USER_CELL_NUMBER_VALIDATE_RESULT_SESSION_KEY";

  public static final String KAPTCHA_SESSION_KEY = "KAPTCHA_SESSION_KEY";
  public static final String CERT_LOGIN_RAND_SESSION_KEY = "CERT_LOGIN_RAND_SESSION_KEY";


  public static final String CRM_CHANNEL_CODE = "CRM";
  public static final String ACCOUNT_CHANNEL_CODE = "account.glodon.com";
  public static final String NGAUTH_CHANNEL_CODE = "auth.glodon.com";
  public static final String UC_CHANNEL_CODE = "UC";
  public static final String CPQ_CHANNEL_CODE = "cpq.glodon.com";

  //定义的虚拟锁，这些虚拟锁供CRM下单时做业务区分用
  public static final String VIRTUAL_USBKEY_NO = "Z0666666";
  public static final String VIRTUAL_USBKEY_NO_OF_VPLATFORM = "V888888";
  public static final String VIRTUAL_USBKEY_NO_OF_CLOUDAUTH = "A000000";
  public static final String VIRTUAL_USBKEY_NO_OF_BIM5D = "B888888";

  // 以YS开头的虚拟锁，属于真实使用的锁，只不过这种锁没有对应的实体硬件资产，采用软件形式作为载体
  public static final String VIRTUAL_USBKEY_MARK = "YS";

  // 默认组织名称格式，ORG_{customerId}_{yyyyMMddHHmmssSSS}
  public static final String DEFAULT_ORG_NAME_FORMAT = "ORG_%s_%s";

  // 迁移资产限制licenseOrderId
  public static final String TRANSFER_LICENSE_ORDER_ID = "qianyilimited";

  //==========系统参数code
  //云授权用户授权浮动节点数key常量
  public static final String CLOUD_FLOATING_NODE_COUNT = "floating_node_count";
  //交易中心产品package id常量
  public static final String PACKAGE_ID = "packageId";
  //CRM产品ID
  public static final String CRM_PRODUCT_ID = "crm_product_id";
  // 产品类别
  public static final String PRODUCT_CATEGORY = "product_category";
  // 节点个数单位
  public static final String NODECOUNT_UNIT = "nodecount_unit";
  // 节点单位数量
  public static final String NODECOUNT_UNIT_QUANTITY = "nodecount_unit_quantity";
  //系统参数 国外分支key
  public static final String DEFAULT_FOREIGN_BRANCH_KEY = "admin_customer_default_branchName";
  //云授权默认分区key
  public static final String DEFAULT_CLOUD_REGION_PARAM_KEY = "cloud_auth_default_region";
  //企业客户支持授权类型黑名单
  public static final String COMPANY_CUSTOMER_LICENSETYPE_BLACKLIST = "company_customer_licenseType_blacklist";
  //个人客户支持授权类型白名单
  public static final String PERSONAL_CUSTOMER_LICENSETYPE_WHITELIST = "personal_customer_licenseType_whiteList";
  //是否校验锁再GSC中的状态开关
  public static final String VALIDATE_GSC_STATUS = "validate_gsc_status";
  //启用异步线程清除缓存的数据量阈值
  public static final String ASYNC_EVCIT_CACHE_THRESHOLD_PARAM_KEY = "async_evcit_cache_threshold";
  //多中心路由统一开关
  public static final String ROUTE_SWITCH_PARAM_CODE = "mutiregion_route_switch";

  // 不受限的数据中心, 可以接受加密锁订单
  public static final String NO_LIMIT_DATACENTER_PARAM_CODE = "no_limit_data_center";

  // 锁号长度不能超过16位
  public static final int MAX_KEY_FULL_NUMBER_LENGTH = 16;

  public static final String DEFAULT_PRO_INFO_ADMIN_PRODUCT_PRIVILEGES = "default_pro_info_admin_product_privileges";

  // GCS需要的图像验证码格式
  public static final int CaptchaLength4GCS = 4;
  public static final int CaptchaWidth4GCS = 90;
  public static final int CaptchaHeight4GCS = 40;

  /**
   * 服务安全检查黑白名单类型
   *
   * @author wangcf-a
   */
  public enum ServiceLimitListType {

    noLimit((short) 0), channelCodeWhiteList((short) 1), channelCodeBlackList(
        (short) 2), ipWhiteList((short) 3), ipBlackList((short) 4);

    private short idx;

    private ServiceLimitListType(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }
  }

  public enum ChannelCode {
    account_glodon_com("用户中心"), activity_glodon_com("活动中心"),
    auth_glodon_com("授权平台"), CRM("CRM"),
    gaptest_glodon_com("GAP"), gdoc_plat_glodon_com("云文档"),
    glodon_my_salesforce_com("SF"), GMS("GMS"),
    gws_glodon_com("G+"), shop_glodon_com("商城"),
    xz_glodon_com("协助"), other("其他");

    private String name;

    private ChannelCode(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }

    public static ChannelCode parse(String name) {
      if (name == null) {
        return other;
      }
      for (ChannelCode channelCode : ChannelCode.values()) {
        if (channelCode.name().equalsIgnoreCase(name.trim().replace(".", "_"))) {
          return channelCode;
        }
      }
      return other;
    }

  }

  /**
   * 授权类型
   *
   * @author zhutw 2016年8月4日
   */
  public enum LicenseType {
    normal_unrecover_usbkey("单机不可补锁"), normal_recover_usbkey("单机可补锁"),
    normal_unrecover_lan_usbkey("网络不可补锁"), normal_recover_lan_usbkey("网络可补锁"),
    identity_usbkey("单机身份锁"), identity_lan_usbkey("网络身份锁"),
    softkey("单机证书"), lan_softkey("网络证书"),
    product_entity("产品实体"), cloud_account("云账号"),
    cloud_customer("企业云账号授权"), cloud_personal("个人云账号授权"),
    lk_product_usbkey("产品锁"), lk_auth_usbkey("登录锁");
    private String name;

    private LicenseType(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }

    public static LicenseType getLicenseTypeByName(String name) {
      if (name == null) {
        return null;
      }
      for (LicenseType licenseType : LicenseType.values()) {
        if (licenseType.name().equals(name)) {
          return licenseType;
        }
      }
      return null;
    }


    /**
     * <p>
     * 将当前枚举类型转换为老授权平台中的授权类型+可补类型的组合
     * </p>
     *
     * @return Map ["type":旧授权类型;"recoverType":是否可补（0-不可补，1-可补）] 对于身份锁，统一返回0-不可补
     * @author dufy
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public Map convertToContainerAndRecoverType() {
      Map result = new HashMap<>();
      switch (this) {
        case normal_recover_usbkey:
          result.put("type", OldContainerType.one_machine_usbkey_s4);
          result.put("recoverType", 1);
          break;
        case normal_unrecover_usbkey:
          result.put("type", OldContainerType.one_machine_usbkey_s4);
          result.put("recoverType", 0);
          break;
        case normal_recover_lan_usbkey:
          result.put("type", OldContainerType.lan_usbkey_s4);
          result.put("recoverType", 1);
          break;
        case normal_unrecover_lan_usbkey:
          result.put("type", OldContainerType.lan_usbkey_s4);
          result.put("recoverType", 0);
          break;
        case identity_usbkey:
          result.put("type", OldContainerType.identity_usbkey_s4);
          result.put("recoverType", 0);
          break;
        case identity_lan_usbkey:
          result.put("type", OldContainerType.identity_lan_usbkey_s4);
          result.put("recoverType", 0);
          break;
        case softkey:
          result.put("type", OldContainerType.one_machine_softkey);
          result.put("recoverType", 0);
          break;
        case lan_softkey:
          result.put("type", OldContainerType.lan_softkey);
          result.put("recoverType", 0);
          break;
        case product_entity:
          result.put("type", OldContainerType.online_product_entity);
          result.put("recoverType", 0);
          break;
        case cloud_account:
        case cloud_customer:
        case cloud_personal:
          result.put("type", OldContainerType.online_cloud_account);
          result.put("recoverType", 0);
          break;
      }
      return result;
    }

    // 是否为可补类型
    public boolean isRecoverType() {
      if (this == normal_recover_usbkey
          || this == normal_recover_lan_usbkey) {
        return true;
      }
      return false;
    }

    // 是否为锁类型
    public boolean isUsbKey() {
      if (this == normal_unrecover_usbkey
          || this == normal_recover_usbkey
          || this == normal_unrecover_lan_usbkey
          || this == normal_recover_lan_usbkey
          || this == identity_usbkey
          || this == identity_lan_usbkey) {
        return true;
      } else {
        return false;
      }
    }
  }

  /**
   * <p>
   * 旧的授权类型
   * </p>
   * <p>
   * 只在兼容老的授权平台的一些接口时使用
   * </p>
   *
   * @author dufy
   */
  public enum OldContainerType {
    none("空"), cloudkey("云锁"),

    identity_usbkey_s4("单机身份锁(S4)"), identity_lan_usbkey_s4("网络身份锁(S4)"), one_machine_usbkey_s4(
        "单机普通锁(S4)"), lan_usbkey_s4(
        "网络普通锁(S4)"), one_machine_softkey("单机证书"), lan_softkey("网络证书"),

    online_cloud_account("云账号在线授权"), online_customer("按客户授权"), online_product_entity(
        "点卡/产品序列号"), online_custom("自定义");

    private String name;

    private OldContainerType(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }
  }

  /**
   * 授权订单类型
   *
   * @author zhutw 2016年8月5日
   */
  public enum LicenseOrderType {

    new_buy("新购"), delete_asset("撤销资产"), delete_product("撤销产品"), change_product("变更产品"),
    exchange_usbkey("换锁"), transfer_usbkey("转锁");

    private String name;

    private LicenseOrderType(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }
  }

  /**
   * <p>
   * 产品类型
   * </p>
   *
   * @author zhutw 2016年8月10日
   * @category ProductType
   */
  public enum ProductType {

    UNDEFINED((short) 0, "未定义"), PC_SOFTWARE((short) 1, "程序"), PC_QUOTA((short) 2,
        "定额"), PC_ALGORITHM((short) 3, "规则"), DATA((short) 4,
        "数据"), CONTENT((short) 5, "内容"), LK((short) 6, "广梦LK");
    private short idx;
    private String name;

    private ProductType(short idx, String name) {
      this.idx = idx;
      this.name = name;
    }

    public short idx() {
      return idx;
    }

    public String getName() {
      return name;
    }

    public static ProductType getProductType(String idx) {
      switch (idx) {
        case "1":
          return ProductType.PC_SOFTWARE;
        case "2":
          return ProductType.PC_QUOTA;
        case "3":
          return ProductType.PC_ALGORITHM;
        case "4":
          return ProductType.DATA;
        case "5":
          return ProductType.CONTENT;
        case "6":
          return ProductType.LK;
      }
      return null;
    }

    public static ProductType getProductTypeFromGmsPid(String gmsPid) {
      if (gmsPid.length() < 2 || gmsPid.charAt(1) == '0') {
        throw new RuntimeException("GmsPid Format error");
      }
      switch (gmsPid.charAt(0)) {
        case '1':
          return ProductType.PC_SOFTWARE;
        case '2':
          return ProductType.PC_QUOTA;
        case '3':
          return ProductType.PC_ALGORITHM;
        case '4':
          return ProductType.DATA;
        case '5':
          return ProductType.CONTENT;
        case '6':
          return ProductType.LK;
        default:
          throw new RuntimeException("GmsPid Format error");
      }
    }

    public static boolean isValidGmsPid(String gmsPid) {
      if (gmsPid != null) {
        try {
          gmsPid = Integer.toString((int) Double.parseDouble(gmsPid));
        } catch (Exception e) {
          return false;
        }
        if (gmsPid.length() >= 2 && gmsPid.charAt(1) != '0') {
          switch (gmsPid.charAt(0)) {
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
              return true;
          }
        }
      }
      return false;
    }

    public static String getName(short idx) {
      for (ProductType t : ProductType.values()) {
        if (t.idx() == idx) {
          return t.getName();
        }
      }
      return null;
    }

  }

  /**
   * 授权订单状态
   *
   * @author zhutw 2016年8月5日
   */
  public enum LicenseOrderStatus {
    unlicensed("未授权"), licensed("已授权"), licensed_failure("授权失败"), revoking("撤销中"), revoke(
        "撤销"), disabled("禁用");
    private String name;

    private LicenseOrderStatus(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }
  }

  /**
   * 客户订单业务类型
   *
   * @author zhutw 2016年8月7日
   */
  public enum CustomerOrderBusinessType {
    new_buy("新购"),
    add_buy("加购"),
    exchange_buy("换购"),
    exchange_one_key("同锁换购"),
    exchange_usbkey("换锁"),
    transfer_usbkey("转锁"),
    free_batch_add("免费批量添加"),
    renew_buy("续费"),
    add_license("加授权");

    private String name;

    private CustomerOrderBusinessType(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }
  }

  /**
   * 订单消息处理结果
   *
   * @author zhutw 2016年8月4日
   */
  public enum OrderMessagePublishResultStatus {
    sendSuccess((short) 0), success((short) 1), failure((short) 2), exception((short) 3);
    private short idx;

    private OrderMessagePublishResultStatus(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }
  }

  /**
   * 业务操作人类型
   */
  public enum OperatorType {
    // 系统自动
    systemAuto((short) 1),
    // 内部超管
    localSuperAdmin((short) 2),
    // 本地客户管理员
    localCustomerAdmin((short) 3),
    // 外部超管
    externalSuperAdmin((short) 4),
    // 外部客户管理员
    externalCustomerAdmin((short) 5),
    // 终端用户
    endUser((short) 6);

    private short idx;

    private OperatorType(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return idx;
    }
  }

  /**
   * 成员角色: 1 大客户管理员 2 国际化管理员 3 固定管理员 4 普通成员 5 大客户普通成员 6 国际化普通成员
   * 7 云授权管理员 8 云授权普通成员 9 个人云账号 10：工信管理员
   *
   * @author yuwb
   */
  public enum MemberRole {
    bigCustomerAdmin((short) 1), internationalAdmin((short) 2), fixedAdmin((short) 3), normal(
        (short) 4),
    bigCustomerNormal((short) 5), internationalNormal((short) 6),
    cloudCustomerAdmin((short) 7), cloudCustomerNormal((short) 8), cloudPersonal(
        (short) 9), proInfoAdmin((short) 10);
    private short idx;

    private MemberRole(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }

    public boolean isCustomerAdmin() {
      switch (this) {
        case bigCustomerAdmin:
        case internationalAdmin:
        case cloudCustomerAdmin:
        case cloudPersonal:
        case proInfoAdmin:
          return true;
        default:
          return false;
      }
    }

    public boolean isNomalMember() {
      switch (this) {
        case bigCustomerNormal:
        case internationalNormal:
        case cloudCustomerNormal:
          return true;
        default:
          return false;
      }
    }

    public boolean isNomalMemberWithCloudPersonal() {
      switch (this) {
        case bigCustomerNormal:
        case internationalNormal:
        case cloudCustomerNormal:
        case cloudPersonal:
          return true;
        default:
          return false;
      }
    }

    public static boolean isNomalMember(List<MemberRole> memberRoles) {
      if (CollectionUtils.isEmpty(memberRoles)) {
        return false;
      }
      if (memberRoles.contains(bigCustomerNormal)
          || memberRoles.contains(internationalNormal)
          || memberRoles.contains(cloudCustomerNormal)
          || memberRoles.contains(cloudPersonal)) {
        return true;
      }
      return false;
    }

    public static MemberRole getNomalByAdmin(MemberRole memberRole) {
      switch (memberRole) {
        case bigCustomerAdmin:
          return bigCustomerNormal;
        case internationalAdmin:
          return internationalNormal;
        case cloudCustomerAdmin:
          return cloudCustomerNormal;
        default:
          return memberRole;
      }
    }

    public static MemberRole getMemberRole(Short idx) {
      switch (idx) {
        case 1:
          return bigCustomerAdmin;
        case 2:
          return internationalAdmin;
        case 3:
          return fixedAdmin;
        case 4:
          return normal;
        case 5:
          return bigCustomerNormal;
        case 6:
          return internationalNormal;
        case 7:
          return cloudCustomerAdmin;
        case 8:
          return cloudCustomerNormal;
        case 9:
          return cloudPersonal;
        case 10:
          return proInfoAdmin;
        default:
          throw new RuntimeException("memberRole type error");
      }
    }
  }

  /**
   * 客户类型：1 个人 2 企业
   *
   * @author yuwb
   */
  public enum CustomerType {
    personal((short) 1), company((short) 2);
    private short idx;

    private CustomerType(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return idx;
    }

    public static CustomerType getCustomerTypeByName(String name) {
      if (name == null) {
        return null;
      }
      for (CustomerType customerType : CustomerType.values()) {
        if (customerType.name().equals(name)) {
          return customerType;
        }
      }
      return null;
    }
  }

  /**
   * 载体分配状态：1 已分配；2 未分配；3 等待解除(占用)
   */
  public enum AssetAssignStatus {
    assigned((short) 1), unassigned((short) 2), expiring((short) 3);
    private short idx;

    private AssetAssignStatus(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }
  }

  /**
   * 许可限制类型
   */
  public enum LicenseLimitType {
    basic("基本限制"), feature("扩展授权点限制");
    private String name;

    private LicenseLimitType(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }
  }

  /**
   * 许可状态
   *
   * @author wangcf-a
   */
  public enum LicenseStatus {

    revoked((short) 0), valid((short) 1), locked((short) 2);
    private short idx;

    private LicenseStatus(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }
  }

  /**
   * <p>
   * 加密锁锁芯片类型
   * </p>
   *
   * @author zhutw 2016年8月12日
   */
  public enum UsbKeyChipType {

    four((short) 1), five((short) 2);
    private short idx;

    private UsbKeyChipType(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }
  }


  /**
   * 授权对象类型
   *
   * @author wangcf-a
   */
  public enum LicenseGranteeType {

    customer("客户"), asset("资产"), employee("员工");
    private String name;

    private LicenseGranteeType(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }

  }

  /**
   * 语系
   *
   * @author yuwb 2016/08/16
   */
  public enum LanguageFamily {
    EN_US("en"), ZH_TW("zh_tw"), ZH_CN("zh_cn");
    private String name;

    private LanguageFamily(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }

    public String getPostFix() {
      String[] arr = name.split("_");
      if (arr.length > 1) {
        return arr[1];
      } else {
        return arr[0];
      }
    }

    public static LanguageFamily getInstance(String languageFamily) {
      for (LanguageFamily value : LanguageFamily.values()) {
        if (StringUtils.equalsIgnoreCase(languageFamily, value.name())) {
          return value;
        }
      }
      //liaolh 2018-11-12 默认返回英文语系，此处是为了语系EN_US("en")格式不对应而特殊设计的
      return EN_US;
    }
  }

  /**
   * 许可查询类型 valid：查有效的（非锁定，非过期）, expired:查过期的（非锁定的）, allNotLocked:所有未锁定的（包括过期的）， all：所有的（包括锁定的和过期的）
   *
   * @author wangcf-a
   */
  public enum LicenseQueryType {

    valid((short) 1), expired((short) 2), allNotLocked((short) 3), all((short) 4);
    private short idx;

    private LicenseQueryType(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }
  }


  /**
   * 绑定状态
   *
   * @author yuwb
   */
  public enum BindStatus {
    unbinded((short) 1), binded((short) 2), needApprove((short) 3), binding((short) 4), expiring(
        (short) 5);
    private short idx;

    private BindStatus(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }
  }


  /**
   * 资料类型
   */
  public enum MaterialType {
    identityCard((short) 0), recoverApplyForm((short) 1);
    private short idx;

    private MaterialType(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }
  }

  /**
   * 补锁处理状态 0：未提交材料 1：已完成补锁 2：取消补锁 3：已提交材料 4：材料审核通过 5：材料审核不通过 6：申请退款
   */
  public enum ProcessResult {
    materialNotSubmitted((short) 0), recoverCompleted((short) 1), recoverCanceled(
        (short) 2), materialSubmitted((short) 3), materialVerified(
        (short) 4), materialUnverified((short) 5), applyRefund((short) 6);

    private short idx;

    private ProcessResult(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }

    public static ProcessResult getProcessResult(Short idx) {
      switch (idx) {
        case 0:
          return materialNotSubmitted;
        case 1:
          return recoverCompleted;
        case 2:
          return recoverCanceled;
        case 3:
          return materialSubmitted;
        case 4:
          return materialVerified;
        case 5:
          return materialUnverified;
        case 6:
          return applyRefund;
        default:
          return null;
      }
    }
  }

  /**
   * 关联状态 0:未认证 1：已认证 2：已申请补锁 3：已取消关联 4：申请补锁成功（已换新锁）
   */
  public enum RelateStatus {
    unrelated((short) 0), related((short) 1), recoverApplied((short) 2), relateCanceled(
        (short) 3), recoverSuccess((short) 4);

    private short idx;

    private RelateStatus(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }

    public static RelateStatus getRelateStatus(short idx) {
      switch (idx) {
        case 0:
          return unrelated;
        case 1:
          return related;
        case 2:
          return recoverApplied;
        case 3:
          return relateCanceled;
        case 4:
          return recoverSuccess;
        default:
          return null;
      }
    }
  }

  /**
   * 重置成员云账号密码返回结果
   */
  public enum ResetPassword {
    inviteSuccess("邀请注册成功"), resetPasswordSuccess("重置密码成功"), exception("重置密码异常");

    private String name;

    private ResetPassword(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }
  }

  /**
   * 1：只从授权平台查询客户信息；
   * 2：在授权平台和crm同时查询；
   * 3：授权平台不存在且crm存在则同步客户数据
   */
  public enum SyncType {
    onlyAuth((short) 1), queryCrm((short) 2), syncCrm((short) 3);
    private short idx;

    private SyncType(short idx) {
      this.idx = idx;
    }
  }


  /**
   * 云授权许可借出状态枚举
   */
  public enum BorrowStatus {

    // 已占用
    occupied((short) 1),
    // 已借出
    borrowed((short) 2),
    // 待归还
    returning((short) 3),
    // 已归还
    returned((short) 4),
    // 待回滚
    rollingBack((short) 5),
    // 回滚失败
    rollBackFailed((short) 6),
    // 未借出状态
    borrowing((short) 7);


    private short idx;

    BorrowStatus(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }
  }

  /**
   * 产品类别
   */
  public enum ProductCategoryEnum {
    memberCount("成员人数"), spaceSize("空间大小");
    private String idx;

    ProductCategoryEnum(String idx) {
      this.idx = idx;
    }

    public static Boolean isValid(String name) {
      for (ProductCategoryEnum e : ProductCategoryEnum.values()) {
        if (e.name().equalsIgnoreCase(name)) {
          return true;
        }
      }
      return false;
    }
  }


  /**
   * 节点单位
   */
  public enum NodeCountUnitEnum {
    G("GB"), M("MB"), K("KB");
    private String idx;

    NodeCountUnitEnum(String idx) {
      this.idx = idx;
    }

    public static Boolean isValid(String name) {
      for (NodeCountUnitEnum e : NodeCountUnitEnum.values()) {
        if (e.name().equalsIgnoreCase(name)) {
          return true;
        }
      }
      return false;
    }
  }

  /**
   * 手机验证用途
   */
  public enum SmsUsage {

    RELATE("认证"), UNRELATE("取消认证"), REGIST_PHONE("注册账号"), BIND_PHOND("绑定手机");

    private String name;

    private SmsUsage(String name) {
      this.name = name;
    }

    public String getName() {
      return name;
    }
  }

  /**
   * 账号类型 1：手机号 2：邮箱 3：用户名 4：用户ID 5:globalid
   */
  public enum IdentityType {
    cellnumber((short) 1), email((short) 2), username((short) 3), userid((short) 4), globalid(
        (short) 5);

    private short idx;

    IdentityType(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return this.idx;
    }

    public static IdentityType getIdentityType(String idx) {
      switch (idx) {
        case "1":
          return cellnumber;
        case "2":
          return email;
        case "3":
          return username;
        case "4":
          return userid;
        case "5":
          return globalid;
        default:
          return null;
      }
    }
  }

  public enum DataCenterRegion {
    // 国内阿里云
    ALIYUN("1"),
    // 新加坡
    SINGAPORE("2"),
    // 法兰克福
    FRANKFURT("2001"),
    // 国内二期
    ERQI("1001");
    private String regionId;

    DataCenterRegion(String regionId) {
      this.regionId = regionId;
    }

    public String getRegionId() {
      return regionId;
    }

    public static DataCenterRegion getInstance(String dataCenter) {
      for (DataCenterRegion value : DataCenterRegion.values()) {
        if (StringUtils.equalsIgnoreCase(dataCenter, value.name())) {
          return value;
        }
      }
      return null;
    }

    /**
     * 校验是否是国内阿里云数据中心
     */
    public static boolean isAliyun(String dataCenter) {
      return ALIYUN == getInstance(dataCenter);
    }

    /**
     * 校验是否是新加坡数据中心
     */
    public static boolean isSingapore(String dataCenter) {
      return SINGAPORE == getInstance(dataCenter);
    }

    /**
     * 校验是否是法兰克福数据中心
     */
    public static boolean isFrankfurt(String dataCenter) {
      return FRANKFURT == getInstance(dataCenter);
    }

    /**
     * 校验是否是国内二期
     */
    public static boolean isErqi(String dataCenter) {
      return ERQI == getInstance(dataCenter);
    }

    @Override
    public String toString() {
      return "DataCenterRegion{" +
          "regionId='" + regionId + '\'' +
          '}';
    }
  }

  /**
   * 广联云账号类型：1 个人 2 企业
   *
   * @author gongm
   */
  public enum CloudAccountType {
    personal((short) 1), company((short) 2);
    private short idx;

    CloudAccountType(short idx) {
      this.idx = idx;
    }

    public short idx() {
      return idx;
    }

  }


}
