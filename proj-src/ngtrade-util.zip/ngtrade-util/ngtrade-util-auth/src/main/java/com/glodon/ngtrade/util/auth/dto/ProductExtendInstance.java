package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * 产品扩展实例对象
 *
 * @author wangcf-a
 */
public class ProductExtendInstance implements Serializable {
    private static final long serialVersionUID = -3685621583168996805L;

    /**
     * 必传项
     */
    private Long id;

    private Long productInsId;

    private String customerId;

    private String limitType;

    private String limitCode;

    private String limitValue;

    private String limitValueUsed;

    private Short limitValueType;

    private Short trial;

    private Date trialEndDate;

    private Date createTime;

    private Date updateTime;

    private String limitName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProductInsId() {
        return productInsId;
    }

    public void setProductInsId(Long productInsId) {
        this.productInsId = productInsId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getLimitType() {
        return limitType;
    }

    public void setLimitType(String limitType) {
        this.limitType = limitType;
    }

    public String getLimitCode() {
        return limitCode;
    }

    public void setLimitCode(String limitCode) {
        this.limitCode = limitCode;
    }

    public String getLimitValue() {
        return limitValue;
    }

    public void setLimitValue(String limitValue) {
        this.limitValue = limitValue;
    }

    public String getLimitValueUsed() {
        return limitValueUsed;
    }

    public void setLimitValueUsed(String limitValueUsed) {
        this.limitValueUsed = limitValueUsed;
    }

    public Short getLimitValueType() {
        return limitValueType;
    }

    public void setLimitValueType(Short limitValueType) {
        this.limitValueType = limitValueType;
    }

    public Short getTrial() {
        return trial;
    }

    public void setTrial(Short trial) {
        this.trial = trial;
    }

    public Date getTrialEndDate() {
        return trialEndDate;
    }

    public void setTrialEndDate(Date trialEndDate) {
        this.trialEndDate = trialEndDate;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getLimitName() {
        return limitName;
    }

    public void setLimitName(String limitName) {
        this.limitName = limitName;
    }
}
