package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;

/**
 * 商品和产品的基类
 */
public class MerchandiseAndProdBaseEntity implements Serializable {
    private static final long serialVersionUID = 2638204682240865358L;

}
