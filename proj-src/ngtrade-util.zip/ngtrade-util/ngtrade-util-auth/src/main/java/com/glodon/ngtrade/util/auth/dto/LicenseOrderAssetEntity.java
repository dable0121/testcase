/*
 * Copyright 2016 Glodon Inc. all right reserved. http://www.glodon.com/
 */
package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * <p>
 * 授权订单包含的资产
 * </p>
 * 
 * @category 授权订单包含的资产
 * @author zhutw 2016年8月5日
 */
public class LicenseOrderAssetEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    // 资产号
    private String[] assetNos;
    // 资产限制开始时间
    private Date limitStartDate;
    // 资产限制结束时间
    private Date limitEndDate;
    // 资产下产品
    private List<LicenseOrderProductEntity> products;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String[] getAssetNos() {
        return assetNos;
    }

    public void setAssetNos(String[] assetNos) {
        if(assetNos!=null && assetNos.length > 0){
            List<String> assetNoList = new ArrayList<String>();
            for(String assetNo : assetNos){
                if(StringUtils.isNotBlank(assetNo)){
                    assetNoList.add(assetNo.trim());
                }
            }
            assetNos = assetNoList.toArray(new String[]{});
        }
        this.assetNos = assetNos;
    }

    public Date getLimitStartDate() {
        return limitStartDate;
    }

    public void setLimitStartDate(Date limitStartDate) {
        this.limitStartDate = limitStartDate;
    }

    public Date getLimitEndDate() {
        return limitEndDate;
    }

    public void setLimitEndDate(Date limitEndDate) {
        this.limitEndDate = limitEndDate;
    }

    public List<LicenseOrderProductEntity> getProducts() {
        return products;
    }

    public void setProducts(List<LicenseOrderProductEntity> products) {
        this.products = products;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
