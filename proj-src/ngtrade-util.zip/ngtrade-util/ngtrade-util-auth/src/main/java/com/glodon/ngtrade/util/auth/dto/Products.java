/**
  * Copyright 2017 bejson.com 
  */
package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Auto-generated: 2017-08-06 14:19:25
 *
 * @author dable
 */
public class Products implements Serializable {
    private String productUri;
    private int limitConcurrent;
    private String productName;
    private int limitCounter;
    private int limitTimeDuration;
    private int limitAmount;
    private long limitStartDate;
    private long limitEndDate;
    private List<ProductFeatures> productFeatures;
    public void setProductUri(String productUri) {
         this.productUri = productUri;
     }
     public String getProductUri() {
         return productUri;
     }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setLimitConcurrent(int limitConcurrent) {
         this.limitConcurrent = limitConcurrent;
     }
     public int getLimitConcurrent() {
         return limitConcurrent;
     }

    public void setLimitCounter(int limitCounter) {
         this.limitCounter = limitCounter;
     }
     public int getLimitCounter() {
         return limitCounter;
     }

    public void setLimitTimeDuration(int limitTimeDuration) {
         this.limitTimeDuration = limitTimeDuration;
     }
     public int getLimitTimeDuration() {
         return limitTimeDuration;
     }

    public void setLimitAmount(int limitAmount) {
         this.limitAmount = limitAmount;
     }
     public int getLimitAmount() {
         return limitAmount;
     }

    public long getLimitStartDate() {
        return limitStartDate;
    }

    public void setLimitStartDate(long limitStartDate) {
        this.limitStartDate = limitStartDate;
    }

    public long getLimitEndDate() {
        return limitEndDate;
    }

    public void setLimitEndDate(long limitEndDate) {
        this.limitEndDate = limitEndDate;
    }

    public void setProductFeatures(List<ProductFeatures> productFeatures) {
         this.productFeatures = productFeatures;
     }
     public List<ProductFeatures> getProductFeatures() {
         return productFeatures;
     }

}