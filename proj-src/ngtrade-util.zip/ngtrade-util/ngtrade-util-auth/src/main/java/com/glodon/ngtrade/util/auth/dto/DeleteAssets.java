package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Dable on 2017/8/18 13:37.
 */
public class DeleteAssets implements Serializable {

	private String assetNum;
	private String licenseType;
	private List<String> licenseIds;
	public void setAssetNum(String assetNum) {
		this.assetNum = assetNum;
	}
	public String getAssetNum() {
		return assetNum;
	}

	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}
	public String getLicenseType() {
		return licenseType;
	}

	public void setLicenseIds(List<String> licenseIds) {
		this.licenseIds = licenseIds;
	}
	public List<String> getLicenseIds() {
		return licenseIds;
	}

}
