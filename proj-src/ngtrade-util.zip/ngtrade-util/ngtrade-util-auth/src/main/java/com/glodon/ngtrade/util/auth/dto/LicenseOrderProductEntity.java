/*
 * Copyright 2016 Glodon Inc. all right reserved. http://www.glodon.com/
 */
package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 订单产品实体
 * </p>
 *
 * @author zhutw 2016年8月5日
 * @category 订单产品实体
 */
public class LicenseOrderProductEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    // productUri或gmsPid或appKey 唯一标识一个产品
    private String productUri;
    // 产品名称
    private String productName;
    // 产品助记符
    private String gmsPid;
    // webapp key
    private String appKey;
    // 产品类型
    private String productType;
    // 产品份数
    private int count;
    // 有效期开始时间 
    private Date limitStartDate;
    // 有效期结束时间 
    private Date limitEndDate;
    // 并发数
    private int limitConcurrent;
    // 限制消费额
    private int limitAmount;
    private long limitTimeDuration;
    // 是否试用 0 非试用 1试用
    private int trial;
    // 试用结束时间 值为0即时间为空
    private Date trialEndDate;

    // 产品功能点集合
    private List<LicenseOrderProductFeatureEntity> productFeatures;

    public String getProductUri() {
        return productUri;
    }

    public void setProductUri(String productUri) {
        if (productUri != null) {
            productUri = productUri.trim();
        }
        this.productUri = productUri;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getGmsPid() {
        return gmsPid;
    }

    public void setGmsPid(String gmsPid) {
        if (gmsPid != null) {
            gmsPid = gmsPid.trim();
        }
        this.gmsPid = gmsPid;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        if (appKey != null) {
            appKey = appKey.trim();
        }
        this.appKey = appKey;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getLimitAmount() {
        return limitAmount;
    }

    public void setLimitAmount(int limitAmount) {
        this.limitAmount = limitAmount;
    }

    public long getLimitTimeDuration() {
        return limitTimeDuration;
    }

    public void setLimitTimeDuration(long limitTimeDuration) {
        this.limitTimeDuration = limitTimeDuration;
    }

    public int getTrial() {
        return trial;
    }

    public void setTrial(int trial) {
        this.trial = trial;
    }

    public List<LicenseOrderProductFeatureEntity> getProductFeatures() {
        return productFeatures;
    }

    public void setProductFeatures(List<LicenseOrderProductFeatureEntity> productFeatures) {
        this.productFeatures = productFeatures;
    }

    public int getLimitConcurrent() {
        return limitConcurrent;
    }

    public void setLimitConcurrent(int limitConcurrent) {
        this.limitConcurrent = limitConcurrent;
    }

    public void setLimitStartDate(Date limitStartDate) {
        this.limitStartDate = limitStartDate;
    }

    public void setLimitEndDate(Date limitEndDate) {
        this.limitEndDate = limitEndDate;
    }

    public Date getLimitStartDate() {
        return limitStartDate;
    }

    public Date getLimitEndDate() {
        return limitEndDate;
    }

    public void setTrialEndDate(Date trialEndDate) {
        this.trialEndDate = trialEndDate;
    }

    public Date getTrialEndDate() {
        return trialEndDate;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }
}
