package com.glodon.ngtrade.util.auth.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author liaolh
 */
@Data
public class EnterpriseMember implements Serializable {

    private String memberGlobalId;
    private String memberIdentity;
    private String password;


}
