package com.glodon.ngtrade.util.auth.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 产品实例对象
 * @author wangcf-a
 */
public class ProductInstance extends MerchandiseAndProdBaseEntity implements Serializable{
    private static final long serialVersionUID = -6052512504479103005L;

    /**
     * 必传项
     */
    private Long id;

    private Constants.LicenseType licenseType;

    private String customerId;

    private String assetId;

    private Long assetInsId;

    private Long merchandiseInsId;

    private String assetNum;

    private String productUri;

    private String gmsPid;

    private String appKey;

    private String productName;

    private String channelCode;

    private String licenseOrderId;

    private String channelOrderId;

    private Date limitStartTime;

    private Date limitEndTime;

    private Integer limitAmount;

    private Integer limitConcurrent;

    private Long limitTimeDuration;

    private Short trial;

    private Date trialEndDate;

    private String limitType;

    private boolean prodDefExtend;

    private String timeDurationExpression;

    /**
     * 原订单号
     */
    private String srcLicenseOrderId;

    private Date createTime;

    private Date updateTime;

    /**
     * 激活标识
     */
    private Boolean activateFlag;

    /**
     * crm产品id
     */
    private String crmProductId;

    private List<ProductExtendInstance> productExtendInstanceList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Constants.LicenseType getLicenseType() {
        return licenseType;
    }

    public void setLicenseType(Constants.LicenseType licenseType) {
        this.licenseType = licenseType;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAssetId() {
        return assetId;
    }

    public void setAssetId(String assetId) {
        this.assetId = assetId;
    }


    public Long getAssetInsId() {
        return assetInsId;
    }

    public void setAssetInsId(Long assetInsId) {
        this.assetInsId = assetInsId;
    }

    public Long getMerchandiseInsId() {
        return merchandiseInsId;
    }

    public void setMerchandiseInsId(Long merchandiseInsId) {
        this.merchandiseInsId = merchandiseInsId;
    }

    public String getAssetNum() {
        return assetNum;
    }

    public void setAssetNum(String assetNum) {
        this.assetNum = assetNum;
    }

    public String getProductUri() {
        return productUri;
    }

    public void setProductUri(String productUri) {
        this.productUri = productUri;
    }

    public String getGmsPid() {
        return gmsPid;
    }

    public void setGmsPid(String gmsPid) {
        this.gmsPid = gmsPid;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getLicenseOrderId() {
        return licenseOrderId;
    }

    public void setLicenseOrderId(String licenseOrderId) {
        this.licenseOrderId = licenseOrderId;
    }

    public String getChannelOrderId() {
        return channelOrderId;
    }

    public void setChannelOrderId(String channelOrderId) {
        this.channelOrderId = channelOrderId;
    }

    public Date getLimitStartTime() {
        return limitStartTime;
    }

    public void setLimitStartTime(Date limitStartTime) {
        this.limitStartTime = limitStartTime;
    }

    public Date getLimitEndTime() {
        return limitEndTime;
    }

    public void setLimitEndTime(Date limitEndTime) {
        this.limitEndTime = limitEndTime;
    }

    public Integer getLimitAmount() {
        return limitAmount;
    }

    public void setLimitAmount(Integer limitAmount) {
        this.limitAmount = limitAmount;
    }

    public Integer getLimitConcurrent() {
        return limitConcurrent;
    }

    public void setLimitConcurrent(Integer limitConcurrent) {
        this.limitConcurrent = limitConcurrent;
    }

    public Long getLimitTimeDuration() {
        return limitTimeDuration;
    }

    public void setLimitTimeDuration(Long limitTimeDuration) {
        this.limitTimeDuration = limitTimeDuration;
    }

    public Short getTrial() {
        return trial;
    }

    public void setTrial(Short trial) {
        this.trial = trial;
    }

    public Date getTrialEndDate() {
        return trialEndDate;
    }

    public void setTrialEndDate(Date trialEndDate) {
        this.trialEndDate = trialEndDate;
    }

    public String getLimitType() {
        return limitType;
    }

    public void setLimitType(String limitType) {
        this.limitType = limitType;
    }

    public boolean isProdDefExtend() {
        return prodDefExtend;
    }

    public void setProdDefExtend(boolean prodDefExtend) {
        this.prodDefExtend = prodDefExtend;
    }

    public String getTimeDurationExpression() {
        return timeDurationExpression;
    }

    public void setTimeDurationExpression(String timeDurationExpression) {
        this.timeDurationExpression = timeDurationExpression;
    }

    public String getSrcLicenseOrderId() {
        return srcLicenseOrderId;
    }

    public void setSrcLicenseOrderId(String srcLicenseOrderId) {
        this.srcLicenseOrderId = srcLicenseOrderId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getActivateFlag() {
        return activateFlag;
    }

    public void setActivateFlag(Boolean activateFlag) {
        this.activateFlag = activateFlag;
    }

    public List<ProductExtendInstance> getProductExtendInstanceList() {
        return productExtendInstanceList;
    }

    public void setProductExtendInstanceList(List<ProductExtendInstance> productExtendInstanceList) {
        this.productExtendInstanceList = productExtendInstanceList;
    }

    public String getCrmProductId() {
        return crmProductId;
    }

    public void setCrmProductId(String crmProductId) {
        this.crmProductId = crmProductId;
    }
}
