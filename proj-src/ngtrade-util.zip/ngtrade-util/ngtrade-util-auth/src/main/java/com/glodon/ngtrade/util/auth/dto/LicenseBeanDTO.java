package com.glodon.ngtrade.util.auth.dto;

import com.alibaba.fastjson.JSON;
import com.glodon.ngtrade.util.common.tool.DateUtils;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by gongm on 2017/8/2.
 */
public class LicenseBeanDTO implements Serializable {


	/**
	 * channelOrderId : 渠道订单编号
	 * licenseId : 0e22dd71896242e5b2930087d9a4a4c0
	 * licenseType : 授权类型
	 * limitAmount : 1
	 * limitConcurrent : 1
	 * limitEndDate : 1500979312000
	 * limitStartDate : 1500892912000
	 * limitTimeDuration : 1
	 * productFeatures : [{"featureKey":"授权扩展项编号","featureValue":"授权扩展项值"}]
	 * productGmsPid : 产品助记符
	 * productName : 客户名称
	 * productUri : 产品统一标识
	 */

	private String channelOrderId;
	private String licenseId;
	private String licenseType;
	private int limitAmount;
	private int limitConcurrent;
	private long limitEndDate;
	private long limitStartDate;
	private int limitTimeDuration;
	private String productGmsPid;
	private String productName;
	private String productUri;


	/**
	 * 更新开始时间时分秒为000000或者当前
	 */
	public void updateLimitStartDate() {
		Date nowDate = new Date();
		long nowLong = nowDate.getTime();
		long nowLong000000 = DateUtils
				.strToDate(DateUtils.dateToStr(nowDate, DateUtils.YYYY_MM_DD_TYPE) + " 00:00:00", DateUtils.yyyy_MM_dd_HH_mm_ss).getTime();
		long startLong000000 = DateUtils.strToDate(DateUtils.dateToStr(new Date(this.limitStartDate), DateUtils.YYYY_MM_DD_TYPE) + " 00:00:00", DateUtils.yyyy_MM_dd_HH_mm_ss).getTime();
		this.limitStartDate = this.limitStartDate < nowLong ? nowLong000000 : startLong000000;
	}

	/**
	 * 更新截止时间时分秒为235959
	 */
	public void updateLimitEndDate() {
		long endLong235959 = DateUtils.strToDate(DateUtils.dateToStr(new Date(this.limitEndDate), DateUtils.YYYY_MM_DD_TYPE) + " 23:59:59", DateUtils.yyyy_MM_dd_HH_mm_ss).getTime();
		this.limitEndDate = endLong235959;
	}

	/**
	 * featureKey : 授权扩展项编号
	 * featureValue : 授权扩展项值
	 */
	private List<ProductFeaturesBean> productFeatures;

	public String getChannelOrderId() {
		return channelOrderId;
	}

	public void setChannelOrderId(String channelOrderId) {
		this.channelOrderId = channelOrderId;
	}

	public String getLicenseId() {
		return licenseId;
	}

	public void setLicenseId(String licenseId) {
		this.licenseId = licenseId;
	}

	public String getLicenseType() {
		return licenseType;
	}

	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}

	public int getLimitAmount() {
		return limitAmount;
	}

	public void setLimitAmount(int limitAmount) {
		this.limitAmount = limitAmount;
	}

	public int getLimitConcurrent() {
		return limitConcurrent;
	}

	public void setLimitConcurrent(int limitConcurrent) {
		this.limitConcurrent = limitConcurrent;
	}

	public long getLimitEndDate() {
		return limitEndDate;
	}

	public void setLimitEndDate(long limitEndDate) {
		this.limitEndDate = limitEndDate;
	}

	public long getLimitStartDate() {
		return limitStartDate;
	}

	public void setLimitStartDate(long limitStartDate) {
		this.limitStartDate = limitStartDate;
	}

	public int getLimitTimeDuration() {
		return limitTimeDuration;
	}

	public void setLimitTimeDuration(int limitTimeDuration) {
		this.limitTimeDuration = limitTimeDuration;
	}

	public String getProductGmsPid() {
		return productGmsPid;
	}

	public void setProductGmsPid(String productGmsPid) {
		this.productGmsPid = productGmsPid;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductUri() {
		return productUri;
	}

	public void setProductUri(String productUri) {
		this.productUri = productUri;
	}

	public List<ProductFeaturesBean> getProductFeatures() {
		return productFeatures;
	}

	public void setProductFeatures(List<ProductFeaturesBean> productFeatures) {
		this.productFeatures = productFeatures;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		LicenseBeanDTO that = (LicenseBeanDTO) o;

		if (limitAmount != that.limitAmount) return false;
		if (limitConcurrent != that.limitConcurrent) return false;
		if (limitEndDate != that.limitEndDate) return false;
		if (limitStartDate != that.limitStartDate) return false;
		if (limitTimeDuration != that.limitTimeDuration) return false;
		if (channelOrderId != null ? !channelOrderId.equals(that.channelOrderId) : that.channelOrderId != null)
			return false;
		if (!licenseId.equals(that.licenseId)) return false;
		if (licenseType != null ? !licenseType.equals(that.licenseType) : that.licenseType != null) return false;
		if (productGmsPid != null ? !productGmsPid.equals(that.productGmsPid) : that.productGmsPid != null)
			return false;
		if (productName != null ? !productName.equals(that.productName) : that.productName != null) return false;
		if (!productUri.equals(that.productUri)) return false;
		return productFeatures.equals(that.productFeatures);
	}

	@Override
	public int hashCode() {
		int result = channelOrderId != null ? channelOrderId.hashCode() : 0;
		result = 31 * result + licenseId.hashCode();
		result = 31 * result + (licenseType != null ? licenseType.hashCode() : 0);
		result = 31 * result + limitAmount;
		result = 31 * result + limitConcurrent;
		result = 31 * result + (int) (limitEndDate ^ (limitEndDate >>> 32));
		result = 31 * result + (int) (limitStartDate ^ (limitStartDate >>> 32));
		result = 31 * result + limitTimeDuration;
		result = 31 * result + (productGmsPid != null ? productGmsPid.hashCode() : 0);
		result = 31 * result + (productName != null ? productName.hashCode() : 0);
		result = 31 * result + productUri.hashCode();
		result = 31 * result + productFeatures.hashCode();
		return result;
	}

	public static class ProductFeaturesBean {
		private String featureKey;
		private String featureValue;

		public String getFeatureKey() {
			return featureKey;
		}

		public void setFeatureKey(String featureKey) {
			this.featureKey = featureKey;
		}

		public String getFeatureValue() {
			return featureValue;
		}

		public void setFeatureValue(String featureValue) {
			this.featureValue = featureValue;
		}
	}

	/**
	 * Returns a string representation of the object. In general, the
	 * {@code toString} method returns a string that
	 * "textually represents" this object. The result should
	 * be a concise but informative representation that is easy for a
	 * person to read.
	 * It is recommended that all subclasses override this method.
	 * <p>
	 * The {@code toString} method for class {@code Object}
	 * returns a string consisting of the name of the class of which the
	 * object is an instance, the at-sign character `{@code @}', and
	 * the unsigned hexadecimal representation of the hash code of the
	 * object. In other words, this method returns a string equal to the
	 * value of:
	 * <blockquote>
	 * <pre>
	 * getClass().getName() + '@' + Integer.toHexString(hashCode())
	 * </pre></blockquote>
	 *
	 * @return a string representation of the object.
	 */
	@Override
	public String toString() {
		return JSON.toJSONString(this, false);
	}

}
