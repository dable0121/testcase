package com.glodon.ngtrade.util.auth.rest;

import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter4;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.servlet.MultipartConfigElement;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.util.unit.DataSize;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

@Configuration
@ComponentScan(basePackages = "com.glodon.ngtrade.util.auth")
public class RestTemplateConfig {
    @Bean
    public MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        //  单个数据大小
        factory.setMaxFileSize(DataSize.ofMegabytes(300)); // KB,MB
        /// 总上传数据大小
        factory.setMaxRequestSize(DataSize.ofMegabytes(500));
        return factory.createMultipartConfig();
    }
    @Bean
    public HttpComponentsClientHttpRequestFactory httpRequestFactory() {
        HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory(HttpClientBuilder.create()
                .disableContentCompression()
                .setMaxConnPerRoute(200)
                .setMaxConnTotal(400).setConnectionTimeToLive(90L, TimeUnit.SECONDS).build());
        httpRequestFactory.setConnectionRequestTimeout(1000);
        httpRequestFactory.setConnectTimeout(5000);
        httpRequestFactory.setReadTimeout(1200000);
        httpRequestFactory.setBufferRequestBody(false);
        return httpRequestFactory;
    }

    private List<HttpMessageConverter<?>> httpMessageConverter() {
        List<HttpMessageConverter<?>> list = new ArrayList<>();
        StringHttpMessageConverter stringHttpMessageConverter = new StringHttpMessageConverter(Charset.forName("UTF-8"));
        FastJsonHttpMessageConverter4 fastjson = new FastJsonHttpMessageConverter4();
        List<MediaType> medisList = new ArrayList<>();
        medisList.add(MediaType.TEXT_HTML);
        medisList.add(MediaType.APPLICATION_JSON_UTF8);
        fastjson.setSupportedMediaTypes(medisList);
        list.add(0,fastjson);
        list.add(1,stringHttpMessageConverter);
        return list;
    }

    @Bean(name = "orderRestTemplate")
    @Scope(value = "singleton")
    public RestTemplate orderRestTemplate(@Autowired HttpComponentsClientHttpRequestFactory httpRequestFactory) {
        final RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
        restTemplate.setMessageConverters(httpMessageConverter());
        return restTemplate;
    }
    @Bean(name = "authRestTemplate")
    @Scope(value = "singleton")
    public RestTemplate authRestTemplate(@Autowired HttpComponentsClientHttpRequestFactory httpRequestFactory) {
        final RestTemplate restTemplate = new RestTemplate(httpRequestFactory);
        restTemplate.setMessageConverters(httpMessageConverter());
        return restTemplate;
    }
}