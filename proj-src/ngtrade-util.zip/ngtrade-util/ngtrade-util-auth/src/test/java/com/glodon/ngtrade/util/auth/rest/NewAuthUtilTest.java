package com.glodon.ngtrade.util.auth.rest;

import com.alibaba.fastjson.JSON;
import com.glodon.ngtrade.util.auth.dto.GlobalAccount;
import com.glodon.ngtrade.util.auth.dto.ProductInstance;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.response.Response;
import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@ContextConfiguration(classes = RestTemplateConfig.class)
@ActiveProfiles("dev")
@RunWith(SpringRunner.class)
@SpringBootTest
public class NewAuthUtilTest {

  @Value("${auth.service.key}")
  private String key;
  @Value("${auth.service.secret}")
  private String secret;
  @Autowired
  private NewAuthUtil newAuthUtil;
  /**
   * logger
   */
  private static final Logger logger = LoggerFactory.getLogger(NewAuthUtilTest.class);

  @Test
  public void getVIPAccountsTest() {
    Response<List<GlobalAccount>> vipAccounts = newAuthUtil.getVIPAccounts("1-2GZJ5O", key,secret);
    Response<List<GlobalAccount>> vipAccountss = newAuthUtil.getVIPAccounts("1-164NB3", key,secret);
    logger.info("vipAccounts=" + JSON.toJSONString(vipAccounts));
    logger.info("vipAccounts1-164NB3=" + JSON.toJSONString(vipAccountss));
    Assert.assertEquals(MessageCode.SUCCESS, vipAccounts.getCode());
    Assert.assertNotNull(vipAccounts.getData());
    String vips = "6496282780782576375";
    List<GlobalAccount> gidList = vipAccounts.getData();
    List<String> mgids = gidList.stream().map(GlobalAccount::getMgid)
            .collect(Collectors.toList());
    String vipmGids = StringUtils.join(mgids, ",");
    Response<Map<String,List<ProductInstance>>> vipProductInfo = newAuthUtil
        .getVipProductInfo(key,secret, vipmGids, "42486,12333,14555", false);
    logger.info("vipProductInfo=" + JSON.toJSONString(vipProductInfo));
    List<String> collect = vipAccountss.getData().stream().map(GlobalAccount::getMgid)
        .collect(Collectors.toList());
    String vipss = org.apache.commons.lang.StringUtils.join(collect,",");
    Response<Map<String,List<ProductInstance>>> vipProductInfo1 = newAuthUtil
        .getVipProductInfo(key,secret, vipss, "", false);
    logger.info("vipProductInfo-vipss=" + JSON.toJSONString(vipProductInfo1));
    Assert.assertNotNull(vipProductInfo.getData());
  }
}