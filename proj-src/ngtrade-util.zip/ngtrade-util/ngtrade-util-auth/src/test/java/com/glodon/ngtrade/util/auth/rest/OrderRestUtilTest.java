package com.glodon.ngtrade.util.auth.rest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = RestTemplateConfig.class)
public class OrderRestUtilTest {

  @Autowired
  private OrderRestUtil orderRestUtil;

  @Test
  public void testContextLoad() {
  }
  @Test
  public void orderAuth() {
//    orderRestUtil.orderAuth(Opt.ADD,,xxx);
  }
}
