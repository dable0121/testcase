package com.glodon.ngtrade.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.data.redis.core.script.RedisScript;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Modify by Dable on 2019/04/26 16:55
 * <p>
 * SnowFlake的结构如下(每部分用-分开):
 * 0 - 0000000000 0000000000 0000000000 0000000000 0000 0000 - 0000 0000 - 00  -  00000
 * -----------------------------------------------------------------------------
 * 1位标识，由于long基本类型在Java中是带符号的，最高位是符号位，正数是0，负数是1，所以id一般是正数，最高位是0
 * 48位时间截(微秒)，注意，48位时间截不是存储当前时间的时间截，而是存储时间截的微秒差值（当前时间截 - 开始时间截)
 * 得到的值）
 * 8位的数据机器IP位
 * 2位数据中心位
 * 5位序列
 * 加起来刚好64位long
 *
 * 测试结果：目前10秒内10w个并发没有产生冲突id，应该完全可以避免并发重复id
 */
public class SnowflakeIdGenerator {

    private RedisTemplate redisTemplate;

    private static final Logger logger = LoggerFactory.getLogger(SnowflakeIdGenerator.class);

    //==============================Constructors=====================================

    /**
     * 构造函数
     * 数据中心不再需要区分，保证redis服务为同一个服务就可以唯一。
     *
     * @param datacenterId 数据中心ID (0~3)
     */
    @Deprecated
    public SnowflakeIdGenerator(long datacenterId, RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    /**
     * 构造函数
     */
    public SnowflakeIdGenerator(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }


    /**
     * 工作机器IP(0~255)
     */
    private static long IP;

    static {
        try {
            InetAddress addr = InetAddress.getLocalHost();
            String addrIp = addr.getHostAddress();
            IP = Long.parseLong(addrIp.substring(addrIp.lastIndexOf(".") + 1));
        } catch (UnknownHostException e) {
            logger.error("获取本地ip地址异常，", e);
        }

    }
    // ==============================Fields===========================================
    /**
     * 开始时间截 微秒单位 (2017/01/01 00:00:00 000 000 )
     */
    private static final long STARTTIME = 1483200000000000L;

    /**
     * 机器ip所占的位数
     */
    private static final long IPBITS = 8L;

    /**
     * 序列在id中占的位数
     */
    private static final long SEQUENCEBITS = 5L;

    /**
     * 数据标识id所占的位数
     */
    private static final long DATACENTERIDBITS = 2L;

    /**
     * ip向左移
     */
    private static final long IPSHIFT = SEQUENCEBITS + DATACENTERIDBITS;

    /**
     * 时间截向左移
     */
    private static final long TIMESTAMPLEFTSHIFT = IPBITS + IPSHIFT;

    /**
     * 数据标识向左移12位
     */
    private static final long DATACENTERIDSHIFT = SEQUENCEBITS;


    // ==============================Methods==========================================

    /**
     * 获得下一个ID (该方法是分布式并发安全的)
     *
     * @return SnowflakeId
     */
    public long nextId() {
        long current = getRedisTime();
        return ((current - STARTTIME) << TIMESTAMPLEFTSHIFT)
                | (IP << IPSHIFT)
                | (1L << DATACENTERIDSHIFT)
                | (1L << (DATACENTERIDSHIFT - 1));
    }


    /**
     * @return 当前时间(微秒)
     */
    private long getRedisTime() {
        List<Integer> keys = new ArrayList<>();
        RedisScript<List> script = new DefaultRedisScript<>(
                "local time = redis.call('time'); return time;", List.class);
        List<Integer> timeList = (List<Integer>) redisTemplate
                .execute(script, keys, new Object[]{});
        String current = timeList.get(0).toString() + String.format("%06d",
                timeList.get(1));
        //锁1毫秒，保证微秒内的序列被占用
        if (redisTemplate.opsForValue().setIfAbsent(current,
                "1", 5,
                TimeUnit.SECONDS)) {
            return Long.parseLong(current);
        } else {
            return getRedisTime();
        }
    }

}
