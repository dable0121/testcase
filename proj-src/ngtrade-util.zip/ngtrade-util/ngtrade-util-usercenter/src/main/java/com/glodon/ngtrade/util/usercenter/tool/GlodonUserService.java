package com.glodon.ngtrade.util.usercenter.tool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.usercenter.dto.UserDTO;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Base64;

/**
 * @author zhangb-l , modify by dable
 */
@Component
@Slf4j
public class GlodonUserService {
    @Resource(name = "devRestTemplate")
    private RestTemplate restTemplate;
    @Value("${cas.host:https://account.glodon.com}/v3/api/security/userinfobyid?identity={0}")
    private String url_format;
    @Value("${cas.key:9j7p95yBTBnTKRHJpeeu8913K2nlQuRD}")
    private String app_key;
    @Value("${cas.secret:tHnb8zYi6P1e5jtFdE4D8EXEbL97tD0U}")
    private String app_secret;


    /**
     * {
     * "id": 5748794830606036993,
     * "fullname": "黄诚139",
     * "username": null,
     * "email": null,
     * "mobile": "13916728412",
     * "globalId": "2764345",
     * "gender": "m",
     * "birthday": null,
     * "qq": null,
     * "company": null,
     * "avatarPath": ["https://account.glodon.com/avatar/show/5748794830606036993/32",
     * "https://account.glodon.com/avatar/show/5748794830606036993/48",
     * "https://account.glodon.com/avatar/show/5748794830606036993/120",
     * "https://account.glodon.com/avatar/show/5748794830606036993/200"],
     * "avatarETag": "5a1bc6f5adf27c2ee7d9625a7e18ca2c",
     * "displayName": "黄诚139",
     * "strId": "5748794830606036993",
     * "nickname": "黄诚139",
     * "accountName": "13916728412",
     * "createTime": "2013-06-07 23:38:15",
     * "passwordStrength": 1,//0：未设置 1：弱 2：中 3：强
     * "passwordMobile": "13916728412",
     * "verified": true,
     * "mobileVerified": true,
     * "emailVerified": false,
     * "enterpriseUser": false,
     * "defaultAvatar": true,
     * "agreeGDPR":false//是否同意GDPR隐私协议，仅在国际化用户中心返回，国内接口不返回
     * }
     *
     * @param identity
     * @return
     */
    @SneakyThrows
    public UserDTO getUserInfo(String identity) {
        try {
            identity = URLEncoder.encode(identity, StandardCharsets.UTF_8.name());
            String url = MessageFormat.format(url_format, identity);
            HttpHeaders h = new HttpHeaders();
            h.put(
                    "Authorization",
                    Arrays.asList(
                            "Basic " +
                                    Base64.getEncoder()
                                            .encodeToString(
                                                    MessageFormat.format("{0}:{1}", app_key
                                                            , app_secret).getBytes(StandardCharsets.UTF_8.name()))
                    )
            );
            h.setContentType(MediaType.APPLICATION_JSON_UTF8.APPLICATION_JSON);
            h.setAccept(Arrays.asList(MediaType.APPLICATION_JSON_UTF8.APPLICATION_JSON));
            ResponseEntity<JSONObject> responseEntity = restTemplate
                    .exchange(url,
                            HttpMethod.GET,
                            new HttpEntity(null, h),
                            JSONObject.class);
            if (responseEntity.getStatusCodeValue() == 200 && responseEntity.getBody().getIntValue(
                    "code") == 0 && responseEntity.getBody() != null) {
                UserDTO user = JSONObject.parseObject(responseEntity.getBody().getString("data"), UserDTO.class);
                log.info(" userid:{} info:{}", identity, JSON.toJSONString(user));
                return user;
            } else {

                if (responseEntity.getBody() != null) {
                    log.error("id{}调用用户中心接口异常{}", identity, JSON.toJSONString(responseEntity.getBody()));
                    throw NgtradeException.exception(responseEntity.getBody().getString("code"),
                            responseEntity.getBody().getString("message"));
                }
                log.error("id{}调用用户中心接口异常", identity);
                throw NgtradeException.exception(MessageCode.MessageCodeEnum.ERROR.getCode(),
                        "调用用户中心接口异常");
            }
        } catch (Exception e) {
            log.error("用户id" + identity + "调用用户中心获取用户信息异常", e);
            return null;
        }
    }


}
