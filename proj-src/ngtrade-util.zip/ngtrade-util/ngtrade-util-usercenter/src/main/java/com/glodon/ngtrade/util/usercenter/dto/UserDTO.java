package com.glodon.ngtrade.util.usercenter.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String id;
    private String fullname;
    private String username;
    private String email;
    private String mobile;
    private String globalId;
    private String gender;
    private String birthday;
    private String qq;
    private String company;
    private String displayName;
    private String nickname;
    private String accountName;
    private String emailVerified;
    private String mobileVerified;
    private String verified;
    private String enterpriseUser;
    private String passwordStrength;//0：未设置 1：弱 2：中 3：强
    private String passwordMobile;
}
