package com.glodon.ngtrade.util.devcenter.rest.tool;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.glodon.ngtrade.util.common.code.MessageCode;
import com.glodon.ngtrade.util.common.exception.NgtradeException;
import com.glodon.ngtrade.util.common.tool.CrmUtil;
import com.glodon.ngtrade.util.devcenter.dto.devplatform.ProductDTO;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by lvxg on 2017/7/28.
 * 对接开发者中心。
 */
@Component
public class DevCenterUtil {

    private static final Logger logger = LoggerFactory.getLogger(DevCenterUtil.class);

    @Value("${dev.Center.Url:https://crm-api-dev.glodon.com}")
    private String devCenterUrl;

    @Resource(name = "devRestTemplate")
    private RestTemplate restTemplate;

    /**
     * 根据锁号查询锁资产:
     * 加密锁号/锁类型/所属客户/客户编号/业务员/购买时间
     */
    public JSONObject findAssertByLockId(String lockNumber, String appKey, String appSecret) {
        logger.info("根据输入锁号查询锁资产，输入为" + lockNumber);
        lockNumber = CrmUtil.getDigitAndRemoveLeftZeroFromString(lockNumber);

        Map<String, Object> params = new HashMap<>();
        params.put("keyNum", lockNumber);
        params.put("appKey", appKey);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/asset/queryAssetByKeyNum", params, null, null,
                        appSecret);

        String url =
                devCenterUrl + "/api/crm/v1/asset/queryAssetByKeyNum?keyNum=" + lockNumber + "&g-signature="
                        + signature + "&appKey=" + appKey;
        logger.info(
                "findAssertByLockId:url=" + url + ",lockNumber=" + lockNumber + ",signature=" + signature);

        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        JSONObject data = jsonObject.getJSONObject("data");
        JSONArray assetsList = data.getJSONArray("assetList");
        FilterYunNanAsset proxy = (FilterYunNanAsset) new CGLibProxy(FilterYunNanAsset.class)
                .getProxyInstance();
        JSONArray newList = proxy.filterYunNanAsset(assetsList);
        data.put("assetList", newList);
        data.put("length", newList.size());
        return data;
    }

    /**
     * 根据锁号查询锁资产:本方法不会过滤资产（比如分支为云南）
     */
    public JSONArray findAssert(String lockNumber, String appKey, String appSecret) {
        logger.info("根据输入锁号查询锁资产，输入为" + lockNumber);
        lockNumber = CrmUtil.getDigitAndRemoveLeftZeroFromString(lockNumber);

        Map<String, Object> params = new HashMap<>();
        params.put("keyNum", lockNumber);
        params.put("appKey", appKey);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/asset/queryAssetByKeyNum", params, null, null,
                        appSecret);

        String url =
                devCenterUrl + "/api/crm/v1/asset/queryAssetByKeyNum?keyNum=" + lockNumber + "&g-signature="
                        + signature + "&appKey=" + appKey;
        logger.info(
                "findAssertByLockId:url=" + url + ",lockNumber=" + lockNumber + ",signature=" + signature);

        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        JSONObject data = jsonObject.getJSONObject("data");
        JSONArray assetsList = data.getJSONArray("assetList");
        return assetsList;
    }

    /**
     * 防止接口返回异常
     */
    private JSONObject checkAndGet(ResponseEntity<JSONObject> responseEntity) {
        if (responseEntity.getStatusCode() != HttpStatus.OK) {
            logger.error("调用开发者中心失败，返回非200异常");
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.NET_CALL_ERROR);
        }
        JSONObject jsonObject = responseEntity.getBody();
        String code = jsonObject.getString("code");
        if (code == null || !code.equals("0")) {
            throw NgtradeException.exception(MessageCode.MessageCodeEnum.NET_CALL_ERROR);
        }
        return jsonObject;
    }

    /**
     * 根据锁号查询锁资产:在用，云南
     * 加密锁号/锁类型/所属客户/客户编号/业务员/购买时间
     */
    public JSONObject findYunnanAssertByLockId(String lockNumber, String appKey, String appSecret) {
        logger.info("根据输入锁号查询锁资产，输入为" + lockNumber);
        lockNumber = CrmUtil.getDigitAndRemoveLeftZeroFromString(lockNumber);

        Map<String, Object> params = new HashMap<>();
        params.put("keyNum", lockNumber);
        params.put("appKey", appKey);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/asset/queryAssetByKeyNum", params, null, null,
                        appSecret);

        String url =
                devCenterUrl + "/api/crm/v1/asset/queryAssetByKeyNum?keyNum=" + lockNumber + "&g-signature="
                        + signature + "&appKey=" + appKey;
        logger.info(
                "findAssertByLockId:url=" + url + ",lockNumber=" + lockNumber + ",signature=" + signature);

        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        JSONObject data = jsonObject.getJSONObject("data");
        JSONArray assetsList = data.getJSONArray("assetList");
        FilterYunNanAsset proxy = (FilterYunNanAsset) new CGLibProxy(FilterYunNanAsset.class)
                .getProxyInstance();
        JSONArray newList = proxy.filterYunNanAsset(assetsList);
        return (JSONObject) newList.get(0);
    }


    /**
     * 模糊查询客户
     */
    public JSONObject findCustomerLike(String pattern, String branchName, String appKey, String appSecret) {
        logger.info("根据输入模糊查询客户，输入为{}", pattern);
        pattern = pattern.replaceAll("[+%&/: ?=#;@!$_.!~*'()\\-]", "");

        // 前置条件检验：如果查询内容为空，不调用开发者中心，直接返回nullJsonObject
        if ("".equals(pattern.trim())) {
            String nullJsonObject = "{\"length\":0,\"customerList\":[]}";
            return JSON.parseObject(nullJsonObject);
        }

        Map<String, Object> params = new HashMap<>();
        params.put("appKey", appKey);
        params.put("query", pattern);
        params.put("branchName", branchName);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/customer/list", params, null, null, appSecret);

        String url =
                devCenterUrl + "/api/crm/v1/customer/list?query=" + pattern + "&branchName=" + branchName
                        + "&g-signature=" + signature + "&appKey=" + appKey;
        logger
                .info("findAssertByLockId:url=" + url + ",pattern=" + pattern + ",signature=" + signature);

        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        return jsonObject.getJSONObject("data");
    }

    /**
     * 根据客户编号查询锁资产
     *
     * @param customerId   根据该ID查询，且使用该值组合json信息
     * @param customerName 使用该值组合json信息
     */
    public JSONObject findAssertByCustomerId(String customerId, String customerName, String appKey, String appSecret) {
        logger.info("根据客户编号查询锁资产，输入为" + customerId);

        Map<String, Object> params = new HashMap<>();
        params.put("appKey", appKey);
        params.put("customerId", customerId);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/asset/queryByCustomerId", params, null, null, appSecret);

        String url = devCenterUrl + "/api/crm/v1/asset/queryByCustomerId?customerId=" + customerId
                + "&g-signature=" + signature + "&appKey=" + appKey;
        logger.info(
                "findAssertByLockId:url=" + url + ",customerId=" + customerId + ",signature=" + signature);

        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);

        JSONObject data = jsonObject.getJSONObject("data");
        JSONArray assetsList = data.getJSONArray("assetList");
        FilterYunNanAsset proxy = (FilterYunNanAsset) new CGLibProxy(FilterYunNanAsset.class)
                .getProxyInstance();
        JSONArray newList = proxy.filterYunNanAsset(assetsList);
        // 将前端需要的customerId和customerName拼到json里。
        for (int i = 0; i < newList.size(); i++) {
            JSONObject item = (JSONObject) newList.get(i);
            item.put("customerId", customerId);
            item.put("customerName", customerName);
            newList.set(i, item);
        }
        data.put("assetList", newList);
        data.put("length", newList.size());
        return data;
    }


    /**
     * 根据产品id查询产品下助记符非空的产品列表
     */
    public List<ProductDTO> queryGmsidByProdid(String prodid, String appKey, String appSecret) {
        logger.info("根据产品id查询产品下助记符非空的产品列表，输入为" + prodid);

        Map<String, Object> params = new HashMap<>();
        params.put("appKey", appKey);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/product/id/" + prodid + "/", params, null, null,
                        appSecret);

        String url =
                devCenterUrl + "/api/crm/v1/product/id/" + prodid + "/?" + "g-signature=" + signature
                        + "&appKey=" + appKey;
        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        JSONArray array = jsonObject.getJSONObject("data").getJSONArray("productList");
        return JSONArray.parseArray(JSON.toJSONString(array), ProductDTO.class);
    }

    /**
     * 查询CRM订单状态
     */
    public JSONObject queryCrmOrderStatus(String orderNum, String appKey, String appSecret) {
        Map<String, Object> params = new HashMap<>();
        params.put("appKey", appKey);
        params.put("orderNum", orderNum);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/order/status", params, null, null, appSecret);

        String url = devCenterUrl + "/api/crm/v1/order/status?orderNum=" + orderNum + "&appKey="
                + appKey + "&g-signature=" + signature;
        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        JSONObject statusObject = jsonObject.getJSONObject("data");
        return statusObject;
    }

    /**
     * 根据锁号及产品ID查询产品详情
     */
    public JSONArray queryValidBySerialNum(String serialNum, String prodIdList, String appKey, String appSecret) {
        Map<String, Object> params = new HashMap<>();
        params.put("appKey", appKey);
        params.put("serialNum", serialNum);
        params.put("prodIdList", prodIdList);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/asset/queryValidBySerialNum", params, null, null,
                        appSecret);

        String url = String.format("%s?serialNum=%s&prodIdList=%s&g-signature=%s&appKey=%s",
                devCenterUrl + "/api/crm/v1/asset/queryValidBySerialNum", serialNum, prodIdList, signature,
                appKey);
        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        if (!jsonObject.getString("code").equals("0")) {
            return null;
        }
        if (jsonObject.getJSONObject("data") == null) {
            return null;
        }
        if (jsonObject.getJSONObject("data").getJSONArray("assetList") == null) {
            return null;
        }
        return jsonObject.getJSONObject("data").getJSONArray("assetList");
    }

    /**
     * 根据锁号查询锁下所有在用产品
     */
    public JSONArray queryValidBySerialNum(String serialNum, String appKey, String appSecret) {
        Map<String, Object> params = new HashMap<>();
        params.put("appKey", appKey);
        params.put("serialNum", serialNum);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/asset/queryValidBySerialNum", params, null, null,
                        appSecret);

        String url = String.format("%s?serialNum=%s&g-signature=%s&appKey=%s",
                devCenterUrl + "/api/crm/v1/asset/queryValidBySerialNum", serialNum, signature,
                appKey);
        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        if (!jsonObject.getString("code").equals("0")) {
            return null;
        }
        if (jsonObject.getJSONObject("data") == null) {
            return null;
        }
        if (jsonObject.getJSONObject("data").getJSONArray("assetList") == null) {
            return null;
        }
        return jsonObject.getJSONObject("data").getJSONArray("assetList");
    }


    /**
     * 根据锁号查询锁资产:在用，锁模式，锁号匹配
     *
     * @param lock 锁号
     * @return 是否可补锁：true可补 false不可补
     */
    public boolean findLockModeByLockId(String lock, String appKey, String appSecret) {
        logger.info("查询开发者中心锁资产，输入为lock" + lock);
        String lockNumber = CrmUtil.getDigitAndRemoveLeftZeroFromString(lock);

        Map<String, Object> params = new HashMap<>();
        params.put("keyNum", lockNumber);
        params.put("appKey", appKey);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/asset/queryAssetByKeyNum", params, null, null,
                        appSecret);

        String url =
                devCenterUrl + "/api/crm/v1/asset/queryAssetByKeyNum?keyNum=" + lockNumber + "&g-signature="
                        + signature + "&appKey=" + appKey;
        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        logger.info("查询开发者中心锁资产，输入为lock{},返回报文：findLockModeByLockId:{}", lock,
                JSON.toJSONString(jsonObject, false));

        JSONObject data = jsonObject.getJSONObject("data");
        JSONArray assetsList = data.getJSONArray("assetList");
        JSONObject lockObjetc = filterLockMode(assetsList, lock);
        if (lockObjetc == null) {
            throw NgtradeException
                    .exception(MessageCode.MessageCodeEnum.AUTH_INVOKE_LOCK_MODE_IS_NULL, lock);
        }
        String lockmode = lockObjetc.getString("lockMode");
        return "可补普通锁".equals(lockmode);
    }

    /**
     * 过滤在用锁模式
     */
    private JSONObject filterLockMode(JSONArray assetsList, String lock) {
        JSONArray newList = new JSONArray();
        Map<String, JSONObject> lockMap = new HashMap<>();
        lock = CrmUtil.getDigitAndRemoveLeftZeroFromString(lock);
        for (int i = 0; i < assetsList.size(); i++) {
            JSONObject item = assetsList.getJSONObject(i);
            String serialNum = CrmUtil
                    .getDigitAndRemoveLeftZeroFromString(item.getString("serialNum"));//锁号
            int status = item.getIntValue(
                    "status");//锁状态， (-1, "未定义"), (0, "停用"), RECYCLE(1, "已回收"), (2, "在用"),(3, "待回收");
            if (serialNum.equals(lock) && //锁号数字部分匹配
                    status == 2 //状态为在用
            ) {
                JSONObject old = lockMap.get(serialNum);
                if (old == null) {
                    newList.add(assetsList.get(i));
                    lockMap.put(serialNum, (JSONObject) assetsList.get(i));
                } else {
                    if (old.getLongValue("createDate") < ((JSONObject) assetsList.get(i))
                            .getLongValue("createDate")) {
                        lockMap.put(serialNum, (JSONObject) assetsList.get(i));
                    }
                }
            }
        }
        return lockMap.isEmpty() ? null : lockMap.get(lock);
    }


    /**
     * 根据锁号及gmsPid查询资产信息，过滤掉待回收的资产
     *
     * @param serialNum 锁号
     * @param gmsPid    产品助记符gmsPid，可以传多个，逗号分隔
     * @param appKey
     * @param appSecret
     * @return
     */
    public JSONArray queryAssetBySerialNumAndGmsPid(String serialNum, String gmsPid, String appKey, String appSecret) {
        Map<String, Object> params = new HashMap<>();
        params.put("appKey", appKey);
        params.put("serialNum", serialNum);
        params.put("gmsPid", gmsPid);

        String signature = DevCenterSignatureUtils
                .signRequest("/api/crm/v1/asset/queryBySerialNumAndGmsPid", params, null, null,
                        appSecret);

        String url = MessageFormat.format("{0}?serialNum={1}&gmsPid={2}&g-signature={3}&appKey={4}",
                devCenterUrl + "/api/crm/v1/asset/queryBySerialNumAndGmsPid", serialNum, gmsPid, signature,
                appKey);
        ResponseEntity<JSONObject> responseEntity = restTemplate.getForEntity(url, JSONObject.class);
        JSONObject jsonObject = checkAndGet(responseEntity);
        if (jsonObject.getJSONObject("data") == null || jsonObject.getJSONObject("data").getJSONArray("assetList") == null) {
            return null;
        }
        JSONArray jsonArray = jsonObject.getJSONObject("data").getJSONArray("assetList");
        List<JSONObject> list =
                jsonArray.parallelStream().map(a -> (JSONObject) a).filter(a -> StringUtils.isNotBlank(a.getString("status")) && !"待回收".equals(a.getString("status"))).collect(Collectors.toList());
        return new JSONArray(new ArrayList<>(list));
    }
}
