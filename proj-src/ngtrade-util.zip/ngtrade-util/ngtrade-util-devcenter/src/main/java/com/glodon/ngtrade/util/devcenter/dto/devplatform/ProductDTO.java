package com.glodon.ngtrade.util.devcenter.dto.devplatform;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

/**
 * Created by Dable on 2017/8/6 11:48.
 */
public class ProductDTO {
	private String prodId;//产品ID
	private String timeFlg;//是否时效产品；N|Y
	private String subType;///产品版式 -1 未定义  0 单机版 1网络版
	private String name;//产品名称
	private String gmsPid;//产品助记符
	private String specFlg;//是否为大客户产品

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProdId() {
		return prodId;
	}

	public void setProdId(String prodId) {
		this.prodId = prodId;
	}

	public String getTimeFlg() {
		return timeFlg;
	}

	public void setTimeFlg(String timeFlg) {
		this.timeFlg = timeFlg;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getGmsPid() {
		return gmsPid;
	}

	public void setGmsPid(String gmsPid) {
		this.gmsPid = gmsPid;
	}

	public String getSpecFlg() {
		return specFlg;
	}

	public void setSpecFlg(String specFlg) {
		this.specFlg = specFlg;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		 return ReflectionToStringBuilder.toString(this);
	}
}
