package com.glodon.ngtrade.util.devcenter.dto.devplatform;

import com.glodon.ngtrade.util.common.tool.DateUtils;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CrmAsset {

  private String assetId;//资产ID
  private Long effEndDate;//结束时间
  private Long effStartDate;//开始时间
  private Long createDate;//创建时间
  private Integer nodeNum;//节点数
  private String prodId;//产品id
  private String prodName;//产品名称
  private Integer subType;//单机版 or 网络版 0 or 1
  private String gmsPid;//gmsid
  private String password;//password

  /**
   * 更新开始时间时分秒为000000或者当前
   */
  public void updateStartDate() {
    Date nowDate = new Date();
    long nowLong = nowDate.getTime();
    long nowLong000000 = DateUtils
        .strToDate(DateUtils.dateToStr(nowDate, DateUtils.YYYY_MM_DD_TYPE) + " 00:00:00", DateUtils.yyyy_MM_dd_HH_mm_ss).getTime();
    long startLong000000 = DateUtils.strToDate(DateUtils.dateToStr(new Date(this.effStartDate.longValue()), DateUtils.YYYY_MM_DD_TYPE) + " 00:00:00", DateUtils.yyyy_MM_dd_HH_mm_ss).getTime();
    this.effStartDate = this.effStartDate.longValue() < nowLong ? nowLong000000 : startLong000000;
  }

  /**
   * 更新截止时间时分秒为235959
   */
  public void updateEndDate() {
    long endLong235959 = DateUtils.strToDate(DateUtils.dateToStr(new Date(this.effEndDate.longValue()), DateUtils.YYYY_MM_DD_TYPE) + " 23:59:59", DateUtils.yyyy_MM_dd_HH_mm_ss).getTime();
    this.effEndDate = endLong235959;
  }
}
