package com.glodon.ngtrade.util.devcenter.rest.tool;

import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.TreeMap;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * 签名工具类
 */
public class DevCenterSignatureUtils {
	
  /**
   * 对请求url、参数、token、body进行签名
   */
  public static String signRequest(String url, Map<String, Object> params, Map<String, Object>
    headers, String jsonBody,String appSecret) {
    // 拼接请求字符串
    String signDate = getSignData(url, params, headers, jsonBody,appSecret);
    // 将拼接后字符串转为md5
    return getMd5Hex(signDate);
  }

  // 拼接字符串
  private static String getSignData(String url, Map<String, Object> params, Map<String, Object>
    headers, String jsonBody,String appSecret) {
    // 对参数进行排序
    Map<String, Object> sortedParams = getSortedParamMap(params);
    // 从header中获取token
    String accessToken = headers == null ? null : getAccessToken(headers);
    // 若token不为空，参与排序
    if(StringUtils.isNotBlank(accessToken)){
      sortedParams.put("accessToken", accessToken);
    }

    // 以&为连接符拼接排序后参数值
    StringBuilder sb = new StringBuilder(url);
    for (Map.Entry<String, Object> entry : sortedParams.entrySet()) {
      String key = entry.getKey();
      String value = null;
      if (entry.getValue() != null) {
        value = String.valueOf(entry.getValue());
      }
      if (!key.equals("g-signature") && value != null) {
        //g-signature不参与签名运算
        sb.append("&").append(value);
      }
    }
    // 若存在请求体json，拼接json
    if(StringUtils.isNotBlank(jsonBody)){
      sb.append("&").append(jsonBody);
    }
    // 最后拼接secret
    sb.append("&").append(appSecret);
    return sb.toString();
  }

  // 获取字符串md5值
  private static String getMd5Hex(String signData) {
    byte[] bytes;
    try {
      bytes = signData.getBytes("UTF-8");
      String signMsg = DigestUtils.md5Hex(bytes);
      String sign = signMsg.toUpperCase();
      return sign;
    } catch (UnsupportedEncodingException e) {
      throw new RuntimeException("String to bytes failed! String: " + signData, e);
    }
  }

  // 对请求参数进行排序
  private static Map<String, Object> getSortedParamMap(Map<String, Object> params){
    Map<String, Object> sortedParams = new TreeMap<String, Object>();
    if(params == null) {
      return sortedParams;
    }
    for (Map.Entry<String, Object> entry : params.entrySet()) {
      String key = entry.getKey();
      if (entry.getValue() != null) {
        sortedParams.put(key, entry.getValue());
      }
    }
    return sortedParams;
  }

  //从header中获取accessToken
  private static String getAccessToken(Map<String, Object> headers) throws SecurityException{
    if(headers == null || headers.get("Authorization") == null){
      return null;
    }
    //格式：Authorization: Bearer {accesstoken}
    String authorization = String.valueOf(headers.get("Authorization"));
    String[] accesstokenArray = authorization.split(" ");
    if(accesstokenArray.length != 2){
      throw new RuntimeException("Accesstoken have a bad format！ " + authorization);
    }
    return accesstokenArray[1];
  }
}
