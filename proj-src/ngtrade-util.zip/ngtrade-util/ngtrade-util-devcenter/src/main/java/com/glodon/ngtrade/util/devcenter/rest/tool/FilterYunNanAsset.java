package com.glodon.ngtrade.util.devcenter.rest.tool;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.glodon.ngtrade.util.common.tool.CrmUtil;

public class FilterYunNanAsset {

  /**
   * 过滤云南资产
   */
  public JSONArray filterYunNanAsset(JSONArray assetsList) {
    JSONArray newList = new JSONArray();
    for (int i = 0; i < assetsList.size(); i++) {
      JSONObject item = assetsList.getJSONObject(i);
      String serialNum = item.getString("serialNum");//锁号
      String lockMode = item.getString("lockMode");//锁模式，可补普通锁 or null
      int type = item.getIntValue("type");//锁类型：（0单机密码锁） or:  （1网络密码锁）
      int status = item.getIntValue(
          "status");//锁状态， (-1, "未定义"), (0, "停用"), RECYCLE(1, "已回收"), (2, "在用"),(3, "待回收");
      String customerOrg = item.getString("customerOrg");//客户组织
      String assetType = item.getString("assetType");//资产类型，大客户授权资产or null

      serialNum = CrmUtil.getDigitAndRemoveLeftZeroFromString(serialNum);
      if (serialNum.startsWith("32") && //32开头
          lockMode != null && lockMode.equals("可补普通锁") &&//锁模式为可补锁
          type == 0 &&//锁类型为单机密码锁
          status == 2 &&//状态为在用
          customerOrg != null && customerOrg.equals("云南") &&//组织为云南
          assetType == null) {//资产类型为空（非【大客户授权资产】）
        newList.add(assetsList.get(i));
      }
    }
    return newList;
  }
}
