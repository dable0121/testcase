package com.glodon.ngtrade.util.cj.ws;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "data")
public class OrderRespRootData {

  private List<OrderProductItem> productItems;

  @XmlElement(name = "product")
  public List<OrderProductItem> getProductItems() {
    return productItems;
  }

  public void setProductItems(List<OrderProductItem> productItems) {
    this.productItems = productItems;
  }

  @Override
  public String toString() {
    return "OrderRespRootData{" +
        "productItems=" + productItems +
        '}';
  }
}