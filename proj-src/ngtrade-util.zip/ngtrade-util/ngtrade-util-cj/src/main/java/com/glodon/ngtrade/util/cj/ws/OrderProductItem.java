package com.glodon.ngtrade.util.cj.ws;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "product")
@XmlType(propOrder = {"name", "account", "gid", "beginDate", "expireDate", "amount"})
public class OrderProductItem {

  private String name;
  private String account;
  private String gid;
  private String beginDate;
  private String expireDate;
  private String amount;

  @XmlElement(name = "name")
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @XmlElement(name = "account")
  public String getAccount() {
    return account;
  }

  public void setAccount(String account) {
    this.account = account;
  }

  @XmlElement(name = "gid")
  public String getGid() {
    return gid;
  }

  public void setGid(String gid) {
    this.gid = gid;
  }

  @XmlElement(name = "beginDate")
  public String getBeginDate() {
    return beginDate;
  }

  public void setBeginDate(String beginDate) {
    this.beginDate = beginDate;
  }

  @XmlElement(name = "expireDate")
  public String getExpireDate() {
    return expireDate;
  }

  public void setExpireDate(String expireDate) {
    this.expireDate = expireDate;
  }

  @XmlElement(name = "amount")
  public String getAmount() {
    return amount;
  }

  public void setAmount(String amount) {
    this.amount = amount;
  }

  @Override
  public String toString() {
    return "OrderProductItem{" +
        "name='" + name + '\'' +
        ", account='" + account + '\'' +
        ", gid='" + gid + '\'' +
        ", beginDate='" + beginDate + '\'' +
        ", expireDate='" + expireDate + '\'' +
        ", amount='" + amount + '\'' +
        '}';
  }
}
