package com.glodon.ngtrade.util.cj.ws;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "root")
public class OrderRootProductList {

  private List<OrderProductItem> orderProductItems;

  @XmlElement(name = "product")
  public List<OrderProductItem> getOrderProductItems() {
    return orderProductItems;
  }

  public void setOrderProductItems(
      List<OrderProductItem> orderProductItems) {
    this.orderProductItems = orderProductItems;
  }

  @Override
  public String toString() {
    return "OrderRootProductList{" +
        "orderProductItems=" + orderProductItems +
        '}';
  }
}