package com.glodon.ngtrade.util.cj.ws;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "root")
public class OrderRespRoot {

  private String code;
  private String msg;
  private OrderRespRootData data;

  @XmlElement(name = "data")
  public OrderRespRootData getData() {
    return data;
  }

  public void setData(OrderRespRootData data) {
    this.data = data;
  }

  @XmlElement(name = "code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  @XmlElement(name = "msg")
  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
  }

  @Override
  public String toString() {
    return "OrderRespRoot{" +
        "code='" + code + '\'' +
        ", msg='" + msg + '\'' +
        ", data=" + data +
        '}';
  }
}