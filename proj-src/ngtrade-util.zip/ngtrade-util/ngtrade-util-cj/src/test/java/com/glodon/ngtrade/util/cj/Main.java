package com.glodon.ngtrade.util.cj;

import com.glodon.ngtrade.util.cj.config.CjCxfConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackageClasses = CjCxfConfig.class)
public class Main {

  public static void main(String[] args) {
    SpringApplication.run(Main.class, args);
  }
}

