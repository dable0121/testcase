package com.glodon.ngtrade.util.cj.ws;

import glodon.gcj.member.center.api.ws.DeliverWebService;
import glodon.gcj.member.center.api.ws.DeliverWebServiceService;
import glodon.gcj.member.center.api.ws.ParseException_Exception;
import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.util.DigestUtils;

public class DeliverWebServiceTest {

  private static DeliverWebServiceService deliverWebServiceService;
  private static DeliverWebService deliverWebService;

  @BeforeClass
  public static void init() throws MalformedURLException {
    deliverWebServiceService = new DeliverWebServiceService(
        new URL("http://192.168.133.177:8380/ws/deliver?wsdl"));
    deliverWebService = deliverWebServiceService.getDeliverWebServicePort();
  }

  @Test
  public void getSomeCustomerAccountInfo() {
    String resp = deliverWebService.getCustomerAccountInfo("1-5ZJM3V", 6386861691385848381L);
    System.out.println(resp);
  }

  @Test
  public void getAllCustomerAccountInfo() {
    String resp = deliverWebService.getCustomerAccountInfo("1-5OCKSL", null);
    System.out.println(resp);
  }

  @Test
  public void auth() throws ParseException_Exception, JAXBException {
    String key = "ddc2cc19f51a48B7a4Fe2192e00a5be8";
    String appCode = "d4a1cb2595A141738712";
    String orderCode = "111111111112";
    String customCode = "custom";
    String orderInfo;

    Writer w;
    Marshaller marshaller;
    JAXBContext jaxbContext;

    OrderRootProductList orderRootProductList = new OrderRootProductList();

    List<OrderProductItem> orderProductItemList = new ArrayList<>();

    OrderProductItem orderProductItem = new OrderProductItem();
    orderProductItem.setName("广材网");
    orderProductItem.setAccount("新建账号1");
    orderProductItem.setGid("");
    orderProductItem.setAmount("1");
    orderProductItem.setBeginDate("2017-01-01");
    orderProductItem.setExpireDate("2017-12-31");

    orderProductItemList.add(orderProductItem);
    orderRootProductList.setOrderProductItems(orderProductItemList);

    w = new StringWriter();
    jaxbContext = JAXBContext.newInstance(OrderRootProductList.class);
    marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
    marshaller.marshal(orderRootProductList, w);
    orderInfo = w.toString();

    String signSrc = String
        .format("appCode=%s&orderCode=%s&orderInfo=%s&key=%s", appCode, orderCode, orderInfo, key);
    System.out.println(signSrc);
    String sign = DigestUtils.md5DigestAsHex(signSrc.getBytes()).toUpperCase();
    System.out.println(sign);
    String resp = deliverWebService.authMall(appCode, sign, customCode, orderInfo, orderCode);
    System.out.println(resp);
  }
}
