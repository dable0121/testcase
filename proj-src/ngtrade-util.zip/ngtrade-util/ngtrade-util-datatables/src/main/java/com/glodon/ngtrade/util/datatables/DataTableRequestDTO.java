/**
 * 
 */
package com.glodon.ngtrade.util.datatables;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;

/**
 * The Class DataTableRequest.
 */
public class DataTableRequestDTO {
	// 客户端原样返回
	private String draw;
	// 分页使用
	private Integer start; //当前页
	private Integer length; // 页面最大数量
	// 搜索值
	private String searchValue;
	// 列属性
	private List<DataTableColumnSpecs> columns;
	// 排序的列
	private List<DataTableColumnSpecs> orders;
	

	public DataTableRequestDTO(HttpServletRequest request) {
		prepareDataTableRequest(request);
	}
	
	public Integer getStart() {
		return start;
	}

	public void setStart(Integer start) {
		this.start = start;
	}

	public Integer getLength() {
		return length;
	}

	public void setLength(Integer length) {
		this.length = length;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public List<DataTableColumnSpecs> getColumns() {
		return columns;
	}

	public void setColumns(List<DataTableColumnSpecs> columns) {
		this.columns = columns;
	}

	public List<DataTableColumnSpecs> getOrder() {
		return orders;
	}

	public void setOrder(List<DataTableColumnSpecs> orders) {
		this.orders = orders;
	}
	
	public String getDraw() {
		return draw;
	}

	public void setDraw(String draw) {
		this.draw = draw;
	}


	/**
	 * Prepare data table request.
	 *
	 */
	private void prepareDataTableRequest(HttpServletRequest request) {
		
		Enumeration<String> parameterNames = request.getParameterNames();
    	
    	if(parameterNames.hasMoreElements()) {
    		
    		this.setStart(Integer.parseInt(request.getParameter("start")));
    		this.setLength(Integer.parseInt(request.getParameter("length")));
    		this.setDraw(request.getParameter("draw"));
    		this.setSearchValue(request.getParameter("search[value]"));

    		List<DataTableColumnSpecs> columns = new ArrayList<>();
    		List<DataTableColumnSpecs> orders = new ArrayList<>();

				this.maxParamsToCheck = getNumberOfColumns(request);
				this.maxOrdersToCheck = getNumberOfOrders(request);
				Map<String,String> colDirMap = new HashMap<>();
				for(int i=0; i < maxOrdersToCheck; i++) {
					String key = request.getParameter("order[" + i + "][column]");
					String value = request.getParameter("order[" + i + "][dir]");
					colDirMap.put(key,value);
				}
    		for(int i=0; i < maxParamsToCheck; i++) {
					String parameter = request.getParameter("columns[" + i + "][data]");
					if (null != parameter	&& !"null".equalsIgnoreCase(parameter)	&& parameter.length()>0) {
    				DataTableColumnSpecs colSpec = new DataTableColumnSpecs(request, i,colDirMap);
    				if(colDirMap.get(String.valueOf(i))!=null) {
							colSpec.setSortDir(colDirMap.get(String.valueOf(i)));
    					orders.add(colSpec);
    				}
    				columns.add(colSpec);
    			}
    		}
				if(!orders.isEmpty()) {
					this.setOrder(orders);
				}
    		if(!columns.isEmpty()) {
    			this.setColumns(columns);
    		}
    	}
	}
	
	private int getNumberOfColumns(HttpServletRequest request) {
		Pattern p = Pattern.compile("columns\\[[0-9]+\\]\\[data\\]");  
		@SuppressWarnings("rawtypes")
		Enumeration params = request.getParameterNames(); 
		List<String> lstOfParams = new ArrayList<>();
		while(params.hasMoreElements()){		
		 String paramName = (String)params.nextElement();
		 Matcher m = p.matcher(paramName);
		 if(m.matches())	{
			 lstOfParams.add(paramName);
		 }
		}
		return lstOfParams.size();
	}
	private int getNumberOfOrders(HttpServletRequest request) {
		Pattern p = Pattern.compile("order\\[[0-9]+\\]\\[column\\]");
		@SuppressWarnings("rawtypes")
		Enumeration params = request.getParameterNames();
		List<String> lstOfParams = new ArrayList<>();
		while(params.hasMoreElements()){
		 String paramName = (String)params.nextElement();
		 Matcher m = p.matcher(paramName);
		 if(m.matches())	{
			 lstOfParams.add(paramName);
		 }
		}
		return lstOfParams.size();
	}
	
	private int maxParamsToCheck = 0;
	private int maxOrdersToCheck = 0;
}
