/**
 *
 */
package com.glodon.ngtrade.util.datatables;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;

/**
 * 列属性
 */
public class DataTableColumnSpecs {

    private int index;
    private String data;
    private String name;
    private boolean searchable;
    private boolean orderable;
    private String filterValue;
    private String sortDir;

    public DataTableColumnSpecs(){

    }
    public DataTableColumnSpecs(HttpServletRequest request, int i,Map<String,String> colDirMap) {
        this.setIndex(i);
        prepareColumnSpecs(request, i,colDirMap);
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isSearchable() {
        return searchable;
    }

    public void setSearchable(boolean searchable) {
        this.searchable = searchable;
    }

    public boolean isOrderable() {
        return orderable;
    }

    public void setOrderable(boolean orderable) {
        this.orderable = orderable;
    }

    public String getFilterValue() {
        return filterValue;
    }

    public void setFilterValue(String filterValue) {
        this.filterValue = filterValue;
    }

    public String getSortDir() {
        return sortDir;
    }

    public void setSortDir(String sortDir) {
        this.sortDir = (null != sortDir) ? sortDir.toUpperCase() : sortDir;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    private void prepareColumnSpecs(HttpServletRequest request, int i,Map<String,String> colDirMap) {

        this.setData(request.getParameter("columns[" + i + "][data]"));
        this.setName(request.getParameter("columns[" + i + "][name]"));
        this.setOrderable(Boolean.valueOf(request.getParameter("columns[" + i + "][orderable]")));
        this.setFilterValue(request.getParameter("columns[" + i + "][search][value]"));
        this.setSearchable(Boolean.valueOf(request.getParameter("columns[" + i + "][searchable]")));
        if (colDirMap.get(String.valueOf(i))!=null) {
            this.setSortDir(colDirMap.get(String.valueOf(i)));
        }
    }

}
