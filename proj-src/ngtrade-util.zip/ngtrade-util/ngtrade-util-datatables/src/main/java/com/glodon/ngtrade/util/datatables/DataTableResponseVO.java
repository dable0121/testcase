package com.glodon.ngtrade.util.datatables;

import java.util.List;

/**
 * Created by lvxg on 2017/8/4.
 */
public class DataTableResponseVO<T> {
    private String draw;
    private String recordsFiltered;
    private String recordsTotal;
    private List<T> data;

    public String getDraw() {
        return draw;
    }

    public void setDraw(String draw) {
        this.draw = draw;
    }

    public String getRecordsFiltered() {
        return recordsFiltered;
    }

    public void setRecordsFiltered(String recordsFiltered) {
        this.recordsFiltered = recordsFiltered;
    }

    public String getRecordsTotal() {
        return recordsTotal;
    }

    public void setRecordsTotal(String recordsTotal) {
        this.recordsTotal = recordsTotal;
    }

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }
}
