/**
 *
 */
package com.glodon.ngtrade.util.datatables;


import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * The Class DataTableRequest.
 */
public class DataTableRequestMapDTO {
	// 客户端原样返回
	private String draw;
	// 分页使用
	private Integer start; //当前页
	private Integer length; // 页面最大数量
	// 搜索值
	private String searchValue;
	// 列属性
	private Map<String, DataTableColumnSpecs> columns;
	// 排序的列
	private DataTableColumnSpecs order;

	private int maxParamsToCheck = 0;

	public DataTableRequestMapDTO(HttpServletRequest request) {
		prepareDataTableRequest(request);
	}

	public Integer getStart() {
		return start;
	}

	public void setStart(Integer start) {
		this.start = start;
	}

	public Integer getLength() {
		return length;
	}

	public void setLength(Integer length) {
		this.length = length;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	public Map<String, DataTableColumnSpecs> getColumns() {
		return columns;
	}

	public void setColumns(Map<String, DataTableColumnSpecs> columns) {
		this.columns = columns;
	}

	public int getMaxParamsToCheck() {
		return maxParamsToCheck;
	}

	public void setMaxParamsToCheck(int maxParamsToCheck) {
		this.maxParamsToCheck = maxParamsToCheck;
	}

	public DataTableColumnSpecs getOrder() {
		return order;
	}

	public void setOrder(DataTableColumnSpecs order) {
		this.order = order;
	}

	public String getDraw() {
		return draw;
	}

	public void setDraw(String draw) {
		this.draw = draw;
	}


	/**
	 * Prepare data table request.
	 */
	private void prepareDataTableRequest(HttpServletRequest request) {

		Enumeration<String> parameterNames = request.getParameterNames();
		if (parameterNames.hasMoreElements()) {
			this.setStart(Integer.parseInt(request.getParameter("start")));
			this.setLength(Integer.parseInt(request.getParameter("length")));
			this.setDraw(request.getParameter("draw"));
			this.setSearchValue(request.getParameter("search[value]"));
			Map<String, DataTableColumnSpecs> columns = new HashMap<>();
			maxParamsToCheck = getNumberOfColumns(request);
			for (int i = 0; i < maxParamsToCheck; i++) {
				String parameter = request.getParameter("columns[" + i + "][data]");
				if (null != parameter	&& !"null".equalsIgnoreCase(parameter)	&& parameter.length()>0) {
					DataTableColumnSpecs colSpec = new DataTableColumnSpecs(request, i,new HashMap<>());
					columns.put(colSpec.getName(), colSpec);
				}
			}
			if (!columns.isEmpty()) {
				this.setColumns(columns);
			}
		}
	}

	@SuppressWarnings("rawtypes")
	private int getNumberOfColumns(HttpServletRequest request) {
		Pattern p = Pattern.compile("columns\\[[0-9]+\\]\\[data\\]");
		Enumeration params = request.getParameterNames();
		List<String> lstOfParams = new ArrayList<String>();
		while(params.hasMoreElements()){
			String paramName = (String)params.nextElement();
			Matcher m = p.matcher(paramName);
			if(m.matches())	{
				lstOfParams.add(paramName);
			}
		}
		return lstOfParams.size();
	}

}
